//! Renders a synthetic textured room with the software 3D renderer to a PPM.
//!   cargo run --release -p doomed-app --example textured_demo -- out.ppm
use doomed_app::{Editor, NewSector};
use doomed_core::render3d::render;
use doomed_core::preview3d::Camera;
use doomed_core::*;

fn le16(v: i16) -> [u8; 2] { v.to_le_bytes() }
fn le32(v: i32) -> [u8; 4] { v.to_le_bytes() }

/// A w x h patch with one full-height post per column; pixel = f(x, y).
fn patch(w: i16, h: i16, f: impl Fn(i16, i16) -> u8) -> Vec<u8> {
    let mut d = vec![];
    d.extend(le16(w)); d.extend(le16(h)); d.extend(le16(0)); d.extend(le16(0));
    let col_size = 3 + h as usize + 2;
    for x in 0..w { d.extend(le32(8 + 4 * w as i32 + col_size as i32 * x as i32)); }
    for x in 0..w {
        d.extend([0, h as u8, 0]);
        for y in 0..h { d.push(f(x, y)); }
        d.extend([0, 0xFF]);
    }
    d
}

fn texture1(defs: &[(&str, i16, i16, i32)]) -> Vec<u8> {
    let mut d = vec![];
    d.extend(le32(defs.len() as i32));
    let hdr = 4 + 4 * defs.len();
    for i in 0..defs.len() { d.extend(le32((hdr + i * (22 + 10)) as i32)); }
    for (name, w, h, p) in defs {
        let mut n = [0u8; 8]; n[..name.len()].copy_from_slice(name.as_bytes());
        d.extend(n); d.extend(le32(0)); d.extend(le16(*w)); d.extend(le16(*h)); d.extend(le32(0)); d.extend(le16(1));
        d.extend(le16(0)); d.extend(le16(0)); d.extend(le16(*p as i16)); d.extend(le16(1)); d.extend(le16(0));
    }
    d
}

fn main() {
    let out = std::env::args().nth(1).unwrap_or("textured.ppm".into());
    let mut w = Wad::new_pwad();
    // palette: a 16x16 colour cube-ish ramp
    let pal: Vec<u8> = (0..256).flat_map(|i| { let (r, g, b) = ((i >> 5) & 7, (i >> 2) & 7, i & 3); [(r * 36) as u8, (g * 36) as u8, (b * 85) as u8] }).collect();
    w.entries.push(WadEntry::new("PLAYPAL", pal));
    let mut pn = le32(2).to_vec(); pn.extend(b"BRICKP\0\0"); pn.extend(b"DOORP\0\0\0");
    w.entries.push(WadEntry::new("PNAMES", pn));
    // brick: red, mortar lines
    w.entries.push(WadEntry::new("BRICKP", patch(128, 64, |x, y| if y % 16 == 0 || (x + if (y / 16) % 2 == 0 { 0 } else { 16 }) % 32 == 0 { 0b11011011 } else { 0b11100000 })));
    w.entries.push(WadEntry::new("DOORP", patch(64, 128, |x, y| if x < 3 || x > 60 || y < 3 { 0b00000011 } else { 0b01001001 })));
    w.entries.push(WadEntry::new("TEXTURE1", texture1(&[("BRICK", 128, 64, 0), ("DOOR", 64, 128, 1)])));
    w.entries.push(WadEntry::new("F_START", vec![]));
    w.entries.push(WadEntry::new("CHECK", (0..4096).map(|i| if ((i % 64) / 8 + (i / 64) / 8) % 2 == 0 { 0b00011100 } else { 0b00010100 }).collect()));
    w.entries.push(WadEntry::new("TILE", (0..4096).map(|i| if i % 64 == 0 || i / 64 == 0 { 0b11111111 } else { 0b10010010 }).collect()));
    w.entries.push(WadEntry::new("F_END", vec![]));
    let g = GfxAssets::from_wads(&[&w]);

    let mut ed = Editor::new(MapData::new("E1M1"));
    ed.sel_rect = Rect { left: 0, right: 512, top: 512, bottom: 0 };
    ed.create_sector(NewSector::Rectangular);
    ed.sel_rect = Rect { left: 192, right: 320, top: 320, bottom: 192 };
    ed.create_sector(NewSector::Rectangular);
    let m = &mut ed.map;
    let name = |s: &str| { let mut n = [0u8; 8]; n[..s.len()].copy_from_slice(s.as_bytes()); n };
    for s in m.sectors.iter_mut() { s.floor = name("CHECK"); s.ceil = name("TILE"); s.floor_z = 0; s.ceil_z = 192; s.light = 224; }
    m.sectors[1].floor_z = 48; m.sectors[1].ceil_z = 160; m.sectors[1].floor = name("TILE");
    // make the inner sector a two-sided platform inside the big room
    for i in 0..m.linedefs.len() {
        if m.linedef_flags[i].used && m.side_sector(m.linedefs[i].sidedef1) == Some(1) {
            let sd = m.sidedef_new();
            m.sidedefs[sd].sector = 0;
            m.linedefs[i].sidedef2 = sd as i16;
            m.linedefs[i].solidity |= line_bits::TWO_SIDED;
        }
    }
    for sd in m.sidedefs.iter_mut() { sd.t1 = name("BRICK"); sd.t2 = name("DOOR"); sd.t3 = name("BRICK"); }
    let cam = Camera { vx: 480, vy: 40, vz: -120, ox: 256, oy: 256, oz: -40, zoom: 3 };
    let traps: Vec<_> = (0..m.sectors.len()).map(|i| m.sector_traps(i)).collect();
    let mut cache = TexCache::new();
    let img = render(m, &traps, &[], &g, &mut cache, &cam, 640, 480, [0, 0, 0]);
    let mut ppm = format!("P6\n{} {}\n255\n", img.width, img.height).into_bytes();
    for px in img.rgba.chunks_exact(4) { ppm.extend(&px[..3]); }
    std::fs::write(out, ppm).unwrap();
}
