//! Runs real egui frames with no window, so every panel and the canvas painter
//! execute (and would panic on bad indexing) for each tool.
use doomed_app::app::DoomEdApp;
use doomed_app::{Mods, NewSector};
use doomed_core::*;
use eframe::egui;

fn frame(ctx: &egui::Context, app: &mut DoomEdApp) {
    let mut input = egui::RawInput::default();
    input.screen_rect = Some(egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(1100.0, 760.0)));
    let _ = ctx.run(input, |ctx| app.run_ui(ctx));
}

#[test]
fn every_tool_paints_and_shows_its_panel() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    app.ed.tool = Kind::Sector;
    app.ed.sel_rect = Rect { left: 0, right: 256, top: 128, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    app.ed.sel_rect = Rect { left: 512, right: 768, top: 256, bottom: 0 };
    app.ed.create_sector(NewSector::Star);
    let t = app.ed.map.thing_new();
    app.ed.map.things[t].x = 64;
    app.ed.map.things[t].y = 64;
    app.ed.map.select(Kind::Thing, t);
    // give it real-looking graphics so thumbnails and the picker run
    let mut iw = Wad::new_pwad();
    iw.entries.push(WadEntry::new("F_START", vec![]));
    iw.entries.push(WadEntry::new("FLOOR0_1", vec![5; 4096]));
    iw.entries.push(WadEntry::new("F_END", vec![]));
    app.set_iwad(iw);
    for s in app.ed.map.sectors.iter_mut() {
        s.floor = *b"FLOOR0_1";
    }
    app.ed.zoom_all();
    for mode in [doomed_app::app::FillMode::Off, doomed_app::app::FillMode::Floor, doomed_app::app::FillMode::Ceiling, doomed_app::app::FillMode::Light] {
        app.set_fill_mode(mode);
        frame(&ctx, &mut app);
    }
    for k in [Kind::Thing, Kind::Vertex, Kind::LineDef, Kind::Sector] {
        app.ed.set_tool(k);
        app.ed.map.select(k, 0);
        frame(&ctx, &mut app);
        frame(&ctx, &mut app);
    }
    // mid-drag frames too
    app.ed.left_down(Point::new(100, 60), Mods::default(), 0);
    app.ed.mouse_move(Point::new(140, 60), Mods::default(), 900);
    frame(&ctx, &mut app);
}

#[test]
fn picker_and_thumbnails_run() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 128, top: 128, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    let mut iw = Wad::new_pwad();
    iw.entries.push(WadEntry::new("F_START", vec![]));
    iw.entries.push(WadEntry::new("FLOOR0_1", vec![5; 4096]));
    iw.entries.push(WadEntry::new("F_END", vec![]));
    app.set_iwad(iw);
    app.ed.map.sectors[0].floor = to_name8("FLOOR0_1");
    frame(&ctx, &mut app);
    app.open_directory_for_test();
    frame(&ctx, &mut app);
    app.open_picker_for_test();
    frame(&ctx, &mut app);
    assert!(app.has_picker());
}

#[test]
fn the_3d_preview_window_draws() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 256, top: 256, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    app.open_preview();
    frame(&ctx, &mut app);
    frame(&ctx, &mut app);
    assert!(app.preview_open());
}

#[test]
fn every_dialog_draws_for_every_tool() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 128, top: 128, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    for d in ["options", "styles", "defaults", "builders", "platforms", "stats", "search", "replace", "quit", "about"] {
        for k in [Kind::Thing, Kind::Vertex, Kind::LineDef, Kind::Sector] {
            app.ed.set_tool(k);
            app.open_dialog_for_test(d);
            frame(&ctx, &mut app);
            frame(&ctx, &mut app);
        }
    }
}

#[test]
fn settings_persist_through_the_ini_file() {
    let dir = std::env::temp_dir().join(format!("doomed_ini_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let ini = dir.join("DOOMED40.INI");
    let _ = std::fs::remove_file(&ini);
    let mut app = DoomEdApp::default();
    app.load_settings(ini.clone());
    app.ed.grid_size = 32; // the toolbar grid is what gets saved, as in the original
    app.settings.colors.background = 0x202020;
    app.settings.styles.push(Style::new("Mine", "A", "B", "C"));
    app.save_settings();
    let mut again = DoomEdApp::default();
    again.load_settings(ini.clone());
    assert_eq!(again.settings.options.grid_size, 32);
    assert_eq!(again.ed.grid_size, 32);
    assert_eq!(again.settings.styles.last().unwrap().name, "Mine");
    assert_eq!(again.settings.colors.background, 0x202020);
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn textured_3d_preview_draws_and_toggles() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 256, top: 256, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    let mut iw = Wad::new_pwad();
    iw.entries.push(WadEntry::new("PLAYPAL", vec![9; 768]));
    iw.entries.push(WadEntry::new("F_START", vec![]));
    iw.entries.push(WadEntry::new("FLOOR0_1", vec![5; 4096]));
    iw.entries.push(WadEntry::new("F_END", vec![]));
    app.set_iwad(iw);
    for s in app.ed.map.sectors.iter_mut() {
        s.floor = *b"FLOOR0_1";
        s.ceil = *b"FLOOR0_1";
    }
    app.open_preview();
    for _ in 0..3 {
        frame(&ctx, &mut app);
    }
    assert!(app.preview_open());
}

#[test]
fn statistics_count_used_items_after_packing() {
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 128, top: 128, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    let t = app.ed.map.thing_new();
    app.ed.map.things[t].x = 10;
    let st = app.statistics_for_test();
    let get = |k: &str| st.iter().find(|r| r.0 == k).unwrap().1.clone();
    assert_eq!(get("Sectors:"), "1");
    assert_eq!(get("LineDefs:"), "4");
    assert_eq!(get("SideDefs:"), "4");
    assert_eq!(get("Vertexes:"), "4");
    assert_eq!(get("Things:"), "1");
    assert_eq!(get("Tag Descriptions:"), "0");
}

#[test]
fn starts_in_2d_and_toggles_to_a_large_3d_view_without_a_size_cap() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    assert!(!app.is_view3d(), "2D is the startup view");
    app.ed.sel_rect = Rect { left: 0, right: 256, top: 256, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    frame(&ctx, &mut app);
    app.set_view3d(true);
    let mut input = egui::RawInput::default();
    input.screen_rect = Some(egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(2600.0, 1500.0)));
    input.max_texture_side = Some(8192); // a real GPU allows this; the headless default is 2048
    for _ in 0..2 {
        let _ = ctx.run(input.clone(), |c| app.run_ui(c));
    }
    assert!(app.preview_open(), "camera is created on first use");
    app.set_view3d(false);
    frame(&ctx, &mut app);
    assert!(!app.is_view3d());
}

#[test]
fn a_3d_click_selects_in_the_matching_tool() {
    use doomed_core::Kind;
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 256, top: 256, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    app.set_view3d(true);
    app.click_3d_for_test(Kind::LineDef, 2, false);
    assert_eq!(app.ed.tool, Kind::LineDef);
    assert!(app.ed.map.is_selected(Kind::LineDef, 2));
    app.click_3d_for_test(Kind::Sector, 0, false);
    assert_eq!(app.ed.tool, Kind::Sector);
    assert!(app.ed.map.is_selected(Kind::Sector, 0));
    assert!(!app.ed.map.is_selected(Kind::LineDef, 2), "a plain click replaces the selection");
    app.click_3d_for_test(Kind::Sector, 0, true);
    assert!(!app.ed.map.is_selected(Kind::Sector, 0), "shift-click toggles");
}

#[test]
fn undo_steps_back_through_edits_made_over_several_frames() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    frame(&ctx, &mut app);
    app.ed.sel_rect = Rect { left: 0, right: 128, top: 128, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    frame(&ctx, &mut app); // idle: the new sector becomes one undo step
    let t = app.ed.map.thing_new();
    app.ed.map.things[t].x = 40;
    frame(&ctx, &mut app);
    app.ed.map.sectors[0].light = 77;
    app.ed.map.mark_changed();
    frame(&ctx, &mut app);
    assert_eq!(app.ed.map.sectors[0].light, 77);
    assert!(app.undo_for_test());
    assert_ne!(app.ed.map.sectors[0].light, 77, "last edit undone");
    assert!(app.undo_for_test());
    assert!(app.ed.map.thing_flags.iter().all(|f| !f.used) || app.ed.map.things.is_empty(), "thing add undone");
    assert!(app.undo_for_test());
    assert_eq!(app.ed.map.sectors.len(), 0, "sector creation undone");
    assert!(!app.undo_for_test(), "at the start of history");
}

#[test]
fn saving_runs_in_the_background_locks_the_editor_and_then_writes_the_file() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 256, top: 256, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    frame(&ctx, &mut app);
    let path = std::env::temp_dir().join(format!("doomed_save_test_{}.wad", std::process::id()));
    let _ = std::fs::remove_file(&path);
    app.save_for_test(path.to_str().unwrap());
    assert!(app.save_busy_for_test(), "the job is running until a frame collects it");
    for _ in 0..500 {
        frame(&ctx, &mut app);
        if !app.save_busy_for_test() {
            break;
        }
        std::thread::sleep(std::time::Duration::from_millis(10));
    }
    assert!(!app.save_busy_for_test(), "finished");
    assert!(app.status_for_test().contains("Saved"), "{}", app.status_for_test());
    assert!(!app.ed.map.edited);
    let wad = Wad::open(path.to_str().unwrap()).unwrap();
    assert!(wad.entries.iter().any(|e| e.title == "NODES"));
    let _ = std::fs::remove_file(&path);
}

#[test]
fn right_click_saves_and_ctrl_right_click_pastes_wall_and_sector_attributes() {
    use doomed_core::render3d::Pick;
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 128, top: 128, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    app.ed.sel_rect = Rect { left: 512, right: 640, top: 128, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    let nm = |s: &str| { let mut n = [0u8; 8]; n[..s.len()].copy_from_slice(s.as_bytes()); n };
    // source wall: line 0 gets an action, tag and textures
    app.ed.map.linedefs[0].special = 11;
    app.ed.map.linedefs[0].tag = 5;
    app.ed.map.linedefs[0].solidity |= doomed_core::structs::line_bits::SECRET;
    let sd0 = app.ed.map.linedefs[0].sidedef1 as usize;
    app.ed.map.sidedefs[sd0].t3 = nm("BRICK1");
    app.ed.map.sidedefs[sd0].x = 24;
    // a target wall in the second sector
    let target = (0..app.ed.map.linedefs.len()).find(|&i| app.ed.map.side_sector(app.ed.map.linedefs[i].sidedef1) == Some(1)).unwrap();
    app.attr_click_for_test(Pick::Wall(target, 0), true);
    assert_eq!(app.ed.map.linedefs[target].special, 0, "pasting with nothing saved changes nothing");
    app.attr_click_for_test(Pick::Wall(0, 0), false);
    let before = app.ed.map.sectors[1];
    app.attr_click_for_test(Pick::Floor(1), true);
    assert_eq!(app.ed.map.sectors[1], before, "a wall clipboard is not pasted onto a sector");
    app.ed.map.linedefs[target].special = 3;
    app.ed.map.linedefs[target].tag = 8;
    let tsd = app.ed.map.linedefs[target].sidedef1 as usize;
    app.ed.map.sidedefs[tsd].x = 5;
    let before_line = app.ed.map.linedefs[target];
    app.attr_click_for_test(Pick::Wall(target, 0), true);
    let l = app.ed.map.linedefs[target];
    assert_eq!(l, before_line, "flags, action and tag are untouched");
    let sd = app.ed.map.sidedefs[tsd];
    assert_eq!(sd.t3, nm("BRICK1"), "textures are copied");
    assert_eq!(sd.x, 5, "offsets are not");
    assert_eq!(sd.sector, 1, "the sidedef still belongs to its own sector");
    // sectors
    app.ed.map.sectors[0].light = 99;
    app.ed.map.sectors[0].floor_z = 16;
    app.ed.map.sectors[0].floor = nm("FLAT5");
    app.attr_click_for_test(Pick::Ceiling(0), false);
    app.attr_click_for_test(Pick::Floor(1), true);
    let (src, dst) = (app.ed.map.sectors[0], app.ed.map.sectors[1]);
    app.ed.map.sectors[1].floor_z = 7;
    app.ed.map.sectors[1].ceil_z = 111;
    app.ed.map.sectors[1].light = 33;
    app.ed.map.sectors[1].tag = 4;
    app.ed.map.sectors[1].flash = 9;
    let before = app.ed.map.sectors[1];
    app.attr_click_for_test(Pick::Floor(1), true);
    let after = app.ed.map.sectors[1];
    assert_eq!((after.floor, after.ceil), (src.floor, src.ceil), "the flats are copied");
    assert_eq!((after.floor_z, after.ceil_z, after.light, after.tag, after.flash), (before.floor_z, before.ceil_z, before.light, before.tag, before.flash), "nothing else changes");
    let _ = dst;
}

#[test]
fn the_picker_is_five_cells_wide_however_many_flats_there_are() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 128, top: 128, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    let mut iw = Wad::new_pwad();
    iw.entries.push(WadEntry::new("F_START", vec![]));
    for i in 0..400 {
        iw.entries.push(WadEntry::new(&format!("FLAT{i}"), vec![(i % 250) as u8; 4096]));
    }
    iw.entries.push(WadEntry::new("F_END", vec![]));
    app.set_iwad(iw);
    app.open_picker_for_test();
    for _ in 0..3 {
        frame(&ctx, &mut app);
    }
    let r = ctx.memory(|m| m.area_rect(egui::Id::new("Choose a flat"))).expect("picker window");
    assert!(r.width() > 450.0 && r.width() < 560.0, "five 88-point cells plus scroll bar, got {}", r.width());
    assert!(r.height() <= 760.0, "fits the screen, got {}", r.height());
}

#[test]
fn reset_returns_the_3d_viewer_to_its_starting_position() {
    let ctx = egui::Context::default();
    let mut app = DoomEdApp::default();
    app.ed.sel_rect = Rect { left: 0, right: 512, top: 512, bottom: 0 };
    app.ed.create_sector(NewSector::Rectangular);
    app.set_view3d(true);
    frame(&ctx, &mut app);
    let start = app.camera_for_test().unwrap();
    app.preview_cam_mut_for_test(|c| {
        c.orbit(400, 200);
        c.dolly(5);
    });
    assert_ne!(app.camera_for_test().unwrap(), start);
    app.reset_3d_for_test();
    assert_eq!(app.camera_for_test().unwrap(), start);
}
