use doomed_app::{Editor, NewSector};
use doomed_core::preview3d::Camera;
use doomed_core::render3d::render;
use doomed_core::*;

fn gfx() -> GfxAssets {
    let mut w = Wad::new_pwad();
    w.entries.push(WadEntry::new("PLAYPAL", (0..256).flat_map(|i| [i as u8, i as u8, i as u8]).collect()));
    w.entries.push(WadEntry::new("F_START", vec![]));
    w.entries.push(WadEntry::new("FLOOR", vec![200; 4096]));
    w.entries.push(WadEntry::new("CEIL", vec![100; 4096]));
    w.entries.push(WadEntry::new("F_END", vec![]));
    GfxAssets::from_wads(&[&w])
}

fn room() -> Editor {
    let mut ed = Editor::new(MapData::new("E1M1"));
    ed.sel_rect = Rect { left: 0, right: 512, top: 512, bottom: 0 };
    ed.create_sector(NewSector::Rectangular);
    let nm = |s: &str| { let mut n = [0u8; 8]; n[..s.len()].copy_from_slice(s.as_bytes()); n };
    let s = &mut ed.map.sectors[0];
    s.floor = nm("FLOOR");
    s.ceil = nm("CEIL");
    s.floor_z = 0;
    s.ceil_z = 128;
    s.light = 255;
    ed
}

fn px(img: &Image, x: usize, y: usize) -> [u8; 3] {
    let o = (y * img.width + x) * 4;
    [img.rgba[o], img.rgba[o + 1], img.rgba[o + 2]]
}

#[test]
fn inside_a_room_floor_walls_and_ceiling_are_all_drawn() {
    let ed = room();
    let traps: Vec<_> = (0..ed.map.sectors.len()).map(|i| ed.map.sector_traps(i)).collect();
    let mut cache = TexCache::new();
    // eye at 64 units height in the middle of the room, looking along +y and slightly up
    let cam = Camera { vx: 256, vy: 128, vz: -64, ox: 256, oy: 512, oz: -80, zoom: 2 };
    let bg = [1, 2, 3];
    let img = render(&ed.map, &traps, &[], &gfx(), &mut cache, &cam, 320, 240, bg);
    assert_ne!(px(&img, 160, 230), bg, "floor at the bottom of the view");
    assert_ne!(px(&img, 160, 5), bg, "ceiling at the top of the view");
    assert_ne!(px(&img, 160, 120), bg, "far wall in the middle");
    // floor and ceiling use their own flats (200 vs 100 grey), shaded by full light
    assert_eq!(px(&img, 160, 230), [200, 200, 200]);
    assert_eq!(px(&img, 160, 5), [100, 100, 100]);
}

#[test]
fn faces_pointing_away_are_culled_so_a_room_can_be_viewed_from_outside() {
    let ed = room();
    let traps: Vec<_> = (0..ed.map.sectors.len()).map(|i| ed.map.sector_traps(i)).collect();
    let mut cache = TexCache::new();
    // above and outside the room: the ceiling is culled, so the floor shows through
    let cam = Camera { vx: 256, vy: -600, vz: -700, ox: 256, oy: 256, oz: 0, zoom: 2 };
    let img = render(&ed.map, &traps, &[], &gfx(), &mut cache, &cam, 320, 240, [1, 2, 3]);
    let mut floor_px = 0;
    for y in 0..240 {
        for x in 0..320 {
            if px(&img, x, y) == [200, 200, 200] {
                floor_px += 1;
            }
        }
    }
    assert!(floor_px > 2000, "floor visible from above, got {floor_px}");
}

fn le16(v: i16) -> [u8; 2] { v.to_le_bytes() }
fn le32(v: i32) -> [u8; 4] { v.to_le_bytes() }

/// A w x h solid patch (one post per column) with the given origin offsets.
fn sprite_patch(w: i16, h: i16, left: i16, top: i16, px: u8) -> Vec<u8> {
    let mut d = vec![];
    d.extend(le16(w)); d.extend(le16(h)); d.extend(le16(left)); d.extend(le16(top));
    let col = 3 + h as i32 + 2;
    for x in 0..w as i32 { d.extend(le32(8 + 4 * w as i32 + col * x)); }
    for _ in 0..w {
        d.extend([0, h as u8, 0]);
        d.extend(std::iter::repeat(px).take(h as usize));
        d.extend([0, 0xFF]);
    }
    d
}

fn gfx_with_sprite() -> GfxAssets {
    let mut w = Wad::new_pwad();
    w.entries.push(WadEntry::new("PLAYPAL", (0..256).flat_map(|i| [i as u8, i as u8, i as u8]).collect()));
    w.entries.push(WadEntry::new("F_START", vec![]));
    w.entries.push(WadEntry::new("FLOOR", vec![200; 4096]));
    w.entries.push(WadEntry::new("CEIL", vec![100; 4096]));
    w.entries.push(WadEntry::new("F_END", vec![]));
    w.entries.push(WadEntry::new("S_START", vec![]));
    w.entries.push(WadEntry::new("TROOA2A8", sprite_patch(32, 64, 16, 64, 250)));
    w.entries.push(WadEntry::new("S_END", vec![]));
    GfxAssets::from_wads(&[&w])
}

#[test]
fn sprite_lookup_falls_back_to_a_rotated_frame_and_keeps_offsets() {
    let g = gfx_with_sprite();
    let (im, l, t) = g.sprite_image("TROOA1").expect("A2A8 stands in for A1");
    assert_eq!((im.width, im.height, l, t), (32, 64, 16, 64));
    assert!(g.sprite_image("TROOB1").is_none(), "other frames are not substituted");
}

#[test]
fn things_are_drawn_as_centred_billboards_standing_on_the_floor() {
    let ed = room();
    let traps: Vec<_> = (0..ed.map.sectors.len()).map(|i| ed.map.sector_traps(i)).collect();
    let mut cache = TexCache::new();
    let cam = Camera { vx: 256, vy: 128, vz: -64, ox: 256, oy: 512, oz: -40, zoom: 2 };
    let g = gfx_with_sprite();
    let things = vec![(256, 300, "TROOA1".to_string())];
    let img = render(&ed.map, &traps, &things, &g, &mut cache, &cam, 320, 240, [1, 2, 3]);
    let (mut n, mut minx, mut maxx) = (0, 999usize, 0usize);
    for y in 0..240 {
        for x in 0..320 {
            if px(&img, x, y) == [250, 250, 250] {
                n += 1;
                minx = minx.min(x);
                maxx = maxx.max(x);
            }
        }
    }
    assert!(n > 300, "sprite pixels drawn: {n}");
    assert!(((minx + maxx) as i32 / 2 - 160).abs() <= 3, "centred: {minx}..{maxx}");
    let none = render(&ed.map, &traps, &[], &g, &mut cache, &cam, 320, 240, [1, 2, 3]);
    assert!((0..240 * 320).all(|i| px(&none, i % 320, i / 320) != [250, 250, 250]));
}

#[test]
fn clicking_picks_walls_floors_ceilings_and_things() {
    use doomed_core::render3d::{render_ids, Pick};
    let ed = room();
    let traps: Vec<_> = (0..ed.map.sectors.len()).map(|i| ed.map.sector_traps(i)).collect();
    let mut cache = TexCache::new();
    let cam = Camera { vx: 256, vy: 128, vz: -64, ox: 256, oy: 512, oz: -40, zoom: 2 };
    let g = gfx_with_sprite();
    let things = vec![(256, 300, "TROOA1".to_string())];
    let v = render_ids(&ed.map, &traps, &things, &g, &mut cache, &cam, 320, 240, [1, 2, 3]);
    assert_eq!(v.pick(160, 235), Some(Pick::Floor(0)));
    assert_eq!(v.pick(160, 3), Some(Pick::Ceiling(0)));
    let mut found = None;
    for y in 0..240 {
        if v.pick(160, y) == Some(Pick::Thing(0)) {
            found = Some(y);
        }
    }
    assert!(found.is_some(), "the sprite is pickable at the centre column");
    // the far wall is the linedef at y = 512
    let wall = (0..240).find_map(|y| match v.pick(40, y) { Some(Pick::Wall(n, side)) => Some((n, side)), _ => None }).expect("a wall");
    assert_eq!(wall.1, 0, "the room's walls are seen from their first side");
    let wall = wall.0;
    let l = ed.map.linedefs[wall];
    let (a, b) = (ed.map.vertexes[l.from as usize], ed.map.vertexes[l.to as usize]);
    assert!(a.y == 512 && b.y == 512, "picked the far wall");
    assert_eq!(v.pick(9999, 0), None);
}
