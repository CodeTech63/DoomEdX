use doomed_app::*;
use doomed_core::*;

const NONE: Mods = Mods { shift: false, ctrl: false };
const SHIFT: Mods = Mods { shift: true, ctrl: false };
const CTRL: Mods = Mods { shift: false, ctrl: true };
const BOTH: Mods = Mods { shift: true, ctrl: true };

fn pt(x: i32, y: i32) -> Point {
    Point::new(x, y)
}

fn ed() -> Editor {
    Editor::new(MapData::new("E1M1"))
}

/// Right-drag a rectangle in empty space, then make it a rectangular sector.
fn make_room(e: &mut Editor, a: (i32, i32), b: (i32, i32)) {
    e.tool = Kind::Sector;
    e.right_down(pt(a.0, a.1), NONE, 0);
    e.mouse_move(pt(b.0, b.1), NONE, 10);
    e.right_up(pt(b.0, b.1), NONE, 20);
    assert!(matches!(e.popup, Some(Popup::NewSector(_))), "popup was {:?}", e.popup);
    e.popup = None;
    assert!(e.create_sector(NewSector::Rectangular));
}

fn used_lines(e: &Editor) -> usize {
    e.map.linedef_flags.iter().filter(|f| f.used).count()
}

#[test]
fn right_drag_in_empty_space_offers_a_new_sector_on_the_grid() {
    let mut e = ed();
    e.tool = Kind::Sector;
    e.right_down(pt(3, 5), NONE, 0);
    assert_eq!(e.action, MouseAction::SelWindow);
    e.mouse_move(pt(133, 71), NONE, 10);
    // the rectangle snaps to the 16-unit grid
    assert_eq!(e.sel_rect, Rect { left: 0, right: 128, top: 64, bottom: 0 });
    e.right_up(pt(133, 71), NONE, 20);
    assert_eq!(e.popup, Some(Popup::NewSector(Rect { left: 0, right: 128, top: 64, bottom: 0 })));
    assert!(e.create_sector(NewSector::Rectangular));
    assert_eq!(used_lines(&e), 4);
}

#[test]
fn a_tiny_right_drag_offers_nothing() {
    let mut e = ed();
    e.tool = Kind::Sector;
    e.right_down(pt(0, 0), NONE, 0);
    e.mouse_move(pt(16, 0), NONE, 5);
    e.right_up(pt(16, 0), NONE, 6);
    assert_eq!(e.popup, None);
    assert_eq!(e.action, MouseAction::Normal);
}

#[test]
fn shift_makes_it_square_and_ctrl_centres_it() {
    let mut e = ed();
    e.tool = Kind::Sector;
    e.right_down(pt(0, 0), NONE, 0);
    e.mouse_move(pt(160, 64), BOTH, 5);
    assert_eq!(e.sel_rect, Rect { left: -160, right: 160, top: 160, bottom: -160 }, "centred square");
    e.mouse_move(pt(160, 64), CTRL, 6);
    assert_eq!(e.sel_rect, Rect { left: -160, right: 160, top: 64, bottom: -64 }, "centred");
    e.mouse_move(pt(160, 64), SHIFT, 7);
    assert_eq!(e.sel_rect.right - e.sel_rect.left, e.sel_rect.top - e.sel_rect.bottom, "square");
}

#[test]
fn click_selects_shift_click_toggles_and_empty_click_clears() {
    let mut e = ed();
    make_room(&mut e, (0, 0), (128, 128));
    make_room(&mut e, (512, 0), (640, 128));
    e.map.unselect_everything();
    e.left_down(pt(64, 64), NONE, 1000);
    e.left_up(pt(64, 64), NONE, 1010);
    assert_eq!(e.map.selected_count(Kind::Sector), 1);
    e.left_down(pt(576, 64), SHIFT, 2000);
    e.left_up(pt(576, 64), SHIFT, 2010);
    assert_eq!(e.map.selected_count(Kind::Sector), 2);
    e.left_down(pt(576, 64), SHIFT, 3000);
    e.left_up(pt(576, 64), SHIFT, 3010);
    assert_eq!(e.map.selected_count(Kind::Sector), 1, "shift-click toggles");
    e.left_down(pt(5000, 5000), NONE, 4000);
    e.left_up(pt(5000, 5000), NONE, 4010);
    assert_eq!(e.map.selected_count(Kind::Sector), 0);
}

#[test]
fn marquee_selects_inside_but_a_tiny_one_just_clears() {
    let mut e = ed();
    make_room(&mut e, (0, 0), (128, 128));
    e.map.unselect_everything();
    e.left_down(pt(-50, -50), NONE, 0);
    assert_eq!(e.action, MouseAction::SelWindow);
    e.mouse_move(pt(200, 200), NONE, 5);
    e.left_up(pt(200, 200), NONE, 6);
    assert_eq!(e.map.selected_count(Kind::Sector), 1);
    e.left_down(pt(-50, -50), SHIFT, 10);
    e.mouse_move(pt(-45, -45), SHIFT, 12);
    e.left_up(pt(-45, -45), SHIFT, 13);
    assert_eq!(e.map.selected_count(Kind::Sector), 0, "a small rectangle unselects all");
}

#[test]
fn a_sector_only_drags_after_the_time_out() {
    let mut e = ed();
    make_room(&mut e, (0, 0), (128, 128));
    e.map.unselect_everything();
    e.left_down(pt(64, 64), NONE, 1000);
    e.mouse_move(pt(200, 64), NONE, 1100); // too soon: still a click
    assert_eq!(e.action, MouseAction::Normal);
    e.mouse_move(pt(200, 64), NONE, 1600); // held long enough
    assert_eq!(e.action, MouseAction::MoveSector);
    e.mouse_move(pt(264, 64), NONE, 1650);
    e.left_up(pt(264, 64), NONE, 1700);
    assert_eq!(e.action, MouseAction::Normal);
    // started at (64,64)->grid (64,64); ended at grid (264,64)->(256,64): +192
    let xs: Vec<i16> = (0..e.map.vertexes.len()).filter(|&i| e.map.vertex_flags[i].used).map(|i| e.map.vertexes[i].x).collect();
    assert_eq!((*xs.iter().min().unwrap(), *xs.iter().max().unwrap()), (192, 320));
    assert_eq!(used_lines(&e), 4);
}

#[test]
fn sectors_dragged_together_join_and_dragged_apart_split_again() {
    let mut e = ed();
    make_room(&mut e, (0, 0), (128, 128));
    make_room(&mut e, (256, 0), (384, 128));
    assert_eq!(used_lines(&e), 8);
    // drag B (selected: it was made last) left until the walls coincide
    e.map.unselect_everything();
    e.left_down(pt(320, 64), NONE, 0);
    e.mouse_move(pt(256, 64), NONE, 600);
    e.mouse_move(pt(192, 64), NONE, 650);
    e.left_up(pt(192, 64), NONE, 700);
    let two_sided = (0..e.map.linedefs.len()).filter(|&i| e.map.linedef_flags[i].used && e.map.linedefs[i].two_sided()).count();
    assert_eq!(two_sided, 1, "the touching walls became one two-sided line");
    assert_eq!(used_lines(&e), 7);
    // and apart again: B is still selected
    e.left_down(pt(192, 64), NONE, 1000);
    e.mouse_move(pt(256, 64), NONE, 1600);
    e.mouse_move(pt(448, 64), NONE, 1650);
    e.left_up(pt(448, 64), NONE, 1700);
    assert_eq!(used_lines(&e), 8, "each room is closed again");
    assert_eq!((0..e.map.linedefs.len()).filter(|&i| e.map.linedef_flags[i].used && e.map.linedefs[i].two_sided()).count(), 0);
}

#[test]
fn right_click_with_the_thing_tool_places_and_drags_a_thing() {
    let mut e = ed();
    e.tool = Kind::Thing;
    e.right_down(pt(100, 100), NONE, 0);
    assert_eq!(e.action, MouseAction::MoveThing);
    assert_eq!((e.map.things[0].x, e.map.things[0].y), (96, 96), "placed on the grid");
    e.mouse_move(pt(164, 132), NONE, 5);
    e.right_up(pt(164, 132), NONE, 10);
    assert_eq!((e.map.things[0].x, e.map.things[0].y), (96 + 64, 96 + 32));
    assert_eq!(e.map.selected_count(Kind::Thing), 1);
    assert_eq!(e.action, MouseAction::Normal);
}

#[test]
fn vertex_tool_right_click_splits_a_line_and_drags_the_new_vertex() {
    let mut e = ed();
    make_room(&mut e, (0, 0), (128, 128));
    e.tool = Kind::Vertex;
    let before = used_lines(&e);
    e.right_down(pt(64, 0), NONE, 0); // on the bottom wall
    assert_eq!(e.action, MouseAction::MoveVertex);
    assert_eq!(used_lines(&e), before + 1);
    e.mouse_move(pt(64, -64), NONE, 5);
    e.right_up(pt(64, -64), NONE, 10);
    let v = (0..e.map.vertexes.len()).find(|&i| e.map.vertex_flags[i].used && e.map.vertexes[i].x == 64).expect("new vertex");
    assert_eq!(e.map.vertexes[v].y, -64);
}

#[test]
fn line_tool_right_click_near_a_vertex_rubber_bands_a_line_that_snaps() {
    let mut e = ed();
    make_room(&mut e, (0, 0), (128, 128));
    make_room(&mut e, (512, 0), (640, 128));
    e.map.unselect_everything();
    e.tool = Kind::LineDef;
    let before = used_lines(&e);
    e.right_down(pt(130, 126), NONE, 0); // near the (128,128) corner
    assert_eq!(e.action, MouseAction::MoveVertex);
    assert!(e.vertex_snap);
    e.mouse_move(pt(300, 100), NONE, 5);
    e.mouse_move(pt(510, 4), NONE, 10); // within reach of (512,0)
    e.right_up(pt(510, 4), NONE, 15);
    assert!(!e.vertex_snap);
    assert_eq!(used_lines(&e), before + 1);
    let l = (0..e.map.linedefs.len()).filter(|&i| e.map.linedef_flags[i].used).last().unwrap();
    let ln = e.map.linedefs[l];
    assert_eq!(e.map.vertexes[ln.to as usize], Vertex { x: 512, y: 0 });
    assert!(ln.two_sided() && ln.test_bit(line_bits::NOT_ON_MAP) && !ln.test_bit(line_bits::IMPASSABLE));
}

#[test]
fn zoom_window_sets_the_extent_and_zoom_prev_returns() {
    let mut e = ed();
    let before = e.view.extent;
    e.begin_zoom_window();
    e.left_down(pt(100, 100), NONE, 0);
    e.mouse_move(pt(500, 300), NONE, 5);
    e.left_up(pt(500, 300), NONE, 6);
    assert_eq!(e.view.extent, Rect { left: 100, right: 500, top: 300, bottom: 100 });
    assert_eq!(e.action, MouseAction::Normal);
    e.view.zoom_prev();
    assert_eq!(e.view.extent, before);
}

#[test]
fn delete_keys_pick_partial_or_full() {
    let mut e = ed();
    make_room(&mut e, (0, 0), (128, 128));
    assert_eq!(e.map.selected_count(Kind::Sector), 1);
    e.delete_key(true);
    assert_eq!(used_lines(&e), 0);
    assert!(e.map.sector_flags.iter().all(|f| !f.used));
}

#[test]
fn view_zoom_and_scroll_follow_scroll_cpp() {
    let mut v = View::new(Rect { left: -1000, right: 1000, top: 1000, bottom: -1000 });
    v.zoom_out();
    assert_eq!(v.extent, Rect { left: -1666, right: 1666, top: 1666, bottom: -1666 });
    let mut v = View::new(Rect { left: -1000, right: 1000, top: 1000, bottom: -1000 });
    v.zoom_in(pt(0, 0), 800.0, 800.0);
    assert_eq!(v.extent, Rect { left: -500, right: 500, top: 500, bottom: -500 });
    let mut v = View::new(Rect { left: -100, right: 100, top: 100, bottom: -100 });
    for _ in 0..10 {
        v.zoom_in(pt(0, 0), 800.0, 800.0);
    }
    assert!(v.extent.right - v.extent.left >= 64, "never narrower than 64");
    let mut v = View::new(Rect { left: 0, right: 1000, top: 1000, bottom: 0 });
    v.scroll_line(1, 0, 500.0, 500.0);
    assert_eq!(v.extent.left, 100);
    v.scroll_page(0, -1, 500.0, 500.0);
    assert_eq!(v.extent.top, 500);
}

#[test]
fn aspect_fit_widens_the_short_axis_and_maps_y_upward() {
    let v = View::new(Rect { left: 0, right: 100, top: 100, bottom: 0 });
    let s = v.on_screen(400.0, 200.0);
    assert_eq!((s.top, s.bottom), (100, 0));
    assert_eq!(s.right - s.left, 200);
    let (x, y) = v.to_screen(pt(s.left, s.top), 400.0, 200.0);
    assert_eq!((x, y), (0.0, 0.0), "top-left of the map is the top-left pixel");
    let back = v.to_map(200.0, 100.0, 400.0, 200.0);
    assert_eq!(back, pt(s.left + 100, 50));
}

#[test]
fn the_thing_table_is_complete() {
    assert_eq!(things::THINGS.len(), 120);
    assert_eq!(things::thing_info(2018).unwrap().name, "Armor: Green");
}

#[test]
fn sector_traps_cover_exact_area_including_holes() {
    use doomed_app::{Editor, NewSector};
    use doomed_core::Rect;
    let mut ed = Editor::new(doomed_core::MapData::new("E1M1"));
    ed.sel_rect = Rect { left: 0, right: 256, top: 256, bottom: 0 };
    ed.create_sector(NewSector::Rectangular);
    let area = |ed: &Editor, s: usize| -> f32 { ed.map.sector_traps(s).iter().map(|t| t.area()).sum() };
    assert_eq!(area(&ed, 0), 256.0 * 256.0);
    ed.sel_rect = Rect { left: 64, right: 128, top: 192, bottom: 64 };
    ed.create_sector(NewSector::Rectangular);
    let n = ed.map.sectors.len();
    let total: f32 = (0..n).map(|s| area(&ed, s)).sum();
    assert_eq!(total, 256.0 * 256.0 + 64.0 * 128.0, "outer sector keeps its hole only if the inner one is its own sector");
}
