//! DoomEd 4.0 editor front end: a headless [`Editor`] (the mouse/keyboard
//! state machine from `MOUSE.CPP`, `EDIT.CPP`) plus the egui shell in `app`.

pub mod app;
pub mod editor;
pub mod specials;
pub mod things;
pub mod view;

pub use editor::{Editor, Mods, MouseAction, NewSector, Popup};
pub use view::View;
