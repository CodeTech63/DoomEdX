#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]

use doomed_app::app::DoomEdApp;

fn main() -> eframe::Result<()> {
    let path = std::env::args().nth(1);
    let options = eframe::NativeOptions {
        viewport: eframe::egui::ViewportBuilder::default().with_inner_size([1100.0, 760.0]).with_title("DoomEd 4.0"),
        ..Default::default()
    };
    eframe::run_native("DoomEd", options, Box::new(move |_cc| Ok(Box::new(DoomEdApp::new_with_path(path.clone())))))
}
