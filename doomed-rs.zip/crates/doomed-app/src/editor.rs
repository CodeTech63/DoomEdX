//! The editing state machine: a port of `MOUSE.CPP` (plus the keyboard
//! commands of `EDIT.CPP`), with no windowing code in it. A front end feeds
//! it map-space mouse points and a clock; it mutates the [`MapData`].
//!
//! Differences from the original, all deliberate:
//! * Time is passed in (`now_ms`) so behaviour is testable. The drag time-out
//!   is the Windows double-click time, 500 ms by default.
//! * While a vertex is rubber-banded with Vertex Snap, the original could snap
//!   it to *itself* (it is among the vertexes `NearestVertex` considers) and
//!   freeze it; here moving vertexes are skipped.
//! * The original's right-button branch in `MA_NORMAL` is unreachable for
//!   every tool but Thing, where the same drag has already started; it is
//!   not ported.

use crate::view::View;
use doomed_core::structs::line_bits;
use doomed_core::*;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MouseAction {
    Normal,
    ZoomWindow,
    SelWindow,
    MoveThing,
    MoveSector,
    MoveVertex,
    MoveLineDef,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Mods {
    pub shift: bool,
    pub ctrl: bool,
}

/// Something the original would have popped up; the front end shows it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Popup {
    /// `PopupNewSector`: right-drag a rectangle in empty space.
    NewSector(Rect),
    /// `PopupSelectedObject`: right-click inside a sector.
    SelectedObject,
    /// Double-click: the property dialog for the current object.
    Properties(Kind, Option<usize>),
}

pub struct Editor {
    pub map: MapData,
    pub view: View,
    pub tool: Kind,
    pub grid_size: i32,
    pub action: MouseAction,
    pub doing_left: bool,
    pub doing_right: bool,
    pub captured: bool,
    pub might_move: bool,
    pub might_insert: bool,
    pub vertex_snap: bool,
    pub creating_sector: bool,
    pub start: Point,
    pub last: Point,
    pub current: Point,
    pub gridded: Point,
    pub sel_rect: Rect,
    pub down_time: u64,
    pub timeout_ms: u64,
    pub cur_thing: Option<usize>,
    pub cur_vertex: Option<usize>,
    pub cur_line: Option<usize>,
    pub cur_sector: Option<usize>,
    pub popup: Option<Popup>,
    pub message: String,
}

fn point_rect(p: Point) -> Rect {
    Rect { left: p.x, right: p.x, top: p.y, bottom: p.y }
}

impl Editor {
    pub fn new(mut map: MapData) -> Self {
        map.normalize_flags();
        let extent = map.map_extent().unwrap_or_else(View::empty_extent);
        Editor {
            map,
            view: View::new(extent),
            tool: Kind::Sector,
            grid_size: 16,
            action: MouseAction::Normal,
            doing_left: false,
            doing_right: false,
            captured: false,
            might_move: false,
            might_insert: false,
            vertex_snap: false,
            creating_sector: false,
            start: Point::default(),
            last: Point::default(),
            current: Point::default(),
            gridded: Point::default(),
            sel_rect: point_rect(Point::default()),
            down_time: 0,
            timeout_ms: 500,
            cur_thing: None,
            cur_vertex: None,
            cur_line: None,
            cur_sector: None,
            popup: None,
            message: String::new(),
        }
    }

    /// The `GetCurrent` macro: C integer division truncates toward zero, and
    /// so does Rust's, so negative coordinates grid exactly as they did.
    pub fn grid(&self, p: Point) -> Point {
        let g = self.grid_size.max(1);
        Point::new(p.x / g * g, p.y / g * g)
    }

    fn get_current(&mut self, p: Point) {
        self.current = p;
        self.gridded = self.grid(p);
    }

    fn hit(&self, p: Point) -> Option<usize> {
        match self.tool {
            Kind::Thing => self.map.nearest_thing(p),
            Kind::Vertex => self.map.nearest_vertex(p),
            Kind::LineDef => self.map.nearest_linedef(p),
            Kind::Sector => self.map.nearest_sector(p),
        }
    }

    fn set_current(&mut self, n: Option<usize>) {
        match self.tool {
            Kind::Thing => self.cur_thing = n,
            Kind::Vertex => self.cur_vertex = n,
            Kind::LineDef => self.cur_line = n,
            Kind::Sector => self.cur_sector = n,
        }
    }

    /// Switching tools (toolbar / menu): the original clears selections of
    /// the other kinds so only the active kind's selection shows.
    pub fn set_tool(&mut self, tool: Kind) {
        if self.tool != tool {
            self.tool = tool;
            self.cancel_drag();
        }
    }

    /// Abandon any drag or pending popup (after the map is replaced by undo).
    pub fn reset_interaction(&mut self) {
        self.cancel_drag();
        self.popup = None;
    }

    fn cancel_drag(&mut self) {
        self.action = MouseAction::Normal;
        self.captured = false;
        self.doing_left = false;
        self.doing_right = false;
        self.creating_sector = false;
        self.vertex_snap = false;
    }

    /// Zoom Window toolbar button.
    pub fn begin_zoom_window(&mut self) {
        self.view.previous = self.view.extent;
        self.action = MouseAction::ZoomWindow;
        self.message = "Use Mouse to outline a new viewing window:".into();
    }

    pub fn zoom_all(&mut self) {
        let all = self.map.map_extent().unwrap_or_else(View::empty_extent);
        self.view.zoom_all(all);
    }

    // ------------------------------------------------------------------
    // left button
    // ------------------------------------------------------------------

    pub fn left_down(&mut self, p: Point, mods: Mods, now_ms: u64) {
        if self.doing_right {
            return;
        }
        self.doing_left = true;
        self.down_time = now_ms;
        self.get_current(p);
        self.start = self.gridded;
        match self.action {
            MouseAction::Normal => {
                let n = self.hit(p);
                self.set_current(n);
                if self.tool == Kind::Thing {
                    if let Some(t) = n {
                        self.map.defaults.thing = self.map.things[t]; // DefThing
                    }
                }
                match n {
                    None => {
                        if !mods.shift {
                            self.map.unselect_all(self.tool);
                        }
                        self.start = p; // rectangles from the raw point
                        self.sel_rect = point_rect(p);
                        self.action = MouseAction::SelWindow;
                        self.message = match self.tool {
                            Kind::Thing => "Draw a rectangle enclosing the desired things",
                            Kind::Vertex => "Draw a rectangle enclosing the desired vertices",
                            Kind::LineDef => "Draw a rectangle enclosing the desired lines",
                            Kind::Sector => "Draw a rectangle enclosing the desired sectors",
                        }
                        .into();
                    }
                    Some(n) if mods.shift => {
                        self.map.select(self.tool, n);
                        self.might_move = false;
                    }
                    Some(n) => {
                        if !self.map.is_selected(self.tool, n) {
                            self.map.unselect_all(self.tool);
                            self.map.select(self.tool, n);
                        }
                        self.might_move = true;
                    }
                }
                self.captured = true;
            }
            MouseAction::ZoomWindow => {
                self.start = p;
                self.sel_rect = point_rect(p);
                self.captured = true;
            }
            _ => {}
        }
    }

    /// `DoomEdLDouble`: asks for the property dialog of the current object.
    pub fn left_double(&mut self) {
        let n = match self.tool {
            Kind::Thing => self.cur_thing,
            Kind::Vertex => self.cur_vertex,
            Kind::LineDef => self.cur_line,
            Kind::Sector => self.cur_sector,
        };
        if self.tool != Kind::Vertex {
            self.popup = Some(Popup::Properties(self.tool, n));
        }
    }

    pub fn left_up(&mut self, p: Point, _mods: Mods, now_ms: u64) {
        self.doing_left = false;
        self.button_up(p, now_ms);
    }

    /// The shared body of `DoomEdLButtonUp` (the right button calls it too).
    fn button_up(&mut self, p: Point, now_ms: u64) {
        if !self.captured {
            return;
        }
        self.get_current(p);
        self.captured = false;
        match self.action {
            MouseAction::MoveSector => {
                self.map.drop_sectors(self.current);
                self.map.process_joins();
                self.action = MouseAction::Normal;
                self.map.mark_nodes_dirty();
            }
            MouseAction::MoveLineDef => {
                self.map.process_joins();
                self.map.mark_nodes_dirty();
                self.action = MouseAction::Normal;
            }
            MouseAction::MoveVertex => {
                self.map.process_joins();
                self.vertex_snap = false;
                self.map.mark_nodes_dirty();
                self.action = MouseAction::Normal;
            }
            MouseAction::MoveThing => {
                self.map.mark_changed();
                self.action = MouseAction::Normal;
            }
            MouseAction::Normal => {
                if self.might_move && now_ms.saturating_sub(self.down_time) < self.timeout_ms {
                    self.might_move = false;
                }
            }
            MouseAction::SelWindow => {
                let r = self.sel_rect;
                self.message.clear();
                if (r.right - r.left).abs() + (r.bottom - r.top).abs() > 24 {
                    self.map.select_in_rect(self.tool, &r);
                } else {
                    self.map.unselect_all(self.tool);
                }
                self.action = MouseAction::Normal;
            }
            MouseAction::ZoomWindow => {
                self.action = MouseAction::Normal;
                self.message.clear();
                self.view.zoom_window(self.sel_rect);
            }
        }
    }

    // ------------------------------------------------------------------
    // right button
    // ------------------------------------------------------------------

    pub fn right_down(&mut self, p: Point, _mods: Mods, now_ms: u64) {
        if self.doing_left {
            return;
        }
        self.doing_right = true;
        self.down_time = now_ms;
        self.get_current(p);
        let g = self.gridded;
        match self.tool {
            Kind::Thing => {
                let t = self.map.thing_new();
                self.cur_thing = Some(t);
                self.map.things[t].x = g.x as i16;
                self.map.things[t].y = g.y as i16;
                self.map.unselect_all(Kind::Thing);
                self.map.select(Kind::Thing, t);
                self.action = MouseAction::MoveThing;
                self.last = g;
                self.captured = true;
            }
            Kind::Vertex => {
                if let Some(cl) = self.map.nearest_linedef(p) {
                    self.cur_line = Some(cl);
                    self.action = MouseAction::MoveVertex;
                    self.map.unselect_all(Kind::Vertex);
                    // break the line: a new vertex, a new line, new sidedefs
                    let newv = self.map.vertex_new().expect("vertex space");
                    self.map.vertexes[newv] = Vertex { x: g.x as i16, y: g.y as i16 };
                    self.map.vertex_flags[newv].selected = true;
                    let newl = self.map.linedef_new();
                    self.map.linedefs[newl] = self.map.linedefs[cl];
                    self.map.linedefs[newl].from = newv as i16;
                    self.map.linedefs[cl].to = newv as i16;
                    for side2 in [false, true] {
                        let old = if side2 { self.map.linedefs[cl].sidedef2 } else { self.map.linedefs[cl].sidedef1 };
                        if old != NOTHING {
                            let nsd = self.map.sidedef_new();
                            self.map.sidedefs[nsd] = self.map.sidedefs[old as usize];
                            if side2 {
                                self.map.linedefs[newl].sidedef2 = nsd as i16;
                            } else {
                                self.map.linedefs[newl].sidedef1 = nsd as i16;
                            }
                        }
                    }
                    self.map.clear_moving();
                    self.map.vertex_flags[newv].moving = true;
                    self.map.linedef_flags[newl].moving = true;
                    self.map.linedef_flags[cl].moving = true;
                    self.last = g;
                    self.captured = true;
                }
            }
            Kind::LineDef => {
                if let Some(v) = self.map.nearest_vertex(p) {
                    self.cur_vertex = Some(v);
                    self.action = MouseAction::MoveVertex;
                    self.map.unselect_all(Kind::LineDef);
                    self.cur_sector = None;
                    self.map.clear_moving();
                    let newl = self.map.linedef_new();
                    self.cur_line = Some(newl);
                    self.map.linedef_flags[newl].moving = true;
                    let (s1, s2) = (self.map.sidedef_new(), self.map.sidedef_new());
                    let ln = &mut self.map.linedefs[newl];
                    ln.sidedef1 = s1 as i16;
                    ln.sidedef2 = s2 as i16;
                    ln.set_bit(line_bits::TWO_SIDED); // two sides, both blank
                    ln.set_bit(line_bits::NOT_ON_MAP); // not visible on the map
                    ln.clear_bit(line_bits::IMPASSABLE); // not blocking
                    ln.from = v as i16;
                    let newv = self.map.vertex_new().expect("vertex space");
                    self.map.vertex_flags[newv].moving = true;
                    self.map.vertexes[newv] = Vertex { x: g.x as i16, y: g.y as i16 };
                    self.map.vertex_flags[newv].selected = true;
                    self.map.linedefs[newl].to = newv as i16;
                    self.vertex_snap = true;
                    self.last = g;
                    self.captured = true;
                }
            }
            Kind::Sector => {
                self.cur_sector = self.map.nearest_sector(p);
                match self.cur_sector {
                    None => {
                        self.start = g;
                        self.sel_rect = point_rect(g);
                        self.action = MouseAction::SelWindow;
                        self.message = "Stretch out the extent of a new sector (try Shift & Ctrl)".into();
                        self.creating_sector = true;
                        self.captured = true;
                    }
                    Some(s) => {
                        if !self.map.sector_selected(s) {
                            self.map.select(Kind::Sector, s);
                        }
                        self.might_insert = true;
                    }
                }
            }
        }
    }

    pub fn right_up(&mut self, p: Point, mods: Mods, now_ms: u64) {
        self.doing_right = false;
        match self.action {
            MouseAction::MoveVertex | MouseAction::MoveThing => {
                let _ = mods;
                self.button_up(p, now_ms);
            }
            MouseAction::SelWindow => {
                self.captured = false;
                self.creating_sector = false;
                let r = self.sel_rect;
                if (r.right - r.left).abs() + (r.bottom - r.top).abs() > 24 {
                    self.popup = Some(Popup::NewSector(r));
                }
                self.might_insert = false;
                self.map.process_joins();
                self.action = MouseAction::Normal;
                self.message.clear();
            }
            MouseAction::Normal => {
                if self.tool == Kind::Sector && self.cur_sector.is_some() {
                    self.popup = Some(Popup::SelectedObject);
                }
            }
            _ => {}
        }
    }

    // ------------------------------------------------------------------
    // movement
    // ------------------------------------------------------------------

    /// Nearest unused-or-not-moving vertex, for Vertex Snap.
    fn snap_target(&self, mouse: Point) -> Option<usize> {
        let mut best: Option<(usize, i32)> = None;
        for (i, v) in self.map.vertexes.iter().enumerate() {
            let f = self.map.vertex_flags[i];
            if !f.used || f.moving {
                continue;
            }
            let d = hypotenuse(mouse, Point::new(v.x as i32, v.y as i32));
            if d <= 64 && best.map_or(true, |b| d < b.1) {
                best = Some((i, d));
            }
        }
        best.map(|b| b.0)
    }

    fn moving_vertexes(&self) -> Vec<usize> {
        (0..self.map.vertexes.len()).filter(|&i| self.map.vertex_flags[i].used && self.map.vertex_flags[i].moving).collect()
    }

    fn offset_moving(&mut self, dx: i32, dy: i32) {
        for i in self.moving_vertexes() {
            let v = &mut self.map.vertexes[i];
            v.x = v.x.wrapping_add(dx as i16);
            v.y = v.y.wrapping_add(dy as i16);
        }
    }

    pub fn mouse_move(&mut self, p: Point, mods: Mods, now_ms: u64) {
        self.get_current(p);
        if !self.captured {
            return;
        }
        match self.action {
            MouseAction::ZoomWindow | MouseAction::SelWindow => self.move_rect(mods),
            MouseAction::MoveVertex | MouseAction::MoveSector | MouseAction::MoveLineDef => {
                let (dx, dy) = (self.gridded.x - self.last.x, self.gridded.y - self.last.y);
                for i in self.moving_vertexes() {
                    if self.vertex_snap {
                        let target = self.snap_target(self.current);
                        if self.cur_sector.is_none() {
                            self.cur_sector = self.map.nearest_sector(self.current);
                        }
                        match target {
                            None => self.map.vertexes[i] = Vertex { x: self.gridded.x as i16, y: self.gridded.y as i16 },
                            Some(t) => {
                                self.map.vertexes[i] = self.map.vertexes[t];
                                if let (Some(s), Some(l)) = (self.cur_sector, self.cur_line) {
                                    // adding a line inside a sector: both sides are that sector
                                    let (a, b) = (self.map.linedefs[l].sidedef1, self.map.linedefs[l].sidedef2);
                                    for sd in [a, b] {
                                        if sd != NOTHING {
                                            self.map.sidedefs[sd as usize].sector = s as i16;
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        let v = &mut self.map.vertexes[i];
                        v.x = v.x.wrapping_add(dx as i16);
                        v.y = v.y.wrapping_add(dy as i16);
                    }
                }
            }
            MouseAction::MoveThing => {
                let (dx, dy) = (self.gridded.x - self.last.x, self.gridded.y - self.last.y);
                for i in 0..self.map.things.len() {
                    let f = self.map.thing_flags[i];
                    if f.used && f.selected {
                        let t = &mut self.map.things[i];
                        t.x = t.x.wrapping_add(dx as i16);
                        t.y = t.y.wrapping_add(dy as i16);
                    }
                }
            }
            MouseAction::Normal => {
                if self.doing_left && now_ms.saturating_sub(self.down_time) > self.timeout_ms {
                    self.start_drag(mods);
                    return; // the original returns here too
                }
            }
        }
        self.last = self.gridded;
    }

    fn move_rect(&mut self, mods: Mods) {
        let (s, mut g, c) = (self.start, self.gridded, self.current);
        if self.creating_sector {
            let (dx, dy) = ((g.x - s.x).abs(), (g.y - s.y).abs());
            let from_corners = |a: Point, b: Point| Rect {
                top: a.y.max(b.y),
                left: a.x.min(b.x),
                right: a.x.max(b.x),
                bottom: a.y.min(b.y),
            };
            self.sel_rect = from_corners(s, g);
            if mods.shift && mods.ctrl {
                let d = dx.max(dy);
                self.sel_rect = Rect { top: s.y + d, left: s.x - d, right: s.x + d, bottom: s.y - d };
            } else {
                if mods.shift {
                    if dy > dx {
                        g.x = s.x + (s.y - g.y);
                    } else {
                        g.y = s.y + (s.x - g.x);
                    }
                    self.sel_rect = from_corners(s, g);
                }
                if mods.ctrl {
                    self.sel_rect = Rect { top: s.y + dy, left: s.x - dx, right: s.x + dx, bottom: s.y - dy };
                }
            }
        } else {
            self.sel_rect = Rect { top: s.y.max(c.y), left: s.x.min(c.x), right: s.x.max(c.x), bottom: s.y.min(c.y) };
        }
    }

    /// The button has been held past the time-out and the mouse moved:
    /// start dragging whatever is selected.
    fn start_drag(&mut self, mods: Mods) {
        let g = self.gridded;
        let gs = self.grid_size.max(1);
        let (dx, dy) = (g.x - self.start.x, g.y - self.start.y);
        match self.tool {
            Kind::Thing => {
                self.action = MouseAction::MoveThing;
                for i in 0..self.map.things.len() {
                    let f = self.map.thing_flags[i];
                    if f.used && f.selected {
                        let t = &mut self.map.things[i];
                        t.x = (t.x as i32 / gs * gs + dx) as i16;
                        t.y = (t.y as i32 / gs * gs + dy) as i16;
                    }
                }
            }
            Kind::Vertex => {
                self.action = MouseAction::MoveVertex;
                self.map.clear_moving();
                for i in 0..self.map.vertexes.len() {
                    let f = self.map.vertex_flags[i];
                    self.map.vertex_flags[i].moving = f.selected && f.used;
                }
                for i in 0..self.map.linedefs.len() {
                    if self.map.linedef_flags[i].used {
                        let l = self.map.linedefs[i];
                        let sel = |v: i16| self.map.vertex_flags.get(v as usize).map_or(false, |f| f.selected);
                        if sel(l.from) || sel(l.to) {
                            self.map.linedef_flags[i].moving = true;
                        }
                    }
                }
                for i in self.moving_vertexes() {
                    let v = &mut self.map.vertexes[i];
                    v.x = (v.x as i32 / gs * gs) as i16;
                    v.y = (v.y as i32 / gs * gs) as i16;
                }
                self.offset_moving(dx, dy);
            }
            Kind::LineDef => {
                self.action = MouseAction::MoveLineDef;
                self.map.clear_moving();
                for i in 0..self.map.linedefs.len() {
                    let f = self.map.linedef_flags[i];
                    if f.used && f.selected {
                        self.map.make_line_moving(i);
                    }
                }
                self.offset_moving(dx, dy);
            }
            Kind::Sector => {
                self.action = MouseAction::MoveSector;
                if mods.shift {
                    self.map.extract_sectors();
                } else {
                    self.map.detach_sectors();
                }
                self.offset_moving(dx, dy);
            }
        }
        self.last = g;
    }

    // ------------------------------------------------------------------
    // commands (menu / keyboard)
    // ------------------------------------------------------------------

    /// Del = partial delete, Shift+Del = full delete (see `EDIT.CPP`: the
    /// original's menu captions were the other way round).
    pub fn delete_key(&mut self, shift: bool) {
        if shift {
            self.map.delete_selected(self.tool);
        } else {
            self.map.partial_delete_selected(self.tool);
        }
        self.map.find_vertexes_in_use();
        self.map.mark_changed();
    }

    /// Builds the sector chosen from the New Sector popup.
    pub fn create_sector(&mut self, shape: NewSector) -> bool {
        let r = self.sel_rect;
        let ok = match shape {
            NewSector::Rectangular => {
                self.map.add_rect_sector(&r);
                true
            }
            NewSector::Polygon(n) => self.map.add_polygon_sector(&r, n).is_some(),
            NewSector::Star => {
                self.map.add_star_sector(&r);
                true
            }
            NewSector::Steps(p) => self.map.add_steps(&r, &p).is_ok(),
        };
        if ok {
            self.map.mark_nodes_dirty();
        }
        ok
    }
}

#[derive(Debug, Clone)]
pub enum NewSector {
    Rectangular,
    Polygon(u32),
    Star,
    Steps(StepsParams),
}
