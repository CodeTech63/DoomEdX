//! The egui shell: menus, toolbar, the map canvas (drawn the way `PAINT.CPP`
//! draws it), property panels and the dialogs that stand in for the original's
//! Win16 dialog boxes.

use crate::editor::{Editor, Mods, MouseAction, NewSector, Popup};
use crate::specials::{line_action_name, LINE_ACTIONS, LINE_FLAGS, SECTOR_SPECIALS};
use crate::things::{thing_info, THINGS};
use doomed_core::preview3d::{self, Camera, Panel};
use doomed_core::settings;
use doomed_core::structs::line_bits;
use doomed_core::*;
use eframe::egui::{self, Color32, Pos2, Rect as ERect, Shape, Stroke, Vec2};

/// The map colours (from the INI's `[Colors]`; COLORREF is 0x00BBGGRR).
/// A save running on a worker thread: packing, blockmap, reject and node
/// building can take a long time on a large map.
struct SaveJob {
    path: String,
    started: std::time::Instant,
    wad: Wad,
    rx: std::sync::mpsc::Receiver<(MapData, Result<PrepareOutcome, PrepareError>)>,
}

/// The system "Save As" dialog. `Some(Some(path))` = chosen, `Some(None)` =
/// cancelled, `None` = no system dialog on this platform (use the built-in one).
#[cfg(windows)]
fn native_save_dialog(suggested: &str) -> Option<Option<String>> {
    let p = std::path::Path::new(suggested);
    let mut d = rfd::FileDialog::new().set_title("Save As").add_filter("WAD files", &["wad", "WAD"]).add_filter("All files", &["*"]);
    if let Some(dir) = p.parent().filter(|d| d.is_dir()) {
        d = d.set_directory(dir);
    }
    if let Some(name) = p.file_name() {
        d = d.set_file_name(name.to_string_lossy());
    }
    Some(d.save_file().map(|f| {
        let mut f = f;
        if f.extension().is_none() {
            f.set_extension("wad");
        }
        f.to_string_lossy().into_owned()
    }))
}

/// The system "Open" dialog; same return convention as [`native_save_dialog`].
#[cfg(windows)]
fn native_open_dialog(title: &str, current: &str) -> Option<Option<String>> {
    let p = std::path::Path::new(current);
    let mut d = rfd::FileDialog::new().set_title(title).add_filter("WAD files", &["wad", "WAD"]).add_filter("All files", &["*"]);
    if let Some(dir) = p.parent().filter(|d| d.is_dir()) {
        d = d.set_directory(dir);
    }
    Some(d.pick_file().map(|f| f.to_string_lossy().into_owned()))
}

#[cfg(not(windows))]
fn native_open_dialog(_title: &str, _current: &str) -> Option<Option<String>> {
    None
}

#[cfg(not(windows))]
fn native_save_dialog(_suggested: &str) -> Option<Option<String>> {
    None
}

/// Attributes saved by a right click in the 3D view.
#[derive(Clone, Debug)]
enum AttrClip {
    /// A wall: the clicked side's sidedef; only its three textures are pasted.
    Wall { side: SideDef },
    /// A sector; only its floor and ceiling textures are pasted.
    Sector(Sector),
}

/// How many edits can be undone.
pub const UNDO_LEVELS: usize = 20;

/// What the 2D view paints inside sectors.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum FillMode {
    Off,
    Floor,
    Ceiling,
    Light,
}

#[derive(Clone, Copy)]
struct Pal {
    background: Color32,
    map_lines: Color32,
    inner_lines: Color32,
    selected: Color32,
    marked: Color32,
    grid: Color32,
    user_grid: Color32,
    axis: Color32,
}

fn cr(c: u32) -> Color32 {
    let (r, g, b) = settings::colorref_rgb(c);
    Color32::from_rgb(r, g, b)
}

impl Pal {
    fn from(c: &Colors) -> Pal {
        Pal {
            background: cr(c.background),
            map_lines: cr(c.map_lines),
            inner_lines: cr(c.map_inner_lines),
            selected: cr(c.selected),
            marked: cr(c.marked),
            grid: cr(c.grid),
            user_grid: cr(c.user_grid),
            axis: Color32::from_rgb(0, 0, 192),
        }
    }
}

#[derive(Default)]
enum Dialog {
    #[default]
    None,
    OpenWad(String),
    OpenIwad(String),
    SaveAs(String),
    NewMap(String),
    Maps,
    Search,
    Replace,
    Options(Box<(Options, Colors)>),
    Styles { sel: Option<usize>, edit: Option<(Option<usize>, Style)> },
    SectorDefaults { wall: String, floor: String, ceil: String, bottom: i32, top: i32, light: i32, pre: Option<usize> },
    Builders { sel: Option<usize>, edit: Option<(Option<usize>, Builder)> },
    ExportDwd(String),
    Platforms { sel: Option<usize>, edit: Option<(Option<usize>, Tag)> },
    Stats(Vec<(&'static str, String)>),
    ConfirmQuit,
    Directory { filter: String, selected: Option<usize> },
    SaveOptions,
    Check(Vec<Problem>),
    Polygon(u32),
    Steps(StepsState),
    RotateScale { x: i32, y: i32, deg: i32 },
    About,
}

/// What a texture/flat picker will write its choice into.
#[derive(Clone, Copy, PartialEq, Eq)]
enum PickTarget {
    Floor,
    Ceil,
    Upper(i16),
    Lower(i16),
    Middle(i16),
    Find(bool),
    Replace(bool),
    /// writes into `pick_result` for whichever dialog is open
    Slot(u8, bool),
}

impl PickTarget {
    fn is_flat(self) -> bool {
        matches!(self, PickTarget::Floor | PickTarget::Ceil | PickTarget::Find(true) | PickTarget::Replace(true) | PickTarget::Slot(_, true))
    }
}

struct StepsState {
    low: i16,
    step: i16,
    num: i16,
    dir: Direction,
    texture: String,
}

impl Default for StepsState {
    fn default() -> Self {
        StepsState { low: 0, step: 8, num: 8, dir: Direction::East, texture: "STEP4".into() }
    }
}

struct Preview {
    cam: Camera,
    hidden: bool,
    textured: bool,
    things: bool,
    panels: Vec<Panel>,
    tex: Option<egui::TextureHandle>,
    tex_key: u64,
    wheel: f32,
    sig: u64,
    /// what the last textured render showed at every pixel (for click selection)
    view: Option<doomed_core::render3d::View3d>,
    /// slice index given to the renderer -> map thing number
    thing_ids: Vec<usize>,
}

pub struct DoomEdApp {
    preview: Option<Preview>,
    pub ed: Editor,
    wad: Option<Wad>,
    wad_path: Option<String>,
    names: NameSets,
    iwad: Option<Wad>,
    gfx: GfxAssets,
    cache: std::collections::HashMap<String, Option<egui::TextureHandle>>,
    picker: Option<(PickTarget, String)>,
    pick_result: Option<(u8, String)>,
    wheel_acc: f32,
    fill_mode: FillMode,
    attr_clip: Option<AttrClip>,
    /// right click in the 3D view waiting to be applied: (what was hit, paste?)
    pending_attr: Option<(doomed_core::render3d::Pick, bool)>,
    job: Option<SaveJob>,
    history: doomed_core::UndoStack,
    /// a click in the 3D view waiting to be applied to the editor: (kind, number, shift)
    pending_3d: Option<(Kind, usize, bool)>,
    /// false = 2D map editor (the default), true = 3D view in the same pane
    view3d: bool,
    /// which of All / Window / Prev was used last (the highlighted 2D button)
    view2d_btn: usize,
    rename: Option<(usize, String)>,
    tex3d: doomed_core::TexCache,
    floor_tex: std::collections::HashMap<String, Option<egui::TextureHandle>>,
    fill_key: u64,
    fill: Vec<Vec<doomed_core::sectorfill::Trap>>,
    dir_path: String,
    find: String,
    repl: String,
    find_thing: i16,
    repl_thing: i16,
    iwad_name: Option<String>,
    dialog: Dialog,
    save: SaveOptions,
    pub settings: Settings,
    pal: Pal,
    ini_path: Option<std::path::PathBuf>,
    ini_text: String,
    confirmed_quit: bool,
    status: String,
    canvas: (f32, f32),
}

impl Default for DoomEdApp {
    fn default() -> Self {
        let mut map = MapData::new("E1M1");
        map.edited = false;
        let map_for_history = map.clone();
        DoomEdApp {
            preview: None,
            ed: Editor::new(map),
            wad: None,
            wad_path: None,
            names: NameSets::default(),
            iwad: None,
            gfx: GfxAssets::default(),
            cache: Default::default(),
            picker: None,
            pick_result: None,
            wheel_acc: 0.0,
            fill_mode: FillMode::Floor,
            attr_clip: None,
            pending_attr: None,
            job: None,
            history: {
                let mut h = doomed_core::UndoStack::new(UNDO_LEVELS);
                h.reset(&map_for_history);
                h
            },
            pending_3d: None,
            view3d: false,
            view2d_btn: 0,
            rename: None,
            tex3d: Default::default(),
            floor_tex: Default::default(),
            fill_key: 0,
            fill: Vec::new(),
            dir_path: String::new(),
            find: String::new(),
            repl: String::new(),
            find_thing: 0,
            repl_thing: 0,
            iwad_name: None,
            dialog: Dialog::None,
            save: SaveOptions::default(),
            settings: Settings::default(),
            pal: Pal::from(&Colors::default()),
            ini_path: None,
            ini_text: String::new(),
            confirmed_quit: false,
            status: "Welcome to DoomEd. File > Open to load a WAD.".into(),
            canvas: (800.0, 600.0),
        }
    }
}

/// Sector attribute drop-down (value = list index, as in the original).
fn sector_special_combo(ui: &mut egui::Ui, v: &mut i16) -> bool {
    let cur = SECTOR_SPECIALS.get(*v as usize).map(|s| s.to_string()).unwrap_or_else(|| format!("{} - unknown", v));
    let mut changed = false;
    ui.horizontal(|ui| {
        ui.label("Special");
        egui::ComboBox::from_id_salt("secspecial").selected_text(cur).width(170.0).show_ui(ui, |ui| {
            for (i, n) in SECTOR_SPECIALS.iter().enumerate() {
                changed |= ui.selectable_value(v, i as i16, *n).changed();
            }
        });
    });
    changed
}

/// Linedef action drop-down, sorted by name with "- Normal -" first.
fn line_action_combo(ui: &mut egui::Ui, v: &mut i16) -> bool {
    let cur = line_action_name(*v).map(String::from).unwrap_or_else(|| format!("{v} - unknown"));
    let mut changed = false;
    ui.horizontal(|ui| {
        ui.label("Action");
        egui::ComboBox::from_id_salt("lineaction").selected_text(cur).width(170.0).show_ui(ui, |ui| {
            let mut list: Vec<&(i16, &str)> = LINE_ACTIONS.iter().collect();
            list.sort_by_key(|a| a.1);
            for (n, name) in list {
                changed |= ui.selectable_value(v, *n, *name).changed();
            }
        });
    });
    changed
}

/// Platform (tag) drop-down, plus the raw number.
fn tag_combo(ui: &mut egui::Ui, tags: &[Tag], v: &mut i16) -> bool {
    let cur = tags.iter().find(|t| t.num == *v).map(|t| format!("{} - {}", t.name, t.desc)).unwrap_or_else(|| v.to_string());
    let mut changed = false;
    ui.horizontal(|ui| {
        ui.label("Tag");
        egui::ComboBox::from_id_salt("tagcombo").selected_text(cur).width(150.0).show_ui(ui, |ui| {
            for t in tags {
                changed |= ui.selectable_value(v, t.num, format!("{} - {}", t.name, t.desc)).changed();
            }
        });
        let mut x = *v as i32;
        if ui.add(egui::DragValue::new(&mut x).range(0..=32767)).changed() {
            *v = x as i16;
            changed = true;
        }
    });
    changed
}

fn ini_location() -> Option<std::path::PathBuf> {
    let exe = std::env::current_exe().ok()?;
    Some(exe.parent()?.join("DOOMED40.INI"))
}

fn name_str(n: &[u8; 8]) -> String {
    let end = n.iter().position(|&c| c == 0).unwrap_or(8);
    n[..end].iter().map(|&c| c as char).collect()
}

/// A texture/flat name field with a thumbnail and a "..." picker button.
/// Returns (text changed, picker requested).
fn asset_row(
    ui: &mut egui::Ui,
    label: &str,
    n: &mut [u8; 8],
    gfx: &GfxAssets,
    cache: &mut std::collections::HashMap<String, Option<egui::TextureHandle>>,
    flat: bool,
) -> (bool, bool) {
    let (mut changed, mut pick) = (false, false);
    let mut s = name_str(n);
    ui.horizontal(|ui| {
        ui.label(label);
        if ui.add(egui::TextEdit::singleline(&mut s).desired_width(72.0)).changed() {
            *n = to_name8(&s.to_uppercase());
            changed = true;
        }
        pick = ui.small_button("...").clicked();
        thumb(ui, gfx, cache, &name_str(n), flat, 32.0);
    });
    (changed, pick)
}

/// Draws `name` as a picture no larger than `max` pixels (a grey box if the
/// asset isn't loaded; nothing for "-").
/// The cached egui texture of a wall texture or flat, loading it on first use.
fn thumb_texture(
    ui: &egui::Ui,
    gfx: &GfxAssets,
    cache: &mut std::collections::HashMap<String, Option<egui::TextureHandle>>,
    name: &str,
    flat: bool,
) -> Option<egui::TextureHandle> {
    let key = format!("{}:{}", if flat { 'F' } else { 'T' }, name.to_uppercase());
    if !cache.contains_key(&key) {
        let img = if flat { gfx.flat_image(name) } else { gfx.texture_image(name) };
        let tex = img.map(|i| {
            let ci = egui::ColorImage::from_rgba_unmultiplied([i.width, i.height], &i.rgba);
            ui.ctx().load_texture(&key, ci, egui::TextureOptions::NEAREST)
        });
        cache.insert(key.clone(), tex);
    }
    cache[&key].clone()
}

/// One cell of the texture picker: the picture with its name below. The whole
/// cell is the button. Returns true when clicked.
fn picker_cell(
    ui: &mut egui::Ui,
    gfx: &GfxAssets,
    cache: &mut std::collections::HashMap<String, Option<egui::TextureHandle>>,
    name: &str,
    flat: bool,
) -> bool {
    const W: f32 = 88.0;
    const H: f32 = 100.0;
    const IMG: f32 = 80.0;
    let (rect, resp) = ui.allocate_exact_size(Vec2::new(W, H), egui::Sense::click());
    let p = ui.painter_at(rect);
    if resp.hovered() {
        p.rect_filled(rect, 3.0, ui.visuals().widgets.hovered.bg_fill);
        p.rect_stroke(rect, 3.0, ui.visuals().widgets.hovered.bg_stroke);
    }
    let img_box = ERect::from_min_size(rect.min + Vec2::new((W - IMG) / 2.0, 3.0), Vec2::splat(IMG));
    if name == "-" || name.is_empty() {
        p.text(img_box.center(), egui::Align2::CENTER_CENTER, "none", egui::FontId::proportional(13.0), ui.visuals().weak_text_color());
    } else if let Some(t) = thumb_texture(ui, gfx, cache, name, flat) {
        let sz = t.size_vec2();
        let k = (IMG / sz.x).min(IMG / sz.y);
        let r = ERect::from_center_size(img_box.center(), sz * k);
        p.image(t.id(), r, ERect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE);
    } else {
        p.rect_stroke(img_box.shrink(24.0), 0.0, Stroke::new(1.0, Color32::DARK_GRAY));
    }
    p.text(
        egui::pos2(rect.center().x, rect.bottom() - 9.0),
        egui::Align2::CENTER_CENTER,
        name,
        egui::FontId::monospace(11.0),
        ui.visuals().text_color(),
    );
    resp.on_hover_text(name).clicked()
}

fn thumb(
    ui: &mut egui::Ui,
    gfx: &GfxAssets,
    cache: &mut std::collections::HashMap<String, Option<egui::TextureHandle>>,
    name: &str,
    flat: bool,
    max: f32,
) {
    if name.is_empty() || name == "-" {
        return;
    }
    let tex = thumb_texture(ui, gfx, cache, name, flat);
    match &tex {
        Some(t) => {
            let sz = t.size_vec2();
            let k = (max / sz.x).min(max / sz.y);
            ui.image((t.id(), sz * k));
        }
        None => {
            let (r, _) = ui.allocate_exact_size(Vec2::splat(max.min(16.0)), egui::Sense::hover());
            ui.painter().rect_stroke(r, 0.0, Stroke::new(1.0, Color32::DARK_GRAY));
        }
    }
}

fn num_edit(ui: &mut egui::Ui, label: &str, v: &mut i16) -> bool {
    let mut x = *v as i32;
    let mut changed = false;
    ui.horizontal(|ui| {
        ui.label(label);
        changed = ui.add(egui::DragValue::new(&mut x).range(-32768..=32767)).changed();
    });
    *v = x as i16;
    changed
}

impl DoomEdApp {
    pub fn new_with_path(path: Option<String>) -> Self {
        let mut a = DoomEdApp::default();
        if let Some(p) = ini_location() {
            a.load_settings(p);
        }
        let saved = a.settings.iwad.clone();
        if !saved.is_empty() && std::path::Path::new(&saved).is_file() {
            a.open_iwad(&saved);
        }
        match path {
            Some(p) => a.open_wad(&p),
            None => {
                // the original always reloads the most recent file
                let r = a.settings.recent_files[0].clone();
                if a.settings.options.auto_load_most_recent && !r.is_empty() && std::path::Path::new(&r).exists() {
                    a.open_wad(&r);
                }
            }
        }
        a
    }

    /// Reads the INI (a missing or unreadable file just means defaults).
    pub fn load_settings(&mut self, path: std::path::PathBuf) {
        self.ini_text = std::fs::read_to_string(&path).unwrap_or_default();
        self.settings = Settings::from_text(&self.ini_text);
        self.ini_path = Some(path);
        self.apply_settings();
    }

    /// Pushes `settings` into the live editor.
    pub fn apply_settings(&mut self) {
        self.pal = Pal::from(&self.settings.colors);
        self.ed.grid_size = self.settings.options.grid_size;
        self.save = self.settings.save_options();
        self.ed.map.defaults = self.settings.defaults();
    }

    /// `QUIT.CPP`'s INI writing.
    pub fn save_settings(&mut self) {
        let o = &mut self.settings.options;
        o.grid_size = self.ed.grid_size;
        o.node_builder = match self.save.node_action {
            NodeAction::None => 1,
            NodeAction::Internal => 2,
            NodeAction::External => 3,
            NodeAction::IdBsp => 4,
        };
        o.reject_builder = if self.save.reject_method == RejectMethod::Quick { 1 } else { 2 };
        if let Some(p) = self.ini_path.clone() {
            let text = self.settings.to_text(Some(&self.ini_text));
            if std::fs::write(&p, &text).is_ok() {
                self.ini_text = text;
            }
        }
    }

    /// Makes `map` the current map, with the INI's default sector, wall and thing.
    /// Record the map as an undo step if it changed since the last idle
    /// moment. Nothing is recorded while a mouse button is held or text is
    /// being typed, so a whole drag or typed value is one step.
    fn commit_history(&mut self, ctx: &egui::Context) {
        let busy = ctx.input(|i| i.pointer.any_down()) || ctx.wants_keyboard_input() || self.ed.action != MouseAction::Normal || self.ed.captured;
        if !busy {
            self.history.commit_if_changed(&self.ed.map);
        }
    }

    fn do_undo(&mut self) {
        if self.history.undo(&mut self.ed.map) {
            self.ed.reset_interaction();
            self.status = format!("Undo ({} more)", self.history.undo_len());
        } else {
            self.status = "Nothing to undo".into();
        }
    }

    fn do_redo(&mut self) {
        if self.history.redo(&mut self.ed.map) {
            self.ed.reset_interaction();
            self.status = format!("Redo ({} more)", self.history.redo_len());
        } else {
            self.status = "Nothing to redo".into();
        }
    }

    #[doc(hidden)]
    pub fn undo_for_test(&mut self) -> bool {
        let n = self.history.undo_len();
        self.do_undo();
        self.history.undo_len() < n
    }

    #[doc(hidden)]
    pub fn commit_for_test(&mut self) {
        self.history.commit_if_changed(&self.ed.map);
    }

    fn install_map(&mut self, mut map: MapData) {
        map.defaults = self.settings.defaults();
        self.ed = Editor::new(map);
        self.ed.grid_size = self.settings.options.grid_size;
        self.preview = None; // the 3D camera is re-fitted to the new map
        self.history.reset(&self.ed.map);
    }

    // ---------------- file operations ----------------

    fn open_wad(&mut self, path: &str) {
        match Wad::open(path) {
            Ok(w) => {
                let maps = w.maps();
                self.status = format!("{path}: {} lumps, {} maps", w.entries.len(), maps.len());
                self.settings.add_recent(path);
                self.wad_path = Some(path.to_string());
                let first = maps.first().copied();
                self.wad = Some(w);
                self.rebuild_gfx();
                match first {
                    Some(h) => self.load_map(h),
                    None => self.dialog = Dialog::NewMap("E1M1".into()),
                }
            }
            Err(e) => self.status = format!("{path}: {e}"),
        }
    }

    /// Installs `w` as the IWAD supplying names and pictures.
    pub fn set_iwad(&mut self, w: Wad) {
        self.names = NameSets::from_wads(&[&w]);
        self.iwad = Some(w);
        self.rebuild_gfx();
    }

    /// Pictures come from the IWAD, overridden by the open PWAD.
    fn rebuild_gfx(&mut self) {
        let mut v: Vec<&Wad> = self.iwad.iter().collect();
        if let Some(w) = &self.wad {
            v.push(w);
        }
        self.gfx = GfxAssets::from_wads(&v);
        self.cache.clear();
        self.floor_tex.clear();
        self.tex3d.clear();
    }

    fn open_iwad(&mut self, path: &str) {
        match Wad::open(path) {
            Ok(w) => {
                self.set_iwad(w);
                self.iwad_name = Some(path.to_string());
                if self.settings.iwad != path {
                    self.settings.iwad = path.to_string();
                    self.save_settings();
                }
                self.status = format!("{path}: {} textures, {} lumps for the map checker", self.names.textures.len(), self.names.lumps.len());
            }
            Err(e) => self.status = format!("{path}: {e}"),
        }
    }

    fn load_map(&mut self, header: usize) {
        let Some(w) = &self.wad else { return };
        match MapData::load(w, header) {
            Some(m) => {
                self.status = format!("Loaded {}", m.name);
                self.install_map(m);
            }
            None => self.status = "That map could not be read".into(),
        }
    }

    /// Start saving `path`. The map is cloned and prepared (pack, blockmap,
    /// reject, nodes) on a worker thread; [`Self::poll_save`] finishes the job.
    fn save_to(&mut self, path: &str) {
        if self.job.is_some() {
            return;
        }
        let wad = match (&self.wad, &self.wad_path) {
            (Some(w), Some(p)) if p == path && w.kind == WadKind::Pwad => w.clone(),
            (Some(w), _) if w.kind == WadKind::Pwad => w.clone(),
            _ => Wad::new_pwad(),
        };
        let mut map = self.ed.map.clone();
        let opts = self.save;
        let (tx, rx) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            let r = map.prepare_for_save(&opts, &mut NoObserver);
            let _ = tx.send((map, r));
        });
        self.job = Some(SaveJob { path: path.to_string(), started: std::time::Instant::now(), wad, rx });
    }

    /// Collect a finished save job and write the file.
    fn poll_save(&mut self, ctx: &egui::Context) {
        use std::sync::mpsc::TryRecvError;
        let Some(job) = &self.job else { return };
        let (map, r) = match job.rx.try_recv() {
            Ok(v) => v,
            Err(TryRecvError::Empty) => {
                ctx.request_repaint_after(std::time::Duration::from_millis(50));
                return;
            }
            Err(TryRecvError::Disconnected) => {
                self.job = None;
                self.status = "Save failed: the node builder stopped unexpectedly".into();
                return;
            }
        };
        let SaveJob { path, mut wad, .. } = self.job.take().unwrap();
        self.ed.map = map;
        self.history.rebase(&self.ed.map); // packing renumbers items; not an edit
        let msg = match r {
            Ok(PrepareOutcome::Built(s)) => format!("Built {} nodes, {} segs, {} subsectors. ", s.nodes, s.segs, s.ssectors),
            Ok(_) => String::new(),
            Err(e) => {
                self.status = format!("Save failed: {e}");
                return;
            }
        };
        self.ed.map.save_into(&mut wad);
        match wad.save(&path) {
            Ok(()) => {
                if self.save.node_action != NodeAction::None {
                    self.ed.map.nodes_dirty = false;
                }
                self.ed.map.edited = false;
                self.status = format!("{msg}Saved {path}");
                self.wad = Some(wad);
                self.wad_path = Some(path.clone());
                self.settings.add_recent(&path);
            }
            Err(e) => self.status = format!("{path}: {e}"),
        }
    }

    /// Centred notice while the node builder runs (shown once the wait is
    /// noticeable, so quick saves do not flash it).
    fn save_progress_window(&mut self, ctx: &egui::Context) {
        let Some(job) = &self.job else { return };
        if job.started.elapsed() < std::time::Duration::from_millis(300) {
            return;
        }
        let secs = job.started.elapsed().as_secs();
        egui::Window::new("Saving")
            .title_bar(false)
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.add(egui::Spinner::new().size(28.0));
                    ui.vertical(|ui| {
                        ui.heading("Building nodes...");
                        ui.label("Packing the map and building the blockmap, reject table and BSP nodes.");
                        ui.label("Large or complex maps can take a while. The editor is locked until this finishes.");
                        ui.weak(format!("{secs} s elapsed"));
                    });
                });
            });
    }

    fn begin_open_wad(&mut self) {
        let cur = self.wad_path.clone().unwrap_or_default();
        match native_open_dialog("Open WAD", &cur) {
            Some(Some(p)) => {
                self.open_wad(&p);
                // opening a PWAD with several maps (or none) continues in the map list / new map dialogs
            }
            Some(None) => {}
            None => self.dialog = Dialog::OpenWad(cur),
        }
    }

    fn begin_open_iwad(&mut self) {
        let cur = self.iwad_name.clone().unwrap_or_default();
        match native_open_dialog("Open IWAD (DOOM.WAD / DOOM2.WAD)", &cur) {
            Some(Some(p)) => self.open_iwad(&p),
            Some(None) => {}
            None => self.dialog = Dialog::OpenIwad(cur),
        }
    }

    fn begin_save_as(&mut self) {
        let suggested = self.wad_path.clone().unwrap_or_else(|| "MYMAP.WAD".into());
        match native_save_dialog(&suggested) {
            Some(Some(p)) => self.save_to(&p),
            Some(None) => {}
            None => self.dialog = Dialog::SaveAs(suggested),
        }
    }

    #[doc(hidden)]
    pub fn save_for_test(&mut self, path: &str) {
        self.save_to(path);
    }

    #[doc(hidden)]
    pub fn save_busy_for_test(&self) -> bool {
        self.job.is_some()
    }

    #[doc(hidden)]
    pub fn status_for_test(&self) -> String {
        self.status.clone()
    }

    fn save_clicked(&mut self) {
        match (&self.wad, self.wad_path.clone()) {
            (Some(w), Some(p)) if w.kind == WadKind::Pwad => self.save_to(&p),
            _ => self.begin_save_as(),
        }
    }

    // ---------------- canvas ----------------

    fn mods(m: egui::Modifiers) -> Mods {
        Mods { shift: m.shift, ctrl: m.ctrl }
    }

    fn handle_canvas_input(&mut self, ui: &egui::Ui, rect: ERect, hovered: bool) {
        let (w, h) = (rect.width(), rect.height());
        let to_map = |ed: &Editor, p: Pos2| ed.view.to_map(p.x - rect.left(), p.y - rect.top(), w, h);
        let events = ui.input(|i| i.events.clone());
        let now = (ui.input(|i| i.time) * 1000.0) as u64;
        for ev in events {
            match ev {
                egui::Event::PointerMoved(p) => {
                    let m = to_map(&self.ed, p);
                    self.ed.mouse_move(m, Self::mods(ui.input(|i| i.modifiers)), now);
                }
                egui::Event::PointerButton { pos, button, pressed, modifiers } => {
                    let m = to_map(&self.ed, pos);
                    let md = Self::mods(modifiers);
                    let inside = rect.contains(pos) && hovered;
                    match (button, pressed) {
                        (egui::PointerButton::Primary, true) if inside => self.ed.left_down(m, md, now),
                        (egui::PointerButton::Primary, false) => self.ed.left_up(m, md, now),
                        (egui::PointerButton::Secondary, true) if inside => self.ed.right_down(m, md, now),
                        (egui::PointerButton::Secondary, false) => self.ed.right_up(m, md, now),
                        _ => {}
                    }
                }
                _ => {}
            }
        }
        // a held button must still see a time-out even if the mouse is still
        if self.ed.doing_left && self.ed.action == MouseAction::Normal {
            ui.ctx().request_repaint();
        }
        if hovered {
            // Accumulate wheel travel and take one zoom step per notch
            // (~50 points); smooth-scroll deltas arrive over many frames.
            let scroll = ui.input(|i| i.smooth_scroll_delta.y);
            self.wheel_acc += scroll;
            if let Some(p) = ui.input(|i| i.pointer.hover_pos()) {
                let m = to_map(&self.ed, p);
                const NOTCH: f32 = 50.0;
                while self.wheel_acc >= NOTCH {
                    self.wheel_acc -= NOTCH;
                    self.ed.view.zoom_in(m, w, h);
                }
                while self.wheel_acc <= -NOTCH {
                    self.wheel_acc += NOTCH;
                    self.ed.view.zoom_out();
                }
            }
            // middle-drag pans
            if ui.input(|i| i.pointer.middle_down()) {
                let d = ui.input(|i| i.pointer.delta());
                let s = self.ed.view.on_screen(w, h);
                let (ux, uy) = ((s.right - s.left) as f32 / w, (s.top - s.bottom) as f32 / h);
                self.ed.view.scroll((-d.x * ux) as i32, (d.y * uy) as i32);
            }
        }
        if double_clicked(ui, rect) {
            self.ed.left_double();
        }
    }

    /// Rebuild the cached sector decompositions when the geometry changes and
    /// load any floor flats that are now needed (repeat-wrapped, 64x64).
    fn prepare_floors(&mut self, ctx: &egui::Context) {
        if self.fill_mode == FillMode::Off {
            return;
        }
        self.update_fill();
        if matches!(self.fill_mode, FillMode::Floor | FillMode::Ceiling) && !self.gfx.flats.is_empty() {
            self.load_floor_textures(ctx);
        }
    }

    /// Refresh the cached sector decompositions when the geometry changes.
    fn update_fill(&mut self) {
        use std::hash::{Hash, Hasher};
        let m = &self.ed.map;
        let mut h = std::collections::hash_map::DefaultHasher::new();
        for (i, l) in m.linedefs.iter().enumerate() {
            (m.linedef_flags[i].used, l.from, l.to, l.sidedef1, l.sidedef2).hash(&mut h);
        }
        for v in &m.vertexes {
            (v.x, v.y).hash(&mut h);
        }
        for sd in &m.sidedefs {
            sd.sector.hash(&mut h);
        }
        let key = h.finish();
        if key != self.fill_key || self.fill.len() != m.sectors.len() {
            self.fill_key = key;
            self.fill = (0..m.sectors.len()).map(|i| m.sector_traps(i)).collect();
        }
    }

    fn load_floor_textures(&mut self, ctx: &egui::Context) {
        let ceil = self.fill_mode == FillMode::Ceiling;
        let names: std::collections::BTreeSet<String> =
            self.ed.map.sectors.iter().map(|s| name_str(if ceil { &s.ceil } else { &s.floor }).to_uppercase()).collect();
        for name in &names {
            if self.floor_tex.contains_key(name) {
                continue;
            }
            let tex = self.gfx.flat_image(name).map(|i| {
                let ci = egui::ColorImage::from_rgba_unmultiplied([i.width, i.height], &i.rgba);
                let opts = egui::TextureOptions {
                    magnification: egui::TextureFilter::Nearest,
                    minification: egui::TextureFilter::Linear,
                    wrap_mode: egui::TextureWrapMode::Repeat,
                    ..Default::default()
                };
                ctx.load_texture(format!("floor:{name}"), ci, opts)
            });
            self.floor_tex.insert(name.clone(), tex);
        }
    }

    fn paint_map(&self, painter: &egui::Painter, rect: ERect) {
        let (w, h) = (rect.width(), rect.height());
        let pal = self.pal;
        let ed = &self.ed;
        let m = &ed.map;
        painter.rect_filled(rect, 0.0, pal.background);
        let on = ed.view.on_screen(w, h);
        let sp = |x: i32, y: i32| -> Pos2 {
            let (sx, sy) = ed.view.to_screen(Point::new(x, y), w, h);
            Pos2::new(rect.left() + sx, rect.top() + sy)
        };
        let sp_f = |x: f32, y: f32| -> Pos2 {
            let sx = w / (on.right - on.left).max(1) as f32;
            let sy = h / (on.top - on.bottom).max(1) as f32;
            Pos2::new(rect.left() + (x - on.left as f32) * sx, rect.top() + (on.top as f32 - y) * sy)
        };
        let width = on.right - on.left;

        // sector fill: floor or ceiling flats (64 map units per tile) or light level
        if self.fill_mode != FillMode::Off {
            let visible = ERect::from_min_size(rect.min, rect.size());
            let ceil = self.fill_mode == FillMode::Ceiling;
            let mut by_tex: std::collections::HashMap<String, egui::epaint::Mesh> = Default::default();
            for (si, traps) in self.fill.iter().enumerate() {
                let Some(sec) = m.sectors.get(si) else { continue };
                let name = name_str(if ceil { &sec.ceil } else { &sec.floor }).to_uppercase();
                for t in traps {
                    let pts = [(t.x0, t.y0[0]), (t.x0, t.y0[1]), (t.x1, t.y1[1]), (t.x1, t.y1[0])];
                    let sc: Vec<Pos2> = pts.iter().map(|&(x, y)| sp_f(x, y)).collect();
                    if !ERect::from_points(&sc).intersects(visible) {
                        continue;
                    }
                    if self.fill_mode == FillMode::Light {
                        let g = (24.0 + sec.light.clamp(0, 255) as f32 * 0.8) as u8;
                        painter.add(Shape::convex_polygon(sc, egui::Color32::from_gray(g), Stroke::NONE));
                        continue;
                    }
                    let Some(Some(tex)) = self.floor_tex.get(&name) else { continue };
                    let mesh = by_tex.entry(name.clone()).or_insert_with(|| egui::epaint::Mesh::with_texture(tex.id()));
                    let tint = egui::Color32::from_gray(210);
                    let base = mesh.vertices.len() as u32;
                    for (k, &(x, y)) in pts.iter().enumerate() {
                        mesh.vertices.push(egui::epaint::Vertex { pos: sc[k], uv: Pos2::new(x / 64.0, -y / 64.0), color: tint });
                    }
                    mesh.indices.extend_from_slice(&[base, base + 1, base + 2, base, base + 2, base + 3]);
                }
            }
            for (_, mesh) in by_tex {
                if !mesh.is_empty() {
                    painter.add(egui::Shape::mesh(mesh));
                }
            }
        }

        // axis (blue, dash-dot)
        let axis = Stroke::new(1.0, pal.axis);
        painter.add(Shape::dashed_line(&[sp(on.left, 0), sp(on.right, 0)], axis, 8.0, 3.0));
        painter.add(Shape::dashed_line(&[sp(0, on.bottom), sp(0, on.top)], axis, 8.0, 3.0));

        // 64x64 tile grid crosses
        if self.settings.options.show_64_grid && width < 2200 {
            let st = Stroke::new(1.0, pal.grid);
            let mut i = (on.left / 64) * 64;
            while i < on.right {
                let mut j = (on.bottom / 64) * 64;
                while j < on.top {
                    painter.line_segment([sp(i - 4, j), sp(i + 5, j)], st);
                    painter.line_segment([sp(i, j - 4), sp(i, j + 5)], st);
                    j += 64;
                }
                i += 64;
            }
        }
        // snap-grid dots
        if self.settings.options.show_snap_to_grid && ed.grid_size > 4 && width < 2200 {
            let g = ed.grid_size;
            let count = ((width / g) as i64) * (((on.top - on.bottom) / g) as i64);
            if count < 60_000 {
                let mut i = (on.left / g) * g;
                while i < on.right {
                    let mut j = (on.bottom / g) * g;
                    while j < on.top {
                        painter.circle_filled(sp(i, j), 0.6, pal.user_grid);
                        j += g;
                    }
                    i += g;
                }
            }
        }

        // linedefs
        let dragging = matches!(ed.action, MouseAction::MoveSector | MouseAction::MoveVertex | MouseAction::MoveLineDef);
        for i in 0..m.linedefs.len() {
            if !m.linedef_flags[i].used {
                continue;
            }
            let l = m.linedefs[i];
            let (Some(a), Some(b)) = (m.vertexes.get(l.from as usize), m.vertexes.get(l.to as usize)) else { continue };
            let two = l.sidedef1 != NOTHING && l.sidedef2 != NOTHING;
            let normal = if two { pal.inner_lines } else { pal.map_lines };
            let col = if dragging && m.linedef_flags[i].moving {
                pal.selected
            } else {
                match ed.tool {
                    Kind::Sector => {
                        let sel = |sd: i16| m.side_sector(sd).map_or(false, |s| m.sector_selected(s));
                        if sel(l.sidedef1) || sel(l.sidedef2) { pal.selected } else { normal }
                    }
                    Kind::LineDef if m.linedef_flags[i].selected => pal.selected,
                    _ => normal,
                }
            };
            let (p, q) = (sp(a.x as i32, a.y as i32), sp(b.x as i32, b.y as i32));
            painter.line_segment([p, q], Stroke::new(1.0, col));
            if ed.tool == Kind::LineDef || (dragging && ed.action == MouseAction::MoveLineDef) {
                // direction tick at the midpoint
                let (mx, my) = ((a.x as i32 + b.x as i32) / 2, (a.y as i32 + b.y as i32) / 2);
                let t = sp(mx + (b.y as i32 - a.y as i32) / 3, my + (a.x as i32 - b.x as i32) / 3);
                painter.line_segment([sp(mx, my), t], Stroke::new(1.0, col));
            }
        }

        // things: +/-8 boxes with a facing tick
        for i in 0..m.things.len() {
            if !m.thing_flags[i].used {
                continue;
            }
            let t = m.things[i];
            let col = if m.thing_flags[i].selected { pal.selected } else { pal.marked };
            let r = ERect::from_two_pos(sp(t.x as i32 - 8, t.y as i32 - 8), sp(t.x as i32 + 8, t.y as i32 + 8));
            painter.rect_stroke(r, 0.0, Stroke::new(1.0, col));
            let ang = (t.face as f32).to_radians();
            let c = sp(t.x as i32, t.y as i32);
            let len = r.width().max(2.0);
            painter.line_segment([c, c + Vec2::new(ang.cos(), -ang.sin()) * len], Stroke::new(1.0, col));
        }

        // vertexes (vertex tool only): +/-4 boxes
        if ed.tool == Kind::Vertex {
            for i in 0..m.vertexes.len() {
                if !m.vertex_flags[i].used {
                    continue;
                }
                let v = m.vertexes[i];
                let col = if m.vertex_flags[i].selected { pal.selected } else { pal.marked };
                let r = ERect::from_two_pos(sp(v.x as i32 - 4, v.y as i32 - 4), sp(v.x as i32 + 4, v.y as i32 + 4));
                painter.rect_stroke(r, 0.0, Stroke::new(1.0, col));
            }
        }

        // rubber-band rectangle
        if matches!(ed.action, MouseAction::SelWindow | MouseAction::ZoomWindow) && ed.captured {
            let r = ed.sel_rect;
            let rr = ERect::from_two_pos(sp(r.left, r.top), sp(r.right, r.bottom));
            painter.rect_stroke(rr, 0.0, Stroke::new(1.0, pal.selected));
        }
    }

    // ---------------- panels ----------------

    fn tool_bar(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            for (k, n) in [(Kind::Thing, "Things"), (Kind::Vertex, "Vertexes"), (Kind::LineDef, "Lines"), (Kind::Sector, "Sectors")] {
                if ui.selectable_label(self.ed.tool == k, n).clicked() {
                    self.ed.set_tool(k);
                }
            }
            ui.separator();
            ui.label("Grid");
            egui::ComboBox::from_id_salt("grid").selected_text(self.ed.grid_size.to_string()).width(48.0).show_ui(ui, |ui| {
                for g in [4, 8, 16, 24, 32, 64] {
                    ui.selectable_value(&mut self.ed.grid_size, g, g.to_string());
                }
            });
            ui.separator();
            // Exactly one of these buttons is highlighted: the zoom button last used
            // in 2D, or the current look in 3D.
            let mode3d = match &self.preview {
                Some(pv) if !pv.textured && pv.hidden => 2,
                Some(pv) if !pv.textured => 1,
                _ => 0,
            };
            if ui.button("2D").on_hover_text("Show the 2D map").clicked() {
                self.view3d = false;
            }
            for (i, n) in ["All", "Window", "Prev"].into_iter().enumerate() {
                if ui.selectable_label(!self.view3d && self.view2d_btn == i, n).clicked() {
                    match i {
                        0 => self.ed.zoom_all(),
                        1 => self.ed.begin_zoom_window(),
                        _ => self.ed.view.zoom_prev(),
                    }
                    self.view2d_btn = i;
                    self.view3d = false;
                }
            }
            ui.separator();
            if ui.button("3D").on_hover_text("Show the 3D view").clicked() {
                self.view3d = true;
                if self.preview.is_none() {
                    self.open_preview();
                }
            }
            let mut pick = None;
            for (i, n, tip) in [
                (0, "Textured", "Textured walls, floors and ceilings (T)"),
                (1, "Wireframe", "Lines only"),
                (2, "Solid", "Wireframe with hidden lines removed (H)"),
            ] {
                if ui.selectable_label(self.view3d && mode3d == i, n).on_hover_text(tip).clicked() {
                    pick = Some(i);
                }
            }
            if let Some(i) = pick {
                if self.preview.is_none() {
                    self.open_preview();
                }
                self.view3d = true;
                if let Some(pv) = &mut self.preview {
                    pv.textured = i == 0;
                    pv.hidden = i == 2;
                }
            }
            if ui.button("Reset").on_hover_text("Return the 3D viewer to its original position").clicked() {
                self.reset_3d_view();
            }
        });
    }

    fn menu_bar(&mut self, ui: &mut egui::Ui) {
        egui::menu::bar(ui, |ui| {
            ui.menu_button("File", |ui| {
                if ui.button("New Map...").clicked() {
                    self.dialog = Dialog::NewMap("E1M1".into());
                    ui.close_menu();
                }
                if ui.button("Open WAD...").clicked() {
                    self.begin_open_wad();
                    ui.close_menu();
                }
                if ui.button("Open IWAD for texture names...").clicked() {
                    self.begin_open_iwad();
                    ui.close_menu();
                }
                if ui.add_enabled(self.wad.is_some() || self.iwad.is_some(), egui::Button::new("WAD Directory...")).clicked() {
                    self.dialog = Dialog::Directory { filter: String::new(), selected: None };
                    ui.close_menu();
                }
                if ui.add_enabled(self.wad.is_some(), egui::Button::new("Maps...")).clicked() {
                    self.dialog = Dialog::Maps;
                    ui.close_menu();
                }
                let recent: Vec<String> = self.settings.recent_files.iter().filter(|p| !p.is_empty()).cloned().collect();
                if !recent.is_empty() {
                    ui.separator();
                    for r in recent {
                        if ui.button(&r).clicked() {
                            self.open_wad(&r);
                            ui.close_menu();
                        }
                    }
                }
                ui.separator();
                if ui.button("Export DWD...").clicked() {
                    let base = self.wad_path.clone().unwrap_or_else(|| self.ed.map.name.clone());
                    self.dialog = Dialog::ExportDwd(format!("{}.DWD", base.trim_end_matches(|c| c != '.').trim_end_matches('.')));
                    ui.close_menu();
                }
                ui.separator();
                if ui.button("Save   Ctrl+S").clicked() {
                    self.save_clicked();
                    ui.close_menu();
                }
                if ui.button("Save As...").clicked() {
                    self.begin_save_as();
                    ui.close_menu();
                }
                if ui.button("Save Options...").clicked() {
                    self.dialog = Dialog::SaveOptions;
                    ui.close_menu();
                }
            });
            ui.menu_button("Edit", |ui| {
                if ui.add_enabled(self.history.undo_len() > 0, egui::Button::new("Undo").shortcut_text("Ctrl+Z")).clicked() {
                    self.do_undo();
                    ui.close_menu();
                }
                if ui.add_enabled(self.history.redo_len() > 0, egui::Button::new("Redo").shortcut_text("Ctrl+Y")).clicked() {
                    self.do_redo();
                    ui.close_menu();
                }
                ui.separator();
                if ui.button("Delete   Del").clicked() {
                    self.ed.delete_key(false);
                    ui.close_menu();
                }
                if ui.button("Delete with lines   Shift+Del").clicked() {
                    self.ed.delete_key(true);
                    ui.close_menu();
                }
                ui.separator();
                if ui.button("Styles...").clicked() {
                    self.dialog = Dialog::Styles { sel: None, edit: None };
                    ui.close_menu();
                }
                if ui.button("Sector Defaults...").clicked() {
                    let st = &self.settings;
                    self.dialog = Dialog::SectorDefaults {
                        wall: st.default_wall.clone(),
                        floor: st.default_floor.clone(),
                        ceil: st.default_ceil.clone(),
                        bottom: st.floor_height,
                        top: st.ceiling_height,
                        light: st.light,
                        pre: None,
                    };
                    ui.close_menu();
                }
                ui.separator();
                if ui.button("Search...").clicked() {
                    self.dialog = Dialog::Search;
                    ui.close_menu();
                }
                if ui.button("Replace...").clicked() {
                    self.dialog = Dialog::Replace;
                    ui.close_menu();
                }
                ui.separator();
                if ui.button("Make Sector a Door").clicked() {
                    self.make_door();
                    ui.close_menu();
                }
                if ui.button("Rotate and/or Scale...").clicked() {
                    self.dialog = Dialog::RotateScale { x: 100, y: 100, deg: 0 };
                    ui.close_menu();
                }
                if ui.button("Duplicate Sector").clicked() {
                    self.ed.map.sector_duplicate();
                    ui.close_menu();
                }
            });
            ui.menu_button("View", |ui| {
                if ui.button("Zoom In").clicked() {
                    let (w, h) = self.canvas;
                    let s = self.ed.view.on_screen(w, h);
                    self.ed.view.zoom_in(Point::new(s.left + (s.right - s.left) / 2, s.bottom + (s.top - s.bottom) / 2), w, h);
                    ui.close_menu();
                }
                if ui.button("Zoom Out").clicked() {
                    self.ed.view.zoom_out();
                    ui.close_menu();
                }
                ui.label("Sector fill");
                for (mode, label) in [(FillMode::Off, "None"), (FillMode::Floor, "Floor textures"), (FillMode::Ceiling, "Ceiling textures"), (FillMode::Light, "Light level")] {
                    ui.radio_value(&mut self.fill_mode, mode, label);
                }
                ui.checkbox(&mut self.settings.options.show_64_grid, "64x64 grid");
                ui.checkbox(&mut self.settings.options.show_snap_to_grid, "Snap grid dots");
            });
            ui.menu_button("Map", |ui| {
                if ui.button(if self.view3d { "2D View" } else { "3D View" }).clicked() {
                    self.view3d = !self.view3d;
                    ui.close_menu();
                }
                if ui.button("Platforms / Tags...").clicked() {
                    self.dialog = Dialog::Platforms { sel: None, edit: None };
                    ui.close_menu();
                }
                if ui.button("Statistics...").clicked() {
                    self.dialog = Dialog::Stats(self.map_statistics());
                    ui.close_menu();
                }
                if ui.button("Check Map...").clicked() {
                    let probs = self.ed.map.check_map(&self.names);
                    self.dialog = Dialog::Check(probs);
                    ui.close_menu();
                }
            });
            ui.menu_button("Options", |ui| {
                if ui.button("Options...").clicked() {
                    self.dialog = Dialog::Options(Box::new((self.settings.options.clone(), self.settings.colors)));
                    ui.close_menu();
                }
                if ui.button("BSP Builders...").clicked() {
                    self.dialog = Dialog::Builders { sel: None, edit: None };
                    ui.close_menu();
                }
            });
            ui.menu_button("Help", |ui| {
                if ui.button("About").clicked() {
                    self.dialog = Dialog::About;
                    ui.close_menu();
                }
            });
        });
    }

    /// Apply a click made in the 3D view: select the item under it in the
    /// matching tool so the side panel shows its properties (Shift adds to or
    /// removes from the selection when the tool is unchanged).
    fn apply_3d_pick(&mut self) {
        let Some((kind, n, shift)) = self.pending_3d.take() else { return };
        if shift && self.ed.tool == kind {
            self.ed.map.select(kind, n);
        } else {
            self.ed.map.unselect_everything();
            self.ed.set_tool(kind);
            self.ed.map.select(kind, n);
        }
    }

    /// Right click in the 3D view: save the attributes of the wall or sector
    /// hit, or (`paste`, Ctrl + right click) apply the saved ones to it.
    fn apply_3d_attr(&mut self) {
        use doomed_core::render3d::Pick;
        let Some((hit, paste)) = self.pending_attr.take() else { return };
        let m = &mut self.ed.map;
        match hit {
            Pick::Wall(n, side) => {
                let Some(&l) = m.linedefs.get(n) else { return };
                let sd_i = if side == 0 { l.sidedef1 } else { l.sidedef2 };
                if sd_i < 0 || m.sidedefs.get(sd_i as usize).is_none() {
                    return;
                }
                if !paste {
                    self.attr_clip = Some(AttrClip::Wall { side: m.sidedefs[sd_i as usize] });
                    self.status = format!("Saved wall textures of line {n} (side {})", side + 1);
                } else {
                    match self.attr_clip.clone() {
                        Some(AttrClip::Wall { side: src }) => {
                            // only the three texture names: flags, action, tag, offsets and sector stay as they were
                            let sd = &mut m.sidedefs[sd_i as usize];
                            (sd.t1, sd.t2, sd.t3) = (src.t1, src.t2, src.t3);
                            m.mark_changed();
                            self.status = format!("Pasted wall textures onto line {n} (side {})", side + 1);
                        }
                        Some(AttrClip::Sector(_)) => self.status = "The saved attributes are a sector's; Ctrl + right click a floor or ceiling".into(),
                        None => self.status = "Nothing saved yet: right click a wall or floor first".into(),
                    }
                }
            }
            Pick::Floor(n) | Pick::Ceiling(n) => {
                let Some(&sec) = m.sectors.get(n) else { return };
                if !paste {
                    self.attr_clip = Some(AttrClip::Sector(sec));
                    self.status = format!("Saved floor and ceiling textures of sector {n}");
                } else {
                    match self.attr_clip.clone() {
                        Some(AttrClip::Sector(src)) => {
                            // only the flats: heights, light, special and tag stay as they were
                            m.sectors[n].floor = src.floor;
                            m.sectors[n].ceil = src.ceil;
                            m.mark_changed();
                            self.status = format!("Pasted floor and ceiling textures onto sector {n}");
                        }
                        Some(AttrClip::Wall { .. }) => self.status = "The saved attributes are a wall's; Ctrl + right click a wall".into(),
                        None => self.status = "Nothing saved yet: right click a wall or floor first".into(),
                    }
                }
            }
            Pick::Thing(_) => {}
        }
    }

    #[doc(hidden)]
    pub fn attr_click_for_test(&mut self, hit: doomed_core::render3d::Pick, paste: bool) {
        self.pending_attr = Some((hit, paste));
        self.apply_3d_attr();
    }

    #[doc(hidden)]
    pub fn click_3d_for_test(&mut self, kind: Kind, n: usize, shift: bool) {
        self.pending_3d = Some((kind, n, shift));
        self.apply_3d_pick();
    }

    /// Put the 3D viewer back where it starts for this map.
    fn reset_3d_view(&mut self) {
        let cam = Camera::for_extent(self.ed.map.map_extent());
        match &mut self.preview {
            Some(pv) => pv.cam = cam,
            None => {
                self.open_preview();
            }
        }
        self.view3d = true;
    }

    #[doc(hidden)]
    pub fn reset_3d_for_test(&mut self) {
        self.reset_3d_view();
    }

    #[doc(hidden)]
    pub fn preview_cam_mut_for_test(&mut self, f: impl FnOnce(&mut Camera)) {
        if let Some(p) = &mut self.preview {
            f(&mut p.cam);
        }
    }

    #[doc(hidden)]
    pub fn camera_for_test(&self) -> Option<Camera> {
        self.preview.as_ref().map(|p| p.cam)
    }

    pub fn open_preview(&mut self) {
        let cam = Camera::for_extent(self.ed.map.map_extent());
        self.preview = Some(Preview { cam, hidden: false, textured: true, things: true, panels: preview3d::panels(&self.ed.map), tex: None, tex_key: 0, wheel: 0.0, sig: 0, view: None, thing_ids: Vec::new() });
        self.view3d = true;
    }

    #[doc(hidden)]
    pub fn preview_open(&self) -> bool {
        self.preview.is_some()
    }

    /// The 3D view (`3D.CPP` / `H3D.CPP`): left-drag orbits and raises the
    /// viewer, right-drag or Ctrl + left-drag turns and raises the target,
    /// both buttons or the wheel dolly, H toggles hidden-line removal.
    fn preview_panel(&mut self, ui: &mut egui::Ui) {
        let ctx = ui.ctx().clone();
        let ctx = &ctx;
        let pal = self.pal;
        if self.preview.is_none() {
            self.open_preview();
        }
        self.update_fill(); // sector shapes are needed for drawing and for picking
        let sig = map_signature(&self.ed.map);
        let Some(pv) = &mut self.preview else { return };
        if pv.sig != sig {
            pv.sig = sig;
            pv.panels = preview3d::panels(&self.ed.map);
        }
        let typing = ctx.wants_keyboard_input();
        {
            ui.horizontal_wrapped(|ui| {
                let c = &mut pv.cam;
                let mut dz = -c.vz;
                ui.label("Viewer");
                ui.add(egui::DragValue::new(&mut c.vx).prefix("x "));
                ui.add(egui::DragValue::new(&mut c.vy).prefix("y "));
                ui.add(egui::DragValue::new(&mut dz).prefix("z "));
                c.vz = -dz;
                ui.label("Look at");
                ui.add(egui::DragValue::new(&mut c.ox).prefix("x "));
                ui.add(egui::DragValue::new(&mut c.oy).prefix("y "));
                ui.add(egui::DragValue::new(&mut c.oz).prefix("z "));
                ui.add(egui::DragValue::new(&mut c.zoom).range(1..=100).prefix("zoom "));
            });
            let (resp, painter) = ui.allocate_painter(ui.available_size(), egui::Sense::click_and_drag());
            let rect = resp.rect;
            painter.rect_filled(rect, 0.0, pal.background);
            let (l, r, d) = ui.input(|i| {
                (i.pointer.button_down(egui::PointerButton::Primary), i.pointer.button_down(egui::PointerButton::Secondary), i.pointer.delta())
            });
            let ctrl = ui.input(|i| i.modifiers.ctrl);
            if resp.dragged() || resp.is_pointer_button_down_on() {
                let (dx, dy) = (d.x as i32, d.y as i32);
                match (l, r) {
                    (true, true) => pv.cam.dolly(dx),
                    // Ctrl + left drag moves the look-toward point instead
                    (true, false) if ctrl => pv.cam.turn(dx, dy),
                    (true, false) => pv.cam.orbit(dx, dy),
                    (false, true) => pv.cam.turn(dx, dy),
                    _ => {}
                }
            }
            if resp.hovered() {
                pv.wheel += ui.input(|i| i.smooth_scroll_delta.y);
                let steps = (pv.wheel / 50.0) as i32; // one step per notch
                if steps != 0 {
                    pv.wheel -= steps as f32 * 50.0;
                    pv.cam.wheel(steps);
                }
            }
            if resp.hovered() && !typing && ui.input(|i| i.key_pressed(egui::Key::H)) {
                pv.hidden = !pv.hidden;
            }
            if resp.hovered() && !typing && ui.input(|i| i.key_pressed(egui::Key::T)) {
                pv.textured = !pv.textured;
            }
            // a plain click selects whatever is under the pointer; a right click
            // saves its attributes and Ctrl + right click pastes them onto it
            let left = resp.clicked() && !ctrl;
            let right = resp.secondary_clicked();
            if left || right {
                if let Some(pos) = resp.interact_pointer_pos() {
                    let (x, y) = ((pos.x - rect.left()) as usize, (pos.y - rect.top()) as usize);
                    let shift = ui.input(|i| i.modifiers.shift);
                    let picked = if pv.textured && pv.view.is_some() {
                        pv.view.as_ref().and_then(|v| v.pick(x, y)).map(|p| (p, pv.thing_ids.clone()))
                    } else {
                        // wireframe: render once, just for the pick buffer
                        let bg = [pal.background.r(), pal.background.g(), pal.background.b()];
                        let (v, ids) = render_view(&self.ed.map, &self.fill, &self.gfx, &mut self.tex3d, &pv.cam, true, (rect.width() as usize).max(2), (rect.height() as usize).max(2), bg);
                        v.pick(x, y).map(|p| (p, ids))
                    };
                    if right {
                        self.pending_attr = picked.map(|(p, _)| (p, ctrl));
                    } else {
                        self.pending_3d = picked.and_then(|(p, ids)| match p {
                            doomed_core::render3d::Pick::Wall(n, _) => Some((Kind::LineDef, n, shift)),
                            doomed_core::render3d::Pick::Floor(n) | doomed_core::render3d::Pick::Ceiling(n) => Some((Kind::Sector, n, shift)),
                            doomed_core::render3d::Pick::Thing(i) => ids.get(i).map(|&n| (Kind::Thing, n, shift)),
                        });
                        if self.pending_3d.is_none() && !shift {
                            self.ed.map.unselect_everything();
                        }
                    }
                }
            }
            if pv.textured {
                let (w, h) = ((rect.width() as usize).max(2), (rect.height() as usize).max(2));
                let key = {
                    use std::hash::{Hash, Hasher};
                    let mut hs = std::collections::hash_map::DefaultHasher::new();
                    let c = &pv.cam;
                    (c.vx, c.vy, c.vz, c.ox, c.oy, c.oz, c.zoom, w, h, pv.things, sig).hash(&mut hs);
                    hs.finish()
                };
                if key != pv.tex_key || pv.tex.is_none() {
                    let bg = [pal.background.r(), pal.background.g(), pal.background.b()];
                    let (view, ids) = render_view(&self.ed.map, &self.fill, &self.gfx, &mut self.tex3d, &pv.cam, pv.things, w, h, bg);
                    let im = &view.image;
                    let ci = egui::ColorImage::from_rgba_unmultiplied([im.width, im.height], &im.rgba);
                    pv.tex = Some(ctx.load_texture("preview3d", ci, egui::TextureOptions::LINEAR));
                    pv.view = Some(view);
                    pv.thing_ids = ids;
                    pv.tex_key = key;
                }
                if let Some(t) = &pv.tex {
                    painter.image(t.id(), rect, ERect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), egui::Color32::WHITE);
                }
                ui.ctx().request_repaint_after(std::time::Duration::from_millis(200));
                return;
            }
            let shown = project_for(pv, rect.width(), rect.height());
            let stroke = Stroke::new(1.0, pal.map_lines);
            for p in shown {
                let pts: Vec<Pos2> = p.s.iter().map(|&(x, y)| Pos2::new(rect.left() + x as f32, rect.top() + y as f32)).collect();
                if pv.hidden {
                    painter.add(Shape::convex_polygon(pts, pal.background, stroke));
                } else {
                    painter.add(Shape::closed_line(pts, stroke));
                }
            }
            ui.ctx().request_repaint_after(std::time::Duration::from_millis(100));
        }
    }

    /// `DoomEdStatistics`: the map is packed first, so deleted items are not counted.
    fn map_statistics(&mut self) -> Vec<(&'static str, String)> {
        self.ed.map.pack();
        self.history.rebase(&self.ed.map);
        let m = &self.ed.map;
        let used = |f: &[doomed_core::Flags]| f.iter().filter(|x| x.used).count();
        vec![
            ("Things:", used(&m.thing_flags).to_string()),
            ("LineDefs:", used(&m.linedef_flags).to_string()),
            ("SideDefs:", used(&m.sidedef_flags).to_string()),
            ("Vertexes:", used(&m.vertex_flags).to_string()),
            ("Sectors:", used(&m.sector_flags).to_string()),
            ("Nodes:", m.nodes.len().to_string()),
            ("Segs:", m.segs.len().to_string()),
            ("SSectors:", m.ssectors.len().to_string()),
            ("Reject bytes:", m.reject.len().to_string()),
            ("Blockmap bytes:", m.blockmap.len().to_string()),
            ("Tag Descriptions:", m.tags.len().saturating_sub(1).to_string()),
        ]
    }

    /// `LABEL.CPP`: rename a directory entry, with the original's list of
    /// standard markers to choose from.
    fn rename_window(&mut self, ctx: &egui::Context) {
        const LABELS: [&str; 18] = [
            "S_START", "S_END", "S1_START", "S2_START", "S1_END", "S2_END", "P_START", "P_END", "P1_START", "P2_START", "P1_END", "P2_END",
            "F_START", "F_END", "F1_START", "F2_START", "F1_END", "F2_END",
        ];
        let Some((idx, text)) = &mut self.rename else { return };
        let (mut ok, mut cancel) = (false, false);
        egui::Window::new("Label").collapsible(false).show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label("Label");
                ui.add(egui::TextEdit::singleline(text).desired_width(90.0));
                egui::ComboBox::from_id_salt("labels").selected_text("choose...").show_ui(ui, |ui| {
                    for i in 1..=32 {
                        let n = format!("MAP{i:02}");
                        if ui.selectable_label(false, &n).clicked() {
                            *text = n;
                        }
                    }
                    for n in LABELS {
                        if ui.selectable_label(false, n).clicked() {
                            *text = n.to_string();
                        }
                    }
                });
            });
            *text = text.chars().filter(|c| !c.is_control()).take(8).collect();
            ui.horizontal(|ui| {
                ok = ui.button("OK").clicked();
                cancel = ui.button("Cancel").clicked();
            });
        });
        if ok {
            let (i, t) = (*idx, text.to_uppercase());
            if let Some(e) = self.wad.as_mut().and_then(|w| w.entries.get_mut(i)) {
                e.title = t.clone();
                self.wad.as_mut().unwrap().classify();
                self.ed.map.edited = true;
                self.status = format!("Renamed to {t}");
                self.rebuild_gfx();
            }
        }
        if ok || cancel {
            self.rename = None;
        }
    }

    fn make_door(&mut self) {
        self.status = match self.ed.map.make_sector_door() {
            Ok(0) => "Select a sector first".into(),
            Ok(n) => format!("{n} door(s) made"),
            Err(e) => e.to_string(),
        };
    }

    fn side_panel(&mut self, ui: &mut egui::Ui) {
        let m = &mut self.ed.map;
        let mut changed = false;
        let mut nodes = false;
        let mut pick: Option<PickTarget> = None;
        match self.ed.tool {
            Kind::Sector => {
                let sel: Vec<usize> = (0..m.sectors.len()).filter(|&i| m.sector_flags[i].used && m.sector_flags[i].selected).collect();
                ui.heading("Sector");
                match sel.as_slice() {
                    [] => {
                        ui.label("Nothing selected.");
                    }
                    [i, rest @ ..] => {
                        ui.label(format!("#{i}{}", if rest.is_empty() { String::new() } else { format!(" (+{} more get the same edits)", rest.len()) }));
                        let mut s = m.sectors[*i];
                        let o = s;
                        nodes |= num_edit(ui, "Floor", &mut s.floor_z);
                        nodes |= num_edit(ui, "Ceiling", &mut s.ceil_z);
                        let (c, p) = asset_row(ui, "Floor flat", &mut s.floor, &self.gfx, &mut self.cache, true);
                        changed |= c;
                        if p { pick = Some(PickTarget::Floor); }
                        let (c, p) = asset_row(ui, "Ceil flat", &mut s.ceil, &self.gfx, &mut self.cache, true);
                        changed |= c;
                        if p { pick = Some(PickTarget::Ceil); }
                        changed |= num_edit(ui, "Light", &mut s.light);
                        changed |= sector_special_combo(ui, &mut s.flash);
                        changed |= tag_combo(ui, &m.tags, &mut s.tag);
                        if s != o {
                            for &k in &sel {
                                if s.floor_z != o.floor_z { m.sectors[k].floor_z = s.floor_z; }
                                if s.ceil_z != o.ceil_z { m.sectors[k].ceil_z = s.ceil_z; }
                                if s.floor != o.floor { m.sectors[k].floor = s.floor; }
                                if s.ceil != o.ceil { m.sectors[k].ceil = s.ceil; }
                                if s.light != o.light { m.sectors[k].light = s.light; }
                                if s.flash != o.flash { m.sectors[k].flash = s.flash; }
                                if s.tag != o.tag { m.sectors[k].tag = s.tag; }
                            }
                        }
                    }
                }
            }
            Kind::LineDef => {
                ui.heading("Line");
                let sel: Vec<usize> = (0..m.linedefs.len()).filter(|&i| m.linedef_flags[i].used && m.linedef_flags[i].selected).collect();
                match sel.first() {
                    None => {
                        ui.label("Nothing selected.");
                    }
                    Some(&i) => {
                        ui.label(format!("#{i}"));
                        let o = m.linedefs[i];
                        let mut l = o;
                        let bits = [
                            line_bits::IMPASSABLE,
                            line_bits::BLOCK_MONSTERS,
                            line_bits::TWO_SIDED,
                            line_bits::UPPER_UNPEGGED,
                            line_bits::LOWER_UNPEGGED,
                            line_bits::SECRET,
                            line_bits::BLOCK_SOUND,
                            line_bits::NOT_ON_MAP,
                            line_bits::ALREADY_ON_MAP,
                        ];
                        for (n, bit) in LINE_FLAGS.iter().zip(bits) {
                            let mut on = l.test_bit(bit);
                            if ui.checkbox(&mut on, *n).changed() {
                                if on { l.set_bit(bit) } else { l.clear_bit(bit) }
                            }
                        }
                        line_action_combo(ui, &mut l.special);
                        tag_combo(ui, &m.tags, &mut l.tag);
                        if l != o {
                            for &k in &sel {
                                m.linedefs[k].solidity = l.solidity;
                                if l.special != o.special { m.linedefs[k].special = l.special; }
                                if l.tag != o.tag { m.linedefs[k].tag = l.tag; }
                            }
                            changed = true;
                        }
                        for (n, sd) in [("Front side", o.sidedef1), ("Back side", o.sidedef2)] {
                            if sd == NOTHING {
                                continue;
                            }
                            ui.separator();
                            ui.label(n);
                            let s = &mut m.sidedefs[sd as usize];
                            for (lab, tex, tgt) in [
                                ("Upper", &mut s.t1, PickTarget::Upper(sd)),
                                ("Lower", &mut s.t2, PickTarget::Lower(sd)),
                                ("Middle", &mut s.t3, PickTarget::Middle(sd)),
                            ] {
                                let (c, p) = asset_row(ui, lab, tex, &self.gfx, &mut self.cache, false);
                                changed |= c;
                                if p { pick = Some(tgt); }
                            }
                            changed |= num_edit(ui, "X offset", &mut s.x);
                            changed |= num_edit(ui, "Y offset", &mut s.y);
                            ui.label(format!("Sector {}", s.sector));
                        }
                    }
                }
            }
            Kind::Thing => {
                ui.heading("Thing");
                let sel: Vec<usize> = (0..m.things.len()).filter(|&i| m.thing_flags[i].used && m.thing_flags[i].selected).collect();
                match sel.first() {
                    None => {
                        ui.label("Nothing selected.");
                    }
                    Some(&i) => {
                        let t = &mut m.things[i];
                        let o = *t;
                        ui.label(format!("#{i} at ({}, {})", t.x, t.y));
                        let cur = thing_info(t.item).map(|i| i.name).unwrap_or("(unknown)");
                        egui::ComboBox::from_id_salt("thingtype").selected_text(cur).width(200.0).show_ui(ui, |ui| {
                            for ti in THINGS {
                                ui.selectable_value(&mut t.item, ti.number, format!("{}  [{}]", ti.name, ti.number));
                            }
                        });
                        num_edit(ui, "Type #", &mut t.item);
                        egui::ComboBox::from_id_salt("face").selected_text(format!("Facing {}", t.face)).show_ui(ui, |ui| {
                            for (n, a) in [("East", 0), ("North", 90), ("West", 180), ("South", 270), ("NE", 45), ("NW", 135), ("SW", 225), ("SE", 315)] {
                                ui.selectable_value(&mut t.face, a, format!("{n} ({a})"));
                            }
                        });
                        num_edit(ui, "Angle", &mut t.face);
                        for (n, bit) in [("Easy", 1), ("Medium", 2), ("Hard", 4), ("Deaf/ambush", 8), ("Multiplayer only", 16)] {
                            let mut on = t.lev & bit != 0;
                            if ui.checkbox(&mut on, n).changed() {
                                t.lev ^= bit;
                            }
                        }
                        if *t != o {
                            let n = *t;
                            for &k in &sel {
                                m.things[k].item = n.item;
                                m.things[k].face = n.face;
                                m.things[k].lev = n.lev;
                            }
                            changed = true;
                        }
                    }
                }
            }
            Kind::Vertex => {
                ui.heading("Vertex");
                let sel: Vec<usize> = (0..m.vertexes.len()).filter(|&i| m.vertex_flags[i].used && m.vertex_flags[i].selected).collect();
                ui.label(format!("{} selected", sel.len()));
                if let [i] = sel.as_slice() {
                    let v = &mut m.vertexes[*i];
                    changed |= num_edit(ui, "X", &mut v.x);
                    changed |= num_edit(ui, "Y", &mut v.y);
                    nodes = changed;
                }
            }
        }
        if let Some(t) = pick {
            self.picker = Some((t, String::new()));
        }
        if nodes {
            m.mark_nodes_dirty();
        } else if changed {
            m.mark_changed();
        }
        ui.separator();
        ui.small(format!(
            "{} things, {} vertexes, {} lines, {} sectors",
            m.thing_flags.iter().filter(|f| f.used).count(),
            m.vertex_flags.iter().filter(|f| f.used).count(),
            m.linedef_flags.iter().filter(|f| f.used).count(),
            m.sector_flags.iter().filter(|f| f.used).count()
        ));
    }

    // ---------------- dialogs ----------------

    fn dialogs(&mut self, ctx: &egui::Context) {
        // popups raised by the mouse model
        if let Some(p) = self.ed.popup {
            match p {
                Popup::NewSector(_) => {
                    let mut close = false;
                    egui::Window::new("New Sector").collapsible(false).resizable(false).show(ctx, |ui| {
                        if ui.button("Rectangular").clicked() {
                            self.ed.create_sector(NewSector::Rectangular);
                            close = true;
                        }
                        if ui.button("Polygonal...").clicked() {
                            self.dialog = Dialog::Polygon(8);
                            close = true;
                        }
                        if ui.button("Star").clicked() {
                            self.ed.create_sector(NewSector::Star);
                            close = true;
                        }
                        if ui.button("Steps...").clicked() {
                            self.dialog = Dialog::Steps(StepsState::default());
                            close = true;
                        }
                        if ui.button("Cancel").clicked() {
                            close = true;
                        }
                    });
                    if close {
                        self.ed.popup = None;
                    }
                }
                Popup::SelectedObject => {
                    let mut close = false;
                    egui::Window::new("Selected Object").collapsible(false).resizable(false).show(ctx, |ui| {
                        if ui.button("Make Sector a Door").clicked() {
                            self.make_door();
                            close = true;
                        }
                        if ui.button("Rotate and/or Scale...").clicked() {
                            self.dialog = Dialog::RotateScale { x: 100, y: 100, deg: 0 };
                            close = true;
                        }
                        if ui.button("Duplicate").clicked() {
                            self.ed.map.sector_duplicate();
                            close = true;
                        }
                        if ui.button("Partial Delete").clicked() {
                            self.ed.delete_key(false);
                            close = true;
                        }
                        if ui.button("Delete").clicked() {
                            self.ed.delete_key(true);
                            close = true;
                        }
                        ui.menu_button("Apply Style", |ui| {
                            for st in self.settings.styles.clone() {
                                if ui.button(&st.name).clicked() {
                                    self.ed.map.apply_style(&st);
                                    close = true;
                                    ui.close_menu();
                                }
                            }
                        });
                        if ui.button("Styles...").clicked() {
                            self.dialog = Dialog::Styles { sel: None, edit: None };
                            close = true;
                        }
                        if ui.button("Cancel").clicked() {
                            close = true;
                        }
                    });
                    if close {
                        self.ed.popup = None;
                    }
                }
                Popup::Properties(..) => self.ed.popup = None, // the side panel is always open
            }
        }

        self.picker_window(ctx);
        let mut dialog = std::mem::take(&mut self.dialog);
        let mut keep = true;
        match &mut dialog {
            Dialog::None => keep = false,
            Dialog::OpenWad(p) => match path_dialog(ctx, "Open WAD", "Path to a WAD file:", p) {
                Some(true) => {
                    let p = p.clone();
                    self.open_wad(&p);
                    keep = matches!(self.dialog, Dialog::NewMap(_));
                    if keep {
                        dialog = std::mem::take(&mut self.dialog);
                    }
                }
                Some(false) => keep = false,
                None => {}
            },
            Dialog::OpenIwad(p) => match path_dialog(ctx, "Open IWAD", "Path to DOOM.WAD / DOOM2.WAD (used by Check Map for texture and flat names):", p) {
                Some(true) => {
                    let p = p.clone();
                    self.open_iwad(&p);
                    keep = false;
                }
                Some(false) => keep = false,
                None => {}
            },
            Dialog::SaveAs(p) => match path_dialog(ctx, "Save As", "Save a PWAD to:", p) {
                Some(true) => {
                    let p = p.clone();
                    self.save_to(&p);
                    keep = false;
                }
                Some(false) => keep = false,
                None => {}
            },
            Dialog::NewMap(n) => match path_dialog(ctx, "New Map", "Map name (ExMy or MAPnn):", n) {
                Some(true) => {
                    let name = n.trim().to_uppercase();
                    if !name.is_empty() {
                        let mut m = MapData::new(&name);
                        m.edited = false;
                        self.install_map(m);
                        self.status = format!("New map {name}");
                    }
                    keep = false;
                }
                Some(false) => keep = false,
                None => {}
            },
            Dialog::Maps => {
                let maps: Vec<(usize, String)> = self.wad.as_ref().map(|w| w.maps().into_iter().map(|h| (h, w.entries[h].title.clone())).collect()).unwrap_or_default();
                let mut pick = None;
                egui::Window::new("Maps").collapsible(false).show(ctx, |ui| {
                    if maps.is_empty() {
                        ui.label("This WAD has no maps.");
                    }
                    for (h, t) in &maps {
                        if ui.button(t).clicked() {
                            pick = Some(*h);
                        }
                    }
                    if ui.button("Close").clicked() {
                        keep = false;
                    }
                });
                if let Some(h) = pick {
                    self.load_map(h);
                    keep = false;
                }
            }
            Dialog::Search | Dialog::Replace => {
                let replace = matches!(dialog, Dialog::Replace);
                let tool = self.ed.tool;
                let mut run = false;
                let mut pick: Option<PickTarget> = None;
                egui::Window::new(if replace { "Replace" } else { "Search" }).collapsible(false).show(ctx, |ui| {
                    let flat = tool == Kind::Sector;
                    match tool {
                        Kind::Thing => {
                            let label = |n: i16| thing_info(n).map(|t| t.name.to_string()).unwrap_or_else(|| n.to_string());
                            ui.horizontal(|ui| {
                                ui.label("Thing");
                                egui::ComboBox::from_id_salt("find_thing").selected_text(label(self.find_thing)).show_ui(ui, |ui| {
                                    for t in THINGS {
                                        ui.selectable_value(&mut self.find_thing, t.number, t.name);
                                    }
                                });
                            });
                            if replace {
                                ui.horizontal(|ui| {
                                    ui.label("With");
                                    egui::ComboBox::from_id_salt("repl_thing").selected_text(label(self.repl_thing)).show_ui(ui, |ui| {
                                        for t in THINGS {
                                            ui.selectable_value(&mut self.repl_thing, t.number, t.name);
                                        }
                                    });
                                });
                            }
                        }
                        Kind::Vertex => {
                            ui.label("Choose the Things, Lines or Sectors tool first.");
                        }
                        _ => {
                            ui.horizontal(|ui| {
                                ui.label(if flat { "Floor / Ceiling" } else { "Wall Texture" });
                                ui.add(egui::TextEdit::singleline(&mut self.find).desired_width(90.0));
                                if ui.small_button("...").clicked() {
                                    pick = Some(PickTarget::Find(flat));
                                }
                            });
                            if replace {
                                ui.horizontal(|ui| {
                                    ui.label("Replace with");
                                    ui.add(egui::TextEdit::singleline(&mut self.repl).desired_width(90.0));
                                    if ui.small_button("...").clicked() {
                                        pick = Some(PickTarget::Replace(flat));
                                    }
                                });
                            }
                            ui.small("Names match by their first letters, as in DoomEd.");
                        }
                    }
                    ui.horizontal(|ui| {
                        run = ui.add_enabled(tool != Kind::Vertex, egui::Button::new("OK")).clicked();
                        if ui.button("Cancel").clicked() {
                            keep = false;
                        }
                    });
                });
                if let Some(p) = pick {
                    self.picker = Some((p, String::new()));
                }
                if run {
                    self.find = self.find.trim().to_uppercase();
                    self.repl = self.repl.trim().to_uppercase();
                    let empty = self.find.is_empty() && tool != Kind::Thing;
                    let m = &mut self.ed.map;
                    self.status = if empty {
                        "Type a name to look for".into()
                    } else if replace {
                        let n = match tool {
                            Kind::Thing => m.replace_things(self.find_thing, self.repl_thing),
                            Kind::Sector => m.replace_flats(&self.find, &self.repl),
                            _ => m.replace_textures(&self.find, &self.repl),
                        };
                        if n > 0 {
                            m.mark_changed();
                        }
                        format!("Replaced {n} occurrences.")
                    } else {
                        let n = match tool {
                            Kind::Thing => m.search_things(self.find_thing),
                            Kind::Sector => m.search_flats(&self.find),
                            _ => m.search_textures(&self.find),
                        };
                        format!("Total of {n} found.")
                    };
                    keep = false;
                }
            }

            Dialog::Options(state) => {
                let mut ok = false;
                let mut custom_changed = false;
                egui::Window::new("Options").collapsible(false).show(ctx, |ui| {
                    let (o, c) = &mut **state;
                    ui.checkbox(&mut o.show_snap_to_grid, "Show snap-to-grid dots");
                    ui.checkbox(&mut o.show_64_grid, "Show 64x64 grid");
                    ui.checkbox(&mut o.verify_exit, "Verify before exiting with unsaved changes");
                    ui.horizontal(|ui| {
                        ui.label("Default grid size");
                        egui::ComboBox::from_id_salt("optgrid").selected_text(o.grid_size.to_string()).width(48.0).show_ui(ui, |ui| {
                            for g in [4, 8, 16, 24, 32, 64] {
                                ui.selectable_value(&mut o.grid_size, g, g.to_string());
                            }
                        });
                    });
                    ui.separator();
                    ui.label("Colors");
                    for (label, v) in [
                        ("Background", &mut c.background),
                        ("Map lines", &mut c.map_lines),
                        ("Inner (two-sided) lines", &mut c.map_inner_lines),
                        ("Selected", &mut c.selected),
                        ("Marked", &mut c.marked),
                        ("64x64 grid", &mut c.grid),
                        ("Snap grid", &mut c.user_grid),
                    ] {
                        ui.horizontal(|ui| {
                            let (r, g, b) = settings::colorref_rgb(*v);
                            let mut rgb = [r, g, b];
                            if ui.color_edit_button_srgb(&mut rgb).changed() {
                                *v = settings::rgb_colorref(rgb[0], rgb[1], rgb[2]);
                            }
                            ui.label(label);
                        });
                    }
                    if ui.button("Restore default colors").clicked() {
                        *c = Colors::default();
                    }
                    ui.label("Custom colors (right-click a swatch to apply it)");
                    ui.horizontal_wrapped(|ui| {
                        for i in 0..16 {
                            let (r, g, b) = settings::colorref_rgb(self.settings.custom_colors[i]);
                            let mut rgb = [r, g, b];
                            let resp = ui.color_edit_button_srgb(&mut rgb);
                            if resp.changed() {
                                self.settings.custom_colors[i] = settings::rgb_colorref(rgb[0], rgb[1], rgb[2]);
                                custom_changed = true;
                            }
                            resp.context_menu(|ui| {
                                let cc = self.settings.custom_colors[i];
                                for (label, slot) in [
                                    ("Background", &mut c.background),
                                    ("Map lines", &mut c.map_lines),
                                    ("Inner lines", &mut c.map_inner_lines),
                                    ("Selected", &mut c.selected),
                                    ("Marked", &mut c.marked),
                                    ("64x64 grid", &mut c.grid),
                                    ("Snap grid", &mut c.user_grid),
                                ] {
                                    if ui.button(format!("Use for {label}")).clicked() {
                                        *slot = cc;
                                        ui.close_menu();
                                    }
                                }
                            });
                        }
                    });
                    ui.horizontal(|ui| {
                        ok = ui.button("OK").clicked();
                        if ui.button("Cancel").clicked() {
                            keep = false;
                        }
                    });
                });
                if custom_changed {
                    self.save_settings();
                }
                if ok {
                    let (o, c) = (**state).clone();
                    let grid_changed = o.grid_size != self.settings.options.grid_size;
                    self.settings.options = o;
                    self.settings.colors = c;
                    self.pal = Pal::from(&self.settings.colors);
                    if grid_changed {
                        self.ed.grid_size = self.settings.options.grid_size;
                    }
                    self.save_settings();
                    keep = false;
                }
            }
            Dialog::Styles { sel, edit } => {
                if let (Some((slot, name)), Some((_, st))) = (self.pick_result.take(), edit.as_mut()) {
                    match slot {
                        1 => st.walls = name,
                        2 => st.floor = name,
                        _ => st.ceiling = name,
                    }
                }
                let mut pick: Option<PickTarget> = None;
                let mut commit: Option<(Option<usize>, Style)> = None;
                let mut cancel_edit = false;
                let mut delete: Option<usize> = None;
                egui::Window::new("Styles").collapsible(false).default_width(320.0).show(ctx, |ui| {
                    for (i, st) in self.settings.styles.iter().enumerate() {
                        let r = ui.selectable_label(*sel == Some(i), &st.name);
                        if r.clicked() {
                            *sel = Some(i);
                        }
                        if r.double_clicked() {
                            *edit = Some((Some(i), st.clone()));
                        }
                    }
                    ui.horizontal(|ui| {
                        if ui.add_enabled(self.settings.styles.len() < settings::MAX_STYLE, egui::Button::new("Add")).clicked() {
                            *edit = Some((None, Style::new("noname", "-", "-", "-")));
                        }
                        if ui.add_enabled(sel.is_some(), egui::Button::new("Edit")).clicked() {
                            if let Some(i) = *sel {
                                *edit = Some((Some(i), self.settings.styles[i].clone()));
                            }
                        }
                        if ui.add_enabled(sel.is_some(), egui::Button::new("Delete")).clicked() {
                            delete = *sel;
                        }
                        if ui.button("Close").clicked() {
                            keep = false;
                        }
                    });
                });
                if let Some((which, st)) = edit.as_mut() {
                    egui::Window::new("Style").collapsible(false).show(ctx, |ui| {
                        ui.horizontal(|ui| {
                            ui.label("Name");
                            ui.text_edit_singleline(&mut st.name);
                            st.name.truncate(32);
                        });
                        let Style { walls, floor, ceiling, .. } = st;
                        for (label, slot, flat, f) in [("Walls", 1u8, false, walls), ("Floor", 2, true, floor), ("Ceiling", 3, true, ceiling)] {
                            ui.horizontal(|ui| {
                                ui.label(label);
                                ui.add(egui::TextEdit::singleline(&mut *f).desired_width(80.0));
                                if ui.small_button("...").clicked() {
                                    pick = Some(PickTarget::Slot(slot, flat));
                                }
                                thumb(ui, &self.gfx, &mut self.cache, f, flat, 32.0);
                            });
                            *f = f.to_uppercase().chars().take(8).collect();
                        }
                        ui.horizontal(|ui| {
                            if ui.button("OK").clicked() {
                                commit = Some((*which, st.clone()));
                            }
                            if ui.button("Cancel").clicked() {
                                cancel_edit = true;
                            }
                        });
                    });
                }
                if let Some(p) = pick {
                    self.picker = Some((p, String::new()));
                }
                if let Some((which, st)) = commit {
                    match which {
                        Some(i) => self.settings.styles[i] = st,
                        None => self.settings.styles.push(st),
                    }
                    *edit = None;
                    self.save_settings();
                }
                if cancel_edit {
                    *edit = None;
                }
                if let Some(i) = delete {
                    let id = egui::Id::new("confirm_delete_style");
                    ctx.memory_mut(|m| m.data.insert_temp(id, i));
                }
                let id = egui::Id::new("confirm_delete_style");
                if let Some(i) = ctx.memory(|m| m.data.get_temp::<usize>(id)) {
                    let name = self.settings.styles.get(i).map(|s| s.name.clone()).unwrap_or_default();
                    let mut done = false;
                    egui::Window::new("Delete style").collapsible(false).show(ctx, |ui| {
                        ui.label(format!("Are you sure you want to delete the style \"{name}\"?"));
                        ui.horizontal(|ui| {
                            if ui.button("Yes").clicked() {
                                if i < self.settings.styles.len() {
                                    self.settings.styles.remove(i);
                                }
                                *sel = None;
                                self.save_settings();
                                done = true;
                            }
                            if ui.button("No").clicked() {
                                done = true;
                            }
                        });
                    });
                    if done {
                        ctx.memory_mut(|m| m.data.remove::<usize>(id));
                    }
                }
            }
            Dialog::SectorDefaults { wall, floor, ceil, bottom, top, light, pre } => {
                if let Some((slot, name)) = self.pick_result.take() {
                    match slot {
                        1 => *wall = name,
                        2 => *floor = name,
                        _ => *ceil = name,
                    }
                }
                let mut pick: Option<PickTarget> = None;
                let mut ok = false;
                egui::Window::new("Sector Defaults").collapsible(false).show(ctx, |ui| {
                    let styles = self.settings.styles.clone();
                    ui.horizontal(|ui| {
                        ui.label("Predefined");
                        egui::ComboBox::from_id_salt("predef")
                            .selected_text(pre.and_then(|i| styles.get(i)).map_or("(choose)", |s| s.name.as_str()))
                            .show_ui(ui, |ui| {
                                for (i, st) in styles.iter().enumerate() {
                                    if ui.selectable_label(*pre == Some(i), &st.name).clicked() {
                                        *pre = Some(i);
                                        *wall = st.walls.clone();
                                        *floor = st.floor.clone();
                                        *ceil = st.ceiling.clone();
                                    }
                                }
                            });
                    });
                    for (label, slot, flat, f) in [("Wall", 1u8, false, &mut *wall), ("Floor", 2, true, &mut *floor), ("Ceiling", 3, true, &mut *ceil)] {
                        ui.horizontal(|ui| {
                            ui.label(label);
                            ui.add(egui::TextEdit::singleline(f).desired_width(80.0));
                            if ui.small_button("...").clicked() {
                                pick = Some(PickTarget::Slot(slot, flat));
                            }
                            thumb(ui, &self.gfx, &mut self.cache, f, flat, 32.0);
                        });
                        *f = f.to_uppercase().chars().take(8).collect();
                    }
                    ui.horizontal(|ui| {
                        ui.label("Floor height");
                        ui.add(egui::DragValue::new(bottom));
                        ui.label("Ceiling height");
                        ui.add(egui::DragValue::new(top));
                        ui.label("Light");
                        ui.add(egui::DragValue::new(light));
                    });
                    ui.horizontal(|ui| {
                        ok = ui.button("OK").clicked();
                        if ui.button("Cancel").clicked() {
                            keep = false;
                        }
                    });
                });
                if let Some(p) = pick {
                    self.picker = Some((p, String::new()));
                }
                if ok {
                    let st = &mut self.settings;
                    st.default_wall = wall.clone();
                    st.default_floor = floor.clone();
                    st.default_ceil = ceil.clone();
                    st.floor_height = *bottom;
                    st.ceiling_height = *top;
                    st.light = *light;
                    self.ed.map.defaults = self.settings.defaults();
                    self.save_settings();
                    keep = false;
                }
            }
            Dialog::Builders { sel, edit } => {
                let mut commit: Option<(Option<usize>, Builder)> = None;
                let mut delete: Option<usize> = None;
                egui::Window::new("BSP Builders").collapsible(false).default_width(340.0).show(ctx, |ui| {
                    ui.small("Builders are stored in the INI; like the original, saving always uses the internal builder.");
                    for (i, b) in self.settings.builders.iter().enumerate() {
                        let r = ui.selectable_label(*sel == Some(i), &b.name);
                        if r.clicked() {
                            *sel = Some(i);
                        }
                        if r.double_clicked() {
                            *edit = Some((Some(i), b.clone()));
                        }
                    }
                    ui.horizontal(|ui| {
                        if ui.add_enabled(self.settings.builders.len() < settings::MAX_BUILDER, egui::Button::new("Add")).clicked() {
                            *edit = Some((None, Builder { name: "noname".into(), command: String::new(), format: 0 }));
                        }
                        if ui.add_enabled(sel.is_some(), egui::Button::new("Edit")).clicked() {
                            if let Some(i) = *sel {
                                *edit = Some((Some(i), self.settings.builders[i].clone()));
                            }
                        }
                        if ui.add_enabled(sel.is_some(), egui::Button::new("Delete")).clicked() {
                            delete = *sel;
                        }
                        if ui.button("Close").clicked() {
                            keep = false;
                        }
                    });
                });
                let mut cancel = false;
                if let Some((which, b)) = edit.as_mut() {
                    egui::Window::new("BSP Builder").collapsible(false).show(ctx, |ui| {
                        ui.horizontal(|ui| {
                            ui.label("Name");
                            ui.text_edit_singleline(&mut b.name);
                            b.name.truncate(32);
                        });
                        ui.horizontal(|ui| {
                            ui.label("Command");
                            ui.add(egui::TextEdit::singleline(&mut b.command).desired_width(260.0));
                            b.command.truncate(128);
                        });
                        ui.horizontal(|ui| {
                            ui.radio_value(&mut b.format, 0, "WAD");
                            ui.radio_value(&mut b.format, 1, "DWD");
                        });
                        ui.horizontal(|ui| {
                            if ui.button("OK").clicked() {
                                commit = Some((*which, b.clone()));
                            }
                            if ui.button("Cancel").clicked() {
                                cancel = true;
                            }
                        });
                    });
                }
                if let Some((which, b)) = commit {
                    match which {
                        Some(i) => self.settings.builders[i] = b,
                        None => self.settings.builders.push(b),
                    }
                    *edit = None;
                    self.save_settings();
                }
                if cancel {
                    *edit = None;
                }
                if let Some(i) = delete {
                    if i < self.settings.builders.len() {
                        self.settings.builders.remove(i);
                    }
                    *sel = None;
                    self.save_settings();
                }
            }
            Dialog::ExportDwd(p) => match path_dialog(ctx, "Export DWD", "Write the map as a DWD file to:", p) {
                Some(true) => {
                    let text = self.ed.map.export_dwd();
                    self.status = match std::fs::write(&*p, text) {
                        Ok(()) => format!("Exported {p}"),
                        Err(e) => format!("{p}: {e}"),
                    };
                    keep = false;
                }
                Some(false) => keep = false,
                None => {}
            },
            Dialog::Platforms { sel, edit } => {
                let mut commit: Option<(Option<usize>, Tag)> = None;
                let mut delete: Option<usize> = None;
                let mut cancel = false;
                egui::Window::new("Platforms (Tags)").collapsible(false).default_width(380.0).show(ctx, |ui| {
                    for (i, t) in self.ed.map.tags.iter().enumerate() {
                        let r = ui.selectable_label(*sel == Some(i), format!("{} - {}", t.name, t.desc));
                        if r.clicked() {
                            *sel = Some(i);
                        }
                        if r.double_clicked() && i > 0 {
                            *edit = Some((Some(i), t.clone()));
                        }
                    }
                    ui.horizontal(|ui| {
                        if ui.button("Add").clicked() {
                            let n = self.ed.map.next_tag as i16;
                            *edit = Some((None, Tag { num: n, name: format!("Tag{n}"), desc: String::new() }));
                        }
                        let editable = sel.map_or(false, |i| i > 0);
                        if ui.add_enabled(editable, egui::Button::new("Edit")).clicked() {
                            if let Some(i) = *sel {
                                *edit = Some((Some(i), self.ed.map.tags[i].clone()));
                            }
                        }
                        if ui.add_enabled(editable, egui::Button::new("Delete")).clicked() {
                            delete = *sel;
                        }
                        if ui.button("Close").clicked() {
                            keep = false;
                        }
                    });
                });
                if let Some((which, t)) = edit.as_mut() {
                    egui::Window::new("Platform").collapsible(false).show(ctx, |ui| {
                        ui.label(format!("Tag number {}", t.num));
                        ui.horizontal(|ui| {
                            ui.label("Name");
                            ui.text_edit_singleline(&mut t.name);
                            t.name = t.name.chars().take(15).collect();
                        });
                        ui.horizontal(|ui| {
                            ui.label("Comment");
                            ui.add(egui::TextEdit::singleline(&mut t.desc).desired_width(260.0));
                            t.desc = t.desc.chars().take(250).collect();
                        });
                        ui.horizontal(|ui| {
                            if ui.button("OK").clicked() {
                                commit = Some((*which, t.clone()));
                            }
                            if ui.button("Cancel").clicked() {
                                cancel = true;
                            }
                        });
                    });
                }
                if let Some((which, t)) = commit {
                    let m = &mut self.ed.map;
                    match which {
                        Some(i) => m.tags[i] = t,
                        None => {
                            m.tags.push(t);
                            m.next_tag += 1;
                        }
                    }
                    m.mark_changed();
                    *edit = None;
                }
                if cancel {
                    *edit = None;
                }
                if let Some(i) = delete {
                    let m = &mut self.ed.map;
                    if i > 0 && i < m.tags.len() {
                        m.tags.remove(i);
                        m.mark_changed();
                    }
                    *sel = None;
                }
            }
            Dialog::Stats(rows) => {
                egui::Window::new("Map Statistics").collapsible(false).show(ctx, |ui| {
                    egui::Grid::new("stats").num_columns(2).show(ui, |ui| {
                        for (k, v) in rows.iter() {
                            ui.label(*k);
                            ui.label(egui::RichText::new(v).monospace());
                            ui.end_row();
                        }
                    });
                    if ui.button("OK").clicked() {
                        keep = false;
                    }
                });
            }
            Dialog::ConfirmQuit => {
                egui::Window::new("Quit").collapsible(false).show(ctx, |ui| {
                    ui.label("This map has unsaved changes. Quit anyway?");
                    ui.horizontal(|ui| {
                        if ui.button("Quit").clicked() {
                            self.confirmed_quit = true;
                            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                            keep = false;
                        }
                        if ui.button("Cancel").clicked() {
                            keep = false;
                        }
                    });
                });
            }
            Dialog::Directory { filter, selected } => {
                let mut op: Option<(u8, usize)> = None; // 1 export, 2 import-replace, 3 import-new, 4 delete
                let which_iwad = self.wad.is_none();
                let wad = if which_iwad { self.iwad.as_ref() } else { self.wad.as_ref() };
                egui::Window::new("WAD Directory").collapsible(false).default_size([560.0, 460.0]).show(ctx, |ui| {
                    let Some(w) = wad else { return };
                    ui.horizontal(|ui| {
                        ui.label(format!("{} - {} lumps", if which_iwad { "IWAD" } else { "Open WAD" }, w.entries.len()));
                        ui.label("Filter");
                        ui.text_edit_singleline(filter);
                        if ui.button("Close").clicked() {
                            keep = false;
                        }
                    });
                    if !which_iwad {
                        ui.horizontal(|ui| {
                            ui.label("File");
                            ui.add(egui::TextEdit::singleline(&mut self.dir_path).desired_width(240.0));
                            let sel = *selected;
                            if ui.add_enabled(sel.is_some(), egui::Button::new("Export")).clicked() {
                                op = Some((1, sel.unwrap_or(0)));
                            }
                            if ui.add_enabled(sel.is_some(), egui::Button::new("Replace")).clicked() {
                                op = Some((2, sel.unwrap_or(0)));
                            }
                            if ui.button("Add").clicked() {
                                op = Some((3, 0));
                            }
                            if ui.add_enabled(sel.is_some(), egui::Button::new("Rename...")).clicked() {
                                if let Some(i) = sel {
                                    self.rename = w.entries.get(i).map(|e| (i, e.title.clone()));
                                }
                            }
                            if ui.add_enabled(sel.is_some(), egui::Button::new("Delete")).clicked() {
                                op = Some((4, sel.unwrap_or(0)));
                            }
                        });
                    }
                    let f = filter.to_uppercase();
                    ui.columns(2, |cols| {
                        egui::ScrollArea::vertical().id_salt("dir").show(&mut cols[0], |ui| {
                            for (i, e) in w.entries.iter().enumerate() {
                                if !f.is_empty() && !e.title.to_uppercase().contains(&f) {
                                    continue;
                                }
                                let label = format!("{:<8} {:>8}  {:?}", e.title, e.data.len(), e.ty);
                                if ui.selectable_label(*selected == Some(i), egui::RichText::new(label).monospace()).clicked() {
                                    *selected = Some(i);
                                }
                            }
                        });
                        if let Some(e) = selected.and_then(|i| w.entries.get(i)) {
                            cols[1].label(format!("{} ({} bytes)", e.title, e.data.len()));
                            let flat = e.data.len() == 4096;
                            // pictures: try as a patch, then as a flat
                            let img = if flat { self.gfx.flat_image(&e.title) } else { self.gfx.patch_image(&e.title) };
                            match img {
                                Some(i) => {
                                    let ci = egui::ColorImage::from_rgba_unmultiplied([i.width, i.height], &i.rgba);
                                    let t = ctx.load_texture("dirpreview", ci, egui::TextureOptions::NEAREST);
                                    let sz = t.size_vec2();
                                    let k = (256.0 / sz.x).min(256.0 / sz.y).max(1.0);
                                    cols[1].image((t.id(), sz * k));
                                }
                                None => {
                                    cols[1].label("(no preview)");
                                }
                            }
                        }
                    });
                });
                if let Some((kind, idx)) = op {
                    self.lump_op(kind, idx, selected);
                }
                if self.rename.is_some() {
                    self.rename_window(ctx);
                }
            }
            Dialog::SaveOptions => {
                egui::Window::new("Save Options").collapsible(false).show(ctx, |ui| {
                    ui.label("Nodes");
                    ui.radio_value(&mut self.save.node_action, NodeAction::Internal, "Build nodes (internal builder)");
                    ui.radio_value(&mut self.save.node_action, NodeAction::None, "Do not rebuild nodes");
                    ui.separator();
                    ui.label("Reject");
                    ui.radio_value(&mut self.save.reject_method, RejectMethod::Quick, "Quick (sector centres)");
                    ui.radio_value(&mut self.save.reject_method, RejectMethod::Full, "Thorough (every line end)");
                    ui.separator();
                    if ui.button("OK").clicked() {
                        keep = false;
                    }
                });
            }
            Dialog::Check(probs) => {
                let mut jump: Option<(ProblemKind, usize)> = None;
                egui::Window::new("Map Check").collapsible(false).default_width(420.0).show(ctx, |ui| {
                    if probs.is_empty() {
                        ui.label("No problems found.");
                    }
                    if self.iwad_name.is_none() {
                        ui.small("No IWAD opened: texture and flat names cannot be verified.");
                    }
                    egui::ScrollArea::vertical().max_height(300.0).show(ui, |ui| {
                        for p in probs.iter() {
                            if ui.selectable_label(false, &p.desc).clicked() {
                                if let Some(w) = p.which {
                                    jump = Some((p.what, w));
                                }
                            }
                        }
                    });
                    if ui.button("Close").clicked() {
                        keep = false;
                    }
                });
                if let Some((k, n)) = jump {
                    self.jump_to(k, n);
                }
            }
            Dialog::Polygon(sides) => {
                egui::Window::new("Polygonal Sector").collapsible(false).show(ctx, |ui| {
                    ui.horizontal(|ui| {
                        ui.label("Sides (3-64)");
                        ui.add(egui::DragValue::new(sides).range(3..=64));
                    });
                    ui.horizontal(|ui| {
                        if ui.button("OK").clicked() {
                            self.ed.create_sector(NewSector::Polygon(*sides));
                            keep = false;
                        }
                        if ui.button("Cancel").clicked() {
                            keep = false;
                        }
                    });
                });
            }
            Dialog::Steps(s) => {
                egui::Window::new("Steps").collapsible(false).show(ctx, |ui| {
                    num_edit(ui, "Lowest floor", &mut s.low);
                    num_edit(ui, "Step height", &mut s.step);
                    num_edit(ui, "Number of steps", &mut s.num);
                    ui.horizontal(|ui| {
                        ui.label("Direction");
                        for (d, n) in [(Direction::East, "E"), (Direction::North, "N"), (Direction::West, "W"), (Direction::South, "S")] {
                            ui.radio_value(&mut s.dir, d, n);
                        }
                    });
                    ui.horizontal(|ui| {
                        ui.label("Riser texture");
                        ui.text_edit_singleline(&mut s.texture);
                    });
                    ui.horizontal(|ui| {
                        if ui.button("OK").clicked() {
                            let p = StepsParams {
                                low_height: s.low,
                                step_height: s.step,
                                num_steps: s.num,
                                direction: s.dir,
                                runner_texture: s.texture.to_uppercase(),
                            };
                            if !self.ed.create_sector(NewSector::Steps(p)) {
                                self.status = "Steps need at least one step".into();
                            }
                            keep = false;
                        }
                        if ui.button("Cancel").clicked() {
                            keep = false;
                        }
                    });
                });
            }
            Dialog::RotateScale { x, y, deg } => {
                egui::Window::new("Rotate and/or Scale").collapsible(false).show(ctx, |ui| {
                    ui.horizontal(|ui| {
                        ui.label("X scale %");
                        ui.add(egui::DragValue::new(x).range(1..=1000));
                    });
                    ui.horizontal(|ui| {
                        ui.label("Y scale %");
                        ui.add(egui::DragValue::new(y).range(1..=1000));
                    });
                    ui.horizontal(|ui| {
                        ui.label("Rotate (degrees, clockwise)");
                        ui.add(egui::DragValue::new(deg).range(-360..=360));
                    });
                    ui.horizontal(|ui| {
                        if ui.button("OK").clicked() {
                            if self.ed.map.rotate_scale_selected(*x, *y, *deg) {
                                self.ed.map.mark_nodes_dirty();
                            } else {
                                self.status = "Select a sector first".into();
                            }
                            keep = false;
                        }
                        if ui.button("Cancel").clicked() {
                            keep = false;
                        }
                    });
                });
            }
            Dialog::About => {
                egui::Window::new("About DoomEd").collapsible(false).show(ctx, |ui| {
                    ui.heading("DoomEd 4.0 (Rust port)");
                    ui.label("Original design and code: Geoff Allan, 1994-95.");
                    ui.label("Port of the editing model, node builder, blockmap and reject builders.");
                    if ui.button("OK").clicked() {
                        keep = false;
                    }
                });
            }
        }
        if keep {
            self.dialog = dialog;
        }
    }

    #[doc(hidden)]
    pub fn open_picker_for_test(&mut self) {
        self.picker = Some((PickTarget::Floor, String::new()));
    }
    #[doc(hidden)]
    pub fn open_directory_for_test(&mut self) {
        self.dialog = Dialog::Directory { filter: String::new(), selected: Some(1) };
    }
    /// Switch the central pane between the 2D editor (false) and the 3D view (true).
    pub fn set_view3d(&mut self, on: bool) {
        self.view3d = on;
    }

    pub fn is_view3d(&self) -> bool {
        self.view3d
    }

    pub fn set_fill_mode(&mut self, m: FillMode) {
        self.fill_mode = m;
    }
    #[doc(hidden)]
    pub fn statistics_for_test(&mut self) -> Vec<(&'static str, String)> {
        self.map_statistics()
    }
    #[doc(hidden)]
    pub fn open_dialog_for_test(&mut self, name: &str) {
        self.dialog = match name {
            "options" => Dialog::Options(Box::new((self.settings.options.clone(), self.settings.colors))),
            "styles" => Dialog::Styles { sel: Some(0), edit: Some((Some(0), self.settings.styles[0].clone())) },
            "defaults" => Dialog::SectorDefaults { wall: "A".into(), floor: "B".into(), ceil: "C".into(), bottom: 0, top: 128, light: 200, pre: Some(0) },
            "builders" => Dialog::Builders { sel: None, edit: Some((None, Builder { name: "x".into(), command: "y".into(), format: 0 })) },
            "platforms" => Dialog::Platforms { sel: Some(0), edit: Some((None, Tag { num: 1, name: "t".into(), desc: "d".into() })) },
            "stats" => Dialog::Stats(vec![("Things:", "0".into())]),
            "search" => Dialog::Search,
            "replace" => Dialog::Replace,
            "quit" => Dialog::ConfirmQuit,
            _ => Dialog::About,
        };
    }
    #[doc(hidden)]
    pub fn has_picker(&self) -> bool {
        self.picker.is_some()
    }

    fn picker_window(&mut self, ctx: &egui::Context) {
        let Some((target, mut filter)) = self.picker.take() else { return };
        let mut names: Vec<String> = if target.is_flat() {
            self.gfx.flats.clone()
        } else {
            let mut v = vec!["-".to_string()];
            v.extend(self.gfx.texture_names().map(String::from));
            v
        };
        let f = filter.to_uppercase();
        names.retain(|n| n.contains(&f));
        names.sort();
        let (mut chosen, mut open) = (None, true);
        const COLS: usize = 5;
        let (flat, total) = (target.is_flat(), names.len());
        egui::Window::new(if flat { "Choose a flat" } else { "Choose a texture" })
            .open(&mut open)
            .default_height(480.0)
            .resizable([false, true]) // fixed 5 columns wide, scrolls vertically
            .show(ctx, |ui| {
                if self.gfx.textures.is_empty() && self.gfx.flats.is_empty() {
                    ui.label("No graphics loaded. Use File > Open IWAD first.");
                }
                ui.horizontal(|ui| {
                    ui.label("Filter");
                    ui.text_edit_singleline(&mut filter);
                    ui.label(format!("{total} shown"));
                });
                let rows = total.div_ceil(COLS);
                egui::ScrollArea::vertical().auto_shrink([false, false]).show_rows(ui, 104.0, rows, |ui, range| {
                    ui.spacing_mut().item_spacing = Vec2::new(4.0, 4.0);
                    for row in range {
                        ui.horizontal(|ui| {
                            for n in names.iter().skip(row * COLS).take(COLS) {
                                if picker_cell(ui, &self.gfx, &mut self.cache, n, flat) {
                                    chosen = Some(n.clone());
                                }
                            }
                        });
                    }
                });
            });
        if let Some(n) = chosen {
            self.apply_pick(target, &n);
        } else if open {
            self.picker = Some((target, filter));
        }
    }

    fn apply_pick(&mut self, t: PickTarget, name: &str) {
        let n = to_name8(name);
        let m = &mut self.ed.map;
        match t {
            PickTarget::Floor | PickTarget::Ceil => {
                for i in 0..m.sectors.len() {
                    if m.sector_flags[i].used && m.sector_flags[i].selected {
                        if t == PickTarget::Floor { m.sectors[i].floor = n } else { m.sectors[i].ceil = n }
                    }
                }
            }
            PickTarget::Slot(n, _) => {
                self.pick_result = Some((n, name.to_string()));
                return;
            }
            PickTarget::Find(_) => {
                self.find = name.to_string();
                return;
            }
            PickTarget::Replace(_) => {
                self.repl = name.to_string();
                return;
            }
            PickTarget::Upper(sd) => m.sidedefs[sd as usize].t1 = n,
            PickTarget::Lower(sd) => m.sidedefs[sd as usize].t2 = n,
            PickTarget::Middle(sd) => m.sidedefs[sd as usize].t3 = n,
        }
        m.mark_changed();
    }

    /// Directory lump commands: 1 export, 2 replace from file, 3 add from file, 4 delete.
    fn lump_op(&mut self, kind: u8, idx: usize, selected: &mut Option<usize>) {
        let path = self.dir_path.trim().to_string();
        let Some(w) = self.wad.as_mut() else { return };
        let msg = match kind {
            1 => match w.entries.get(idx) {
                Some(e) if !path.is_empty() => match std::fs::write(&path, &e.data) {
                    Ok(()) => format!("Exported {} to {path}", e.title),
                    Err(err) => format!("{path}: {err}"),
                },
                _ => "Type a file name first".into(),
            },
            2 | 3 => match std::fs::read(&path) {
                Ok(data) => {
                    if kind == 2 {
                        match w.entries.get_mut(idx) {
                            Some(e) => {
                                e.data = data;
                                w.classify();
                                "Lump replaced (Save to keep it)".to_string()
                            }
                            None => "Nothing selected".to_string(),
                        }
                    } else {
                        let stem = std::path::Path::new(&path).file_stem().and_then(|s| s.to_str()).unwrap_or("LUMP").to_uppercase();
                        let at = idx.min(w.entries.len().saturating_sub(1)) + usize::from(!w.entries.is_empty());
                        w.entries.insert(at.min(w.entries.len()), WadEntry::new(&stem, data));
                        w.classify();
                        *selected = Some(at.min(w.entries.len() - 1));
                        format!("Added {stem}")
                    }
                }
                Err(err) => format!("{path}: {err}"),
            },
            4 => {
                if idx < w.entries.len() {
                    let t = w.entries.remove(idx).title;
                    *selected = None;
                    format!("Deleted {t}")
                } else {
                    "Nothing selected".into()
                }
            }
            _ => String::new(),
        };
        self.status = msg;
        if kind != 1 {
            self.ed.map.edited = true; // the WAD changed, so ask before quitting
            self.rebuild_gfx();
        }
    }

    /// Map checker: select the offending item and centre the view on it.
    fn jump_to(&mut self, kind: ProblemKind, n: usize) {
        let m = &mut self.ed.map;
        let (tool, centre) = match kind {
            ProblemKind::Thing => (Kind::Thing, m.things.get(n).map(|t| (t.x as i32, t.y as i32))),
            ProblemKind::Line => (
                Kind::LineDef,
                m.linedefs.get(n).and_then(|l| {
                    let (a, b) = (m.vertexes.get(l.from as usize)?, m.vertexes.get(l.to as usize)?);
                    Some(((a.x as i32 + b.x as i32) / 2, (a.y as i32 + b.y as i32) / 2))
                }),
            ),
            ProblemKind::Sector => {
                let ext = m.sector_extents();
                (Kind::Sector, ext.get(n).copied().flatten().map(|r| ((r.left + r.right) / 2, (r.top + r.bottom) / 2)))
            }
        };
        self.ed.set_tool(tool);
        let m = &mut self.ed.map;
        m.unselect_everything();
        m.select(tool, n);
        if let Some((cx, cy)) = centre {
            let e = self.ed.view.extent;
            let (hw, hh) = ((e.right - e.left) / 2, (e.top - e.bottom) / 2);
            self.ed.view.extent = Rect { left: cx - hw, right: cx + hw, top: cy + hh, bottom: cy - hh };
        }
    }
}

/// A small modal asking for one line of text. `Some(true)` = OK.
fn path_dialog(ctx: &egui::Context, title: &str, prompt: &str, text: &mut String) -> Option<bool> {
    let mut result = None;
    egui::Window::new(title).collapsible(false).default_width(420.0).show(ctx, |ui| {
        ui.label(prompt);
        let r = ui.add(egui::TextEdit::singleline(text).desired_width(400.0));
        let enter = r.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
        ui.horizontal(|ui| {
            if ui.button("OK").clicked() || enter {
                result = Some(true);
            }
            if ui.button("Cancel").clicked() {
                result = Some(false);
            }
        });
    });
    result
}

/// Render the map for the 3D view (and its click-pick buffer). Returns the
/// view and the map thing number of each sprite handed to the renderer.
#[allow(clippy::too_many_arguments)]
fn render_view(
    map: &MapData,
    fill: &[Vec<doomed_core::sectorfill::Trap>],
    gfx: &GfxAssets,
    cache: &mut doomed_core::TexCache,
    cam: &Camera,
    things_on: bool,
    w: usize,
    h: usize,
    bg: [u8; 3],
) -> (doomed_core::render3d::View3d, Vec<usize>) {
    let mut sprites: Vec<(i32, i32, String)> = Vec::new();
    let mut ids = Vec::new();
    if things_on {
        for i in 0..map.things.len() {
            if !map.thing_flags[i].used {
                continue;
            }
            if let Some(ti) = thing_info(map.things[i].item) {
                sprites.push((map.things[i].x as i32, map.things[i].y as i32, ti.sprite.to_string()));
                ids.push(i);
            }
        }
    }
    (doomed_core::render3d::render_ids(map, fill, &sprites, gfx, cache, cam, w, h, bg), ids)
}

/// Hash of everything the textured 3D view depends on.
fn map_signature(m: &MapData) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = std::collections::hash_map::DefaultHasher::new();
    for (i, l) in m.linedefs.iter().enumerate() {
        (m.linedef_flags[i].used, l.from, l.to, l.solidity, l.sidedef1, l.sidedef2).hash(&mut h);
    }
    for v in &m.vertexes {
        (v.x, v.y).hash(&mut h);
    }
    for sd in &m.sidedefs {
        (sd.x, sd.y, sd.t1, sd.t2, sd.t3, sd.sector).hash(&mut h);
    }
    for s in &m.sectors {
        (s.floor_z, s.ceil_z, s.floor, s.ceil, s.light).hash(&mut h);
    }
    for (i, t) in m.things.iter().enumerate() {
        (m.thing_flags[i].used, t.x, t.y, t.item).hash(&mut h);
    }
    h.finish()
}

fn project_for(pv: &Preview, w: f32, h: f32) -> Vec<preview3d::Projected> {
    preview3d::project(&pv.panels, &pv.cam, w as i32, h as i32, pv.hidden)
}

fn double_clicked(ui: &egui::Ui, rect: ERect) -> bool {
    ui.input(|i| {
        i.pointer.button_double_clicked(egui::PointerButton::Primary)
            && i.pointer.interact_pos().map_or(false, |p| rect.contains(p))
    })
}

impl eframe::App for DoomEdApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.run_ui(ctx);
    }

    fn on_exit(&mut self, _gl: Option<&eframe::glow::Context>) {
        self.save_settings();
    }
}

impl DoomEdApp {
    /// One frame of the UI (separate from `eframe::App::update` so it can be
    /// driven headlessly).
    pub fn run_ui(&mut self, ctx: &egui::Context) {
        // closing the window: verify when there are unsaved changes
        if ctx.input(|i| i.viewport().close_requested()) && !self.confirmed_quit && self.settings.options.verify_exit && self.ed.map.edited {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            if !matches!(self.dialog, Dialog::ConfirmQuit) {
                self.dialog = Dialog::ConfirmQuit;
            }
        }
        self.poll_save(ctx);
        let busy = self.job.is_some();
        if !busy {
            self.commit_history(ctx); // edits made since the last frame become one undo step
        }
        // keyboard
        let (undo_key, redo_key) = ctx.input(|i| {
            let z = i.key_pressed(egui::Key::Z) && i.modifiers.command;
            (z && !i.modifiers.shift, (i.key_pressed(egui::Key::Y) && i.modifiers.command) || (z && i.modifiers.shift))
        });
        if !ctx.wants_keyboard_input() && !busy {
            if undo_key {
                self.do_undo();
            }
            if redo_key {
                self.do_redo();
            }
        }
        let (del, shift_del, save, plus, minus, pgup, pgdn, l, r, u, d) = ctx.input(|i| {
            (
                i.key_pressed(egui::Key::Delete) && !i.modifiers.shift,
                i.key_pressed(egui::Key::Delete) && i.modifiers.shift,
                i.key_pressed(egui::Key::S) && i.modifiers.ctrl,
                i.key_pressed(egui::Key::Plus) || i.key_pressed(egui::Key::Equals),
                i.key_pressed(egui::Key::Minus),
                i.key_pressed(egui::Key::PageUp),
                i.key_pressed(egui::Key::PageDown),
                i.key_pressed(egui::Key::ArrowLeft),
                i.key_pressed(egui::Key::ArrowRight),
                i.key_pressed(egui::Key::ArrowUp),
                i.key_pressed(egui::Key::ArrowDown),
            )
        });
        let typing = ctx.wants_keyboard_input();
        if !typing && !self.view3d && !busy {
            if del {
                self.ed.delete_key(false);
            }
            if shift_del {
                self.ed.delete_key(true);
            }
            let (w, h) = self.canvas;
            if plus {
                let s = self.ed.view.on_screen(w, h);
                self.ed.view.zoom_in(Point::new(s.left + (s.right - s.left) / 2, s.bottom + (s.top - s.bottom) / 2), w, h);
            }
            if minus {
                self.ed.view.zoom_out();
            }
            let page = ctx.input(|i| i.modifiers.ctrl);
            let step = |v: &mut crate::view::View, rx: i32, uy: i32| {
                if page { v.scroll_page(rx, uy, w, h) } else { v.scroll_line(rx, uy, w, h) }
            };
            if l { step(&mut self.ed.view, -1, 0); }
            if r { step(&mut self.ed.view, 1, 0); }
            if u { step(&mut self.ed.view, 0, 1); }
            if d { step(&mut self.ed.view, 0, -1); }
            if pgup { self.ed.view.scroll_page(0, 1, w, h); }
            if pgdn { self.ed.view.scroll_page(0, -1, w, h); }
        }
        if save && !busy {
            self.save_clicked();
        }

        egui::TopBottomPanel::top("menu").show(ctx, |ui| {
            ui.add_enabled_ui(!busy, |ui| {
            self.menu_bar(ui);
            self.tool_bar(ui);
            });
        });
        egui::TopBottomPanel::bottom("status").show(ctx, |ui| {
            ui.horizontal(|ui| {
                let g = self.ed.gridded;
                ui.monospace(format!("X {:>6}  Y {:>6}", g.x, g.y));
                ui.separator();
                let msg = if self.ed.message.is_empty() { &self.status } else { &self.ed.message };
                ui.label(msg);
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.label(format!(
                        "{}{}",
                        self.ed.map.name,
                        if self.ed.map.edited { " *" } else { "" }
                    ));
                });
            });
        });
        egui::SidePanel::right("props").default_width(240.0).show(ctx, |ui| {
            ui.add_enabled_ui(!busy, |ui| {
                egui::ScrollArea::vertical().show(ui, |ui| self.side_panel(ui));
            });
        });
        egui::CentralPanel::default().frame(egui::Frame::none()).show(ctx, |ui| {
            if busy {
                ui.disable();
            }
            if self.view3d {
                self.preview_panel(ui);
                if self.pending_attr.is_some() {
                    self.apply_3d_attr();
                    ui.ctx().request_repaint();
                }
                if self.pending_3d.is_some() {
                    self.apply_3d_pick();
                    ui.ctx().request_repaint(); // so the side panel shows the new selection
                }
                return;
            }
            let (rect, resp) = ui.allocate_exact_size(ui.available_size(), egui::Sense::click_and_drag());
            self.canvas = (rect.width(), rect.height());
            let hovered = resp.hovered() || self.ed.captured;
            self.handle_canvas_input(ui, rect, hovered);
            let painter = ui.painter_at(rect);
            self.prepare_floors(ui.ctx());
            self.paint_map(&painter, rect);
        });
        self.dialogs(ctx);
        self.save_progress_window(ctx);
        if self.job.is_none() {
            self.commit_history(ctx);
        }
    }
}
