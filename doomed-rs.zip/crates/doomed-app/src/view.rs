//! The map viewport (`PAINT.CPP` `SetMapping`, `SCROLL.CPP`).
//!
//! `extent` is the original's `MapExtent`: the part of the map the user asked
//! to see. What is actually shown (`MapOnScreen`) is that rectangle widened,
//! about its centre, to the display's aspect ratio. Y points up in the map
//! and down on the screen.

use doomed_core::{Point, Rect};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct View {
    pub extent: Rect,
    pub previous: Rect,
}

impl View {
    pub fn new(extent: Rect) -> Self {
        View { extent, previous: extent }
    }

    /// The extent used for an empty map (`GetMapExtents` returns this shape).
    pub fn empty_extent() -> Rect {
        Rect { left: -1024, right: 1024, top: 1024, bottom: -1024 }
    }

    /// `MapOnScreen` for a display of `w` x `h` pixels.
    pub fn on_screen(&self, w: f32, h: f32) -> Rect {
        let mut pc = self.extent;
        let (mw, mh) = ((pc.right - pc.left).max(1), (pc.top - pc.bottom).max(1));
        let (w, h) = (w.max(1.0), h.max(1.0));
        let (rx, ry) = (mw as f32 / w, mh as f32 / h);
        if rx > ry {
            let extra = (h * rx) as i32 - mh;
            pc.top += extra / 2;
            pc.bottom -= extra / 2;
        } else {
            let extra = (w * ry) as i32 - mw;
            pc.left -= extra / 2;
            pc.right += extra / 2;
        }
        pc
    }

    /// Map point -> display pixel (origin top-left of the canvas).
    pub fn to_screen(&self, p: Point, w: f32, h: f32) -> (f32, f32) {
        let s = self.on_screen(w, h);
        let sx = w / (s.right - s.left).max(1) as f32;
        let sy = h / (s.top - s.bottom).max(1) as f32;
        ((p.x - s.left) as f32 * sx, (s.top - p.y) as f32 * sy)
    }

    /// Display pixel -> map point.
    pub fn to_map(&self, x: f32, y: f32, w: f32, h: f32) -> Point {
        let s = self.on_screen(w, h);
        let mx = (s.right - s.left) as f32 / w.max(1.0);
        let my = (s.top - s.bottom) as f32 / h.max(1.0);
        Point::new(s.left + (x * mx) as i32, s.top - (y * my) as i32)
    }

    /// Zoom All: remember where we were, then show `all`.
    pub fn zoom_all(&mut self, all: Rect) {
        self.previous = self.extent;
        self.extent = all;
    }

    /// Zoom Prev swaps nothing: the original only copies the saved extent back.
    pub fn zoom_prev(&mut self) {
        self.extent = self.previous;
    }

    /// Zoom Window finished: the dragged rectangle becomes the extent.
    pub fn zoom_window(&mut self, r: Rect) {
        if r.right > r.left && r.top > r.bottom {
            self.extent = r;
        }
    }

    /// `DoomEdZoomOut`: each side moves out by a third; refuses beyond
    /// 32000 wide or ±10000.
    pub fn zoom_out(&mut self) {
        let e = &mut self.extent;
        let cy = (e.top - e.bottom) / 3;
        let (t, b) = (e.top + cy, e.bottom - cy);
        if t - b > 32000 || t > 10000 || b < -10000 || b > t {
            return;
        }
        let cx = (e.right - e.left) / 3;
        let (l, r) = (e.left - cx, e.right + cx);
        if r - l > 32000 || r > 10000 || l < -10000 || l > r {
            return;
        }
        *e = Rect { left: l, right: r, top: t, bottom: b };
    }

    /// `DoomEdZoomIn`: re-centres on `mouse`, then each side moves in by a
    /// quarter; refuses to get narrower than 64 units.
    pub fn zoom_in(&mut self, mouse: Point, w: f32, h: f32) {
        let s = self.on_screen(w, h);
        let center = Point::new(s.left + (s.right - s.left) / 2, s.bottom + (s.top - s.bottom) / 2);
        let (ox, oy) = (mouse.x - center.x, mouse.y - center.y);
        let mut e = self.extent;
        e.left += ox;
        e.right += ox;
        e.top += oy;
        e.bottom += oy;
        let cy = (e.top - e.bottom) / 4;
        e.top -= cy;
        e.bottom += cy;
        if e.top - e.bottom < 64 {
            return;
        }
        let cx = (e.right - e.left) / 4;
        e.left += cx;
        e.right -= cx;
        if e.right - e.left < 64 {
            return;
        }
        e.left -= ox / 2;
        e.right -= ox / 2;
        e.top -= oy / 2;
        e.bottom -= oy / 2;
        self.extent = e;
    }

    /// Scroll by whole map units (original: line = size/10, page = size/2).
    pub fn scroll(&mut self, dx: i32, dy: i32) {
        self.extent.left += dx;
        self.extent.right += dx;
        self.extent.top += dy;
        self.extent.bottom += dy;
    }

    pub fn scroll_line(&mut self, right: i32, up: i32, w: f32, h: f32) {
        let s = self.on_screen(w, h);
        self.scroll(right * ((s.right - s.left) / 10), up * ((s.top - s.bottom) / 10));
    }

    pub fn scroll_page(&mut self, right: i32, up: i32, w: f32, h: f32) {
        let s = self.on_screen(w, h);
        self.scroll(right * ((s.right - s.left) / 2), up * ((s.top - s.bottom) / 2));
    }
}
