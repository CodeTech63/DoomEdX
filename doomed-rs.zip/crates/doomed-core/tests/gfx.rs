use doomed_core::gfx::*;
use doomed_core::*;

fn le16(v: i16) -> [u8; 2] { v.to_le_bytes() }
fn le32(v: i32) -> [u8; 4] { v.to_le_bytes() }

/// 2x2 patch: column 0 has pixels 1,2; column 1 has a post at row 1 only (pixel 3).
fn patch() -> Vec<u8> {
    let mut d = vec![];
    d.extend(le16(2)); d.extend(le16(2)); d.extend(le16(0)); d.extend(le16(0));
    d.extend(le32(16)); d.extend(le32(16 + 7));
    d.extend([0, 2, 0, 1, 2, 0, 0xFF]);        // column 0 at 16
    d.extend([1, 1, 0, 3, 0, 0xFF]);           // column 1 at 23
    d
}

fn texture1() -> Vec<u8> {
    let mut d = vec![];
    d.extend(le32(1)); d.extend(le32(8));
    d.extend(b"WALL\0\0\0\0"); d.extend(le32(0)); d.extend(le16(4)); d.extend(le16(2));
    d.extend(le32(0)); d.extend(le16(2));
    for x in [0i16, 2] { d.extend(le16(x)); d.extend(le16(0)); d.extend(le16(0)); d.extend(le16(1)); d.extend(le16(0)); }
    d
}

fn assets() -> GfxAssets {
    let mut w = Wad::new_pwad();
    let pal: Vec<u8> = (0..256).flat_map(|i| [i as u8, 0, 255 - i as u8]).collect();
    w.entries.push(WadEntry::new("PLAYPAL", pal));
    let mut pn = le32(1).to_vec(); pn.extend(b"PATCH1\0\0");
    w.entries.push(WadEntry::new("PNAMES", pn));
    w.entries.push(WadEntry::new("PATCH1", patch()));
    w.entries.push(WadEntry::new("TEXTURE1", texture1()));
    w.entries.push(WadEntry::new("F_START", vec![]));
    w.entries.push(WadEntry::new("FLAT1", vec![7; 4096]));
    w.entries.push(WadEntry::new("F_END", vec![]));
    GfxAssets::from_wads(&[&w])
}

#[test]
fn patch_columns_and_transparency_decode() {
    let g = assets();
    let p = g.patch_image("patch1").unwrap();
    assert_eq!((p.width, p.height), (2, 2));
    assert_eq!(p.rgba[0..4], [1, 0, 254, 255]);       // (0,0) pixel 1
    assert_eq!(p.rgba[8..12], [2, 0, 253, 255]);      // (0,1) pixel 2
    assert_eq!(p.rgba[7], 0, "(1,0) is transparent");
    assert_eq!(p.rgba[12..16], [3, 0, 252, 255]);     // (1,1) pixel 3
}

#[test]
fn composite_texture_tiles_its_patches() {
    let g = assets();
    assert_eq!(g.texture_names().collect::<Vec<_>>(), ["WALL"]);
    let t = g.texture_image("Wall").unwrap();
    assert_eq!((t.width, t.height), (4, 2));
    assert_eq!(t.rgba[3], 255, "first patch at x=0");
    assert_eq!(t.rgba[(0 * 4 + 2) * 4 + 3], 255, "second patch at x=2");
}

#[test]
fn flats_are_found_between_markers() {
    let g = assets();
    assert_eq!(g.flats, ["FLAT1"]);
    let f = g.flat_image("flat1").unwrap();
    assert_eq!((f.width, f.height), (64, 64));
    assert_eq!(f.rgba[0..3], [7, 0, 248]);
    assert!(g.flat_image("PATCH1").is_none());
}

#[test]
fn damaged_lumps_do_not_panic() {
    assert!(decode_picture(&[1, 0, 1, 0, 0, 0, 0, 0, 255, 255, 255, 127], |i| [i; 3]).is_none());
    assert!(parse_texture_defs(&[5, 0, 0, 0]).is_empty());
}
