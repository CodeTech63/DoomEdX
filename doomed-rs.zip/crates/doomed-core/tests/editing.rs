use doomed_core::check::{parse_texture_names, MAX_PROBLEMS};
use doomed_core::*;
use std::collections::HashSet;

// ---------- helpers ----------

/// Always creates a new vertex (no sharing), like dragging geometry around.
fn vnew(m: &mut MapData, p: (i16, i16)) -> i16 {
    m.vertexes.push(Vertex { x: p.0, y: p.1 });
    (m.vertexes.len() - 1) as i16
}

fn side(m: &mut MapData, sector: i16, t3: &str) -> i16 {
    m.sidedefs.push(SideDef { t1: null_wall(), t2: null_wall(), t3: to_name8(t3), sector, ..Default::default() });
    (m.sidedefs.len() - 1) as i16
}

fn sectors(m: &mut MapData, n: usize) {
    while m.sectors.len() < n {
        m.sectors.push(m.defaults.sector);
    }
}

fn wall(m: &mut MapData, a: (i16, i16), b: (i16, i16), sector: i16) -> usize {
    sectors(m, sector as usize + 1);
    let (from, to) = (vnew(m, a), vnew(m, b));
    let s1 = side(m, sector, "MARBLE1");
    m.linedefs.push(LineDef { from, to, solidity: 1, sidedef1: s1, sidedef2: NOTHING, ..Default::default() });
    m.linedefs.len() - 1
}

/// One-sided wall between existing vertexes.
fn wall_v(m: &mut MapData, from: i16, to: i16, sector: i16) -> usize {
    sectors(m, sector as usize + 1);
    let s1 = side(m, sector, "MARBLE1");
    m.linedefs.push(LineDef { from, to, solidity: 1, sidedef1: s1, sidedef2: NOTHING, ..Default::default() });
    m.linedefs.len() - 1
}

/// Two-sided wall between existing vertexes, no textures (the normal kind).
fn portal_v(m: &mut MapData, from: i16, to: i16, right: i16, left: i16) -> usize {
    sectors(m, right.max(left) as usize + 1);
    let (s1, s2) = (side(m, right, "-"), side(m, left, "-"));
    m.linedefs.push(LineDef { from, to, solidity: 4, sidedef1: s1, sidedef2: s2, ..Default::default() });
    m.linedefs.len() - 1
}

/// Two-sided wall with no textures (the normal kind).
fn portal(m: &mut MapData, a: (i16, i16), b: (i16, i16), right: i16, left: i16) -> usize {
    sectors(m, right.max(left) as usize + 1);
    let (from, to) = (vnew(m, a), vnew(m, b));
    let (s1, s2) = (side(m, right, "-"), side(m, left, "-"));
    m.linedefs.push(LineDef { from, to, solidity: 4, sidedef1: s1, sidedef2: s2, ..Default::default() });
    m.linedefs.len() - 1
}

/// Clockwise room (4 shared corner vertexes); returns its 4 linedefs.
fn room(m: &mut MapData, x: i16, y: i16, size: i16, sector: i16) -> [usize; 4] {
    let v = [vnew(m, (x, y)), vnew(m, (x, y + size)), vnew(m, (x + size, y + size)), vnew(m, (x + size, y))];
    [wall_v(m, v[0], v[1], sector), wall_v(m, v[1], v[2], sector), wall_v(m, v[2], v[3], sector), wall_v(m, v[3], v[0], sector)]
}

fn fin(mut m: MapData) -> MapData {
    m.normalize_flags();
    m
}

fn used_lines(m: &MapData) -> usize {
    m.linedef_flags.iter().filter(|f| f.used).count()
}
fn used_verts(m: &MapData) -> usize {
    m.vertex_flags.iter().filter(|f| f.used).count()
}
fn two_sided_lines(m: &MapData) -> Vec<usize> {
    (0..m.linedefs.len()).filter(|&i| m.linedef_flags[i].used && m.linedefs[i].two_sided()).collect()
}

/// Rooms A (sector 0, 0..128) and B (sector 1, 128..256) sharing the two-sided
/// line returned (line 2). Six vertexes; lines 0-3 are A's, 4-6 are B's.
fn two_rooms() -> (MapData, usize) {
    let mut m = MapData::new("E1M1");
    let v: Vec<i16> =
        [(0, 0), (0, 128), (128, 128), (128, 0), (256, 128), (256, 0)].iter().map(|&p| vnew(&mut m, p)).collect();
    wall_v(&mut m, v[0], v[1], 0);
    wall_v(&mut m, v[1], v[2], 0);
    let shared = portal_v(&mut m, v[2], v[3], 0, 1);
    wall_v(&mut m, v[3], v[0], 0);
    wall_v(&mut m, v[2], v[4], 1);
    wall_v(&mut m, v[4], v[5], 1);
    wall_v(&mut m, v[5], v[3], 1);
    (fin(m), shared)
}

// ---------- defaults and item creation ----------

#[test]
fn default_items_match_the_original_ini() {
    let d = Defaults::default();
    assert_eq!((d.thing.item, d.thing.face, d.thing.lev), (0x7f3, 0, 7));
    assert_eq!(d.linedef.solidity, line_bits::IMPASSABLE);
    assert_eq!((d.linedef.sidedef1, d.linedef.sidedef2), (NOTHING, NOTHING));
    assert_eq!(d.sidedef.t3, to_name8("MARBLE1"));
    assert_eq!((d.sidedef.t1, d.sidedef.t2), (null_wall(), null_wall()));
    assert_eq!((d.sector.floor_z, d.sector.ceil_z, d.sector.light), (0, 128, 200));
    assert_eq!((d.sector.floor, d.sector.ceil), (to_name8("FLAT5_2"), to_name8("CEIL1_1")));
}

#[test]
fn new_items_reuse_unused_slots_before_growing() {
    let mut m = MapData::new("E1M1");
    let a = m.sector_new();
    let b = m.sector_new();
    assert_eq!((a, b), (0, 1));
    assert!(m.nodes_dirty && m.edited);
    m.sector_flags[0].used = false; // lazily deleted
    m.sectors[0].light = 1;
    assert_eq!(m.sector_new(), 0, "slot 0 is reused");
    assert_eq!(m.sectors[0], m.defaults.sector, "and reset to the default");
    assert_eq!(m.sector_new(), 2);
    let l = m.linedef_sidedef_new();
    assert_eq!(m.linedefs[l].sidedef1, 0);
    assert_eq!(m.linedefs[l].sidedef2, NOTHING);
    assert_eq!(m.sidedefs[0], m.defaults.sidedef);
    assert_eq!(m.thing_new(), 0);
    assert_eq!(m.things[0], m.defaults.thing);
}

#[test]
fn deleting_items() {
    let mut m = MapData::new("E1M1");
    for _ in 0..3 {
        m.sector_new();
    }
    for s in 0..3 {
        let l = m.linedef_sidedef_new();
        let sd = m.linedefs[l].sidedef1 as usize;
        m.sidedefs[sd].sector = s;
    }
    m.sector_flags[2].selected = true;
    m.sector_del(1);
    assert_eq!(m.sectors.len(), 2);
    assert_eq!(m.sidedefs.iter().map(|s| s.sector).collect::<Vec<_>>(), [0, 1, 1], "later sectors renumbered");
    assert!(m.sector_flags[1].selected, "selection follows the item (the original left it behind)");

    m.linedef_del(0);
    assert_eq!(m.linedefs.len(), 2);
    assert!(!m.sidedef_flags[0].used, "sidedefs are freed lazily");
    assert!(m.sidedef_flags[1].used);

    let v = m.vertex_new().unwrap();
    m.vertex_del(v);
    assert_eq!(m.vertex_new(), Some(v), "freed vertex slot is reused");
    m.thing_new();
    m.thing_new();
    m.thing_del(0);
    assert_eq!(m.things.len(), 1);
}

// ---------- selection ----------

#[test]
fn single_picks_toggle_and_rectangles_add() {
    let mut m = MapData::new("E1M1");
    for x in [0, 10, 20, 500] {
        m.things.push(Thing { x, y: 5, ..Default::default() });
    }
    let mut m = fin(m);
    m.select(Kind::Thing, 1);
    assert!(m.is_selected(Kind::Thing, 1));
    m.select(Kind::Thing, 1);
    assert_eq!(m.selected_count(Kind::Thing), 0);
    m.select(Kind::Thing, 1);
    m.select_in_rect(Kind::Thing, &Rect { left: 0, right: 20, top: 5, bottom: 5 }); // inclusive edges
    assert_eq!(m.selected_count(Kind::Thing), 3, "adds; does not toggle thing 1 off");
    assert!(!m.is_selected(Kind::Thing, 3));
    m.thing_flags[0].used = false;
    m.select(Kind::Thing, 0);
    assert!(!m.is_selected(Kind::Thing, 0), "unused items cannot be selected");
    m.unselect_everything();
    assert_eq!(m.selected_count(Kind::Thing), 0);
}

#[test]
fn rectangle_selection_rules_for_lines_and_sectors() {
    let mut m = MapData::new("E1M1");
    room(&mut m, 0, 0, 100, 0);
    room(&mut m, 500, 0, 100, 1);
    let mut m = fin(m);
    let r = Rect { left: -10, right: 120, top: 120, bottom: -10 };
    m.select_in_rect(Kind::LineDef, &r);
    assert_eq!(m.selected_count(Kind::LineDef), 4, "only lines with both ends inside");
    let half = Rect { left: -10, right: 50, top: 120, bottom: -10 };
    m.unselect_everything();
    m.select_in_rect(Kind::LineDef, &half);
    assert_eq!(m.selected_count(Kind::LineDef), 1, "just the west wall");
    m.select_in_rect(Kind::Sector, &half);
    assert_eq!(m.selected_count(Kind::Sector), 0, "a sector must lie wholly inside");
    m.select_in_rect(Kind::Sector, &r);
    assert!(m.is_selected(Kind::Sector, 0) && !m.is_selected(Kind::Sector, 1));
    m.select_in_rect(Kind::Vertex, &r);
    assert_eq!(m.selected_count(Kind::Vertex), 4, "the four corners of the first room");
}

#[test]
fn a_sector_no_line_touches_is_selected_by_any_rectangle() {
    // quirk carried over from GetSectorExtents' initial extent
    let mut m = MapData::new("E1M1");
    sectors(&mut m, 1);
    let mut m = fin(m);
    m.select_in_rect(Kind::Sector, &Rect { left: 0, right: 1, top: 1, bottom: 0 });
    assert!(m.is_selected(Kind::Sector, 0));
}

// ---------- finders ----------

#[test]
fn hypotenuse_is_the_gems_approximation() {
    assert_eq!(hypotenuse(Point::new(0, 0), Point::new(3, 4)), 3 + 4 - (3 >> 1));
    assert_eq!(hypotenuse(Point::new(0, 0), Point::new(100, 0)), 100);
    assert_eq!(hypotenuse(Point::new(5, 5), Point::new(-5, -5)), 10 + 10 - 5);
}

#[test]
fn nearest_vertex_and_thing_have_a_64_unit_reach() {
    let mut m = MapData::new("E1M1");
    wall(&mut m, (0, 0), (100, 0), 0);
    m.things.push(Thing { x: 300, y: 300, ..Default::default() });
    m.things.push(Thing { x: 310, y: 300, ..Default::default() });
    let mut m = fin(m);
    m.find_vertexes_in_use();
    assert_eq!(m.nearest_vertex(Point::new(90, 10)), Some(1));
    assert_eq!(m.nearest_vertex(Point::new(500, 500)), None, "out of reach: no panic, no vertex");
    assert_eq!(m.nearest_thing(Point::new(306, 300)), Some(1));
    assert_eq!(m.nearest_thing(Point::new(0, 0)), None);
    assert_eq!(MapData::new("x").nearest_thing(Point::new(0, 0)), None);
}

#[test]
fn nearest_linedef_halves_its_box_until_one_remains() {
    let mut m = MapData::new("E1M1");
    wall(&mut m, (0, 0), (1000, 0), 0);
    wall(&mut m, (0, 40), (1000, 40), 0);
    let m = fin(m);
    assert_eq!(m.nearest_linedef(Point::new(500, 10)), Some(0));
    assert_eq!(m.nearest_linedef(Point::new(500, 30)), Some(1));
    assert_eq!(m.nearest_linedef(Point::new(500, 20)), None, "equidistant: gives up");
    assert_eq!(m.nearest_linedef(Point::new(500, 300)), None, "nothing in reach");
    assert_eq!(m.nearest_linedef(Point::new(500, -50)), Some(0), "only one within the first box");
}

#[test]
fn sector_lookup_casts_a_ray_toward_plus_x() {
    let (mut m, _) = two_rooms();
    assert_eq!(m.nearest_sector(Point::new(60, 60)), Some(0));
    assert_eq!(m.nearest_sector(Point::new(200, 60)), Some(1));
    assert_eq!(m.nearest_sector(Point::new(300, 60)), None, "outside every sector");
    assert_eq!(m.nearest_sector(Point::new(60, 500)), None);
    // ignoring lines marked moving
    for i in 4..7 {
        m.linedef_flags[i].moving = true;
    }
    assert_eq!(m.nearest_sector_not_moving(Point::new(200, 60)), None);
    assert_eq!(m.nearest_sector_not_moving(Point::new(60, 60)), Some(0));
}

// ---------- joining ----------

#[test]
fn join_2_lines_makes_a_two_sided_line_and_matches_heights() {
    let mut m = MapData::new("E1M1");
    // two one-sided walls on the same spot, back to back
    let a = wall(&mut m, (128, 0), (128, 128), 1); // faces east (sector 1)
    let b = wall(&mut m, (128, 128), (128, 0), 0); // faces west (sector 0)
    let sd = m.linedefs[a].sidedef1 as usize;
    m.sidedefs[sd].t3 = to_name8("WALLA");
    let sd = m.linedefs[b].sidedef1 as usize;
    m.sidedefs[sd].t3 = to_name8("WALLB");
    m.sectors[0].ceil_z = 128;
    m.sectors[0].floor_z = 0;
    m.sectors[1].ceil_z = 192;
    m.sectors[1].floor_z = 16;
    let mut m = fin(m);
    assert_eq!(m.join_2_lines(a, b), None);
    let l = m.linedefs[a];
    assert!(l.test_bit(line_bits::TWO_SIDED) && !l.test_bit(line_bits::IMPASSABLE));
    assert!(!m.linedef_flags[b].used, "the second line is gone");
    let (s1, s2) = (m.sidedefs[l.sidedef1 as usize], m.sidedefs[l.sidedef2 as usize]);
    assert_eq!((s1.sector, s2.sector), (1, 0));
    assert_eq!((s1.t3, s2.t3), (null_wall(), null_wall()), "main textures leave the opening");
    // sector 1's ceiling is higher: its side gets the old wall as an upper texture, offset by the step
    assert_eq!((s1.t1, s1.y), (to_name8("WALLA"), 64));
    // sector 1's floor is higher: the lower texture lands on the lower sector's side
    assert_eq!(s2.t2, to_name8("WALLB"));
}

#[test]
fn join_2_lines_drops_a_redundant_face_of_a_doubled_sector() {
    let mut m = MapData::new("E1M1");
    sectors(&mut m, 3);
    let a = portal(&mut m, (0, 0), (0, 100), 0, 1);
    let b = portal(&mut m, (0, 100), (0, 0), 0, 2);
    let mut m = fin(m);
    assert_eq!(m.join_2_lines(a, b), Some(0));
    let l = m.linedefs[a];
    assert_eq!((m.sidedefs[l.sidedef1 as usize].sector, m.sidedefs[l.sidedef2 as usize].sector), (0, 2));
    assert!(m.sidedef_flags[m.linedefs[a].sidedef1 as usize].used, "the kept faces stay in use");
    assert!(!m.sidedef_flags[0].used || m.sidedefs.len() == 4, "only the redundant face was freed");
}

#[test]
fn process_joins_welds_moved_geometry() {
    let mut m = MapData::new("E1M1");
    room(&mut m, 0, 0, 128, 0);
    let b = room(&mut m, 128, 0, 128, 1); // separate vertexes, sharing a wall's position
    let mut m = fin(m);
    assert_eq!(used_lines(&m), 8);
    for &l in &b {
        m.linedef_flags[l].moving = true;
        for v in [m.linedefs[l].from, m.linedefs[l].to] {
            m.vertex_flags[v as usize].moving = true;
        }
    }
    m.process_joins();
    assert_eq!(used_lines(&m), 7, "two walls became one");
    assert_eq!(two_sided_lines(&m).len(), 1);
    assert_eq!(used_verts(&m), 6, "coincident vertexes were merged");
    let l = m.linedefs[two_sided_lines(&m)[0]];
    assert_eq!(m.vertexes[l.from as usize].x, 128);
    assert!(m.nodes_dirty);
}

#[test]
fn process_joins_deletes_lines_that_shrink_to_a_point() {
    let mut m = MapData::new("E1M1");
    let l = wall(&mut m, (0, 0), (0, 0), 0); // second vertex will weld onto the first
    let mut m = fin(m);
    m.vertex_flags[1].moving = true;
    m.process_joins();
    assert!(!m.linedef_flags[l].used);
    assert!(!m.sidedef_flags[m.linedefs[l].sidedef1 as usize].used);
}

#[test]
fn sector_height_change_rebuilds_the_boundary_textures() {
    let (mut m, shared) = two_rooms();
    m.sectors[1].floor_z = 24; // B was raised
    m.select(Kind::Sector, 1);
    m.process_sector_joins();
    let lines = two_sided_lines(&m);
    assert_eq!(lines.len(), 1, "the boundary is one two-sided line again");
    assert_eq!(used_verts(&m), 6, "temporary vertexes are freed");
    let l = m.linedefs[lines[0]];
    assert!(l.test_bit(line_bits::TWO_SIDED));
    let _ = shared;
    // whichever side is lower gets the step texture (filled from the default wall)
    let low = if m.sectors[m.sidedefs[l.sidedef1 as usize].sector as usize].floor_z == 0 { l.sidedef1 } else { l.sidedef2 };
    assert_eq!(m.sidedefs[low as usize].t2, to_name8("MARBLE1"));
}

// ---------- detach / extract / duplicate / drop ----------

fn moving_lines(m: &MapData) -> Vec<usize> {
    (0..m.linedefs.len()).filter(|&i| m.linedef_flags[i].moving).collect()
}

#[test]
fn detach_splits_the_shared_wall_and_marks_the_selection_moving() {
    let (mut m, shared) = two_rooms();
    m.select(Kind::Sector, 0);
    let before = m.linedefs.len();
    m.detach_sectors();
    assert_eq!(m.linedefs.len(), before + 1, "the shared wall became two lines");
    // A's three walls and its half of the shared wall move
    assert_eq!(moving_lines(&m).len(), 4);
    assert!(moving_lines(&m).contains(&shared));
    let (mine, theirs) = (m.linedefs[shared], m.linedefs[before]);
    assert_eq!(mine.sidedef2, NOTHING);
    assert_eq!(m.sidedefs[mine.sidedef1 as usize].sector, 0);
    assert_eq!(m.sidedefs[theirs.sidedef1 as usize].sector, 1);
    assert!(!m.linedef_flags[before].moving);
    assert!(mine.test_bit(line_bits::IMPASSABLE) && !mine.test_bit(line_bits::TWO_SIDED));
    assert_eq!(m.sidedefs[mine.sidedef1 as usize].t3, to_name8("MARBLE1"), "opening gets a wall texture");
    assert_eq!(m.vertex_flags.iter().filter(|f| f.moving).count(), 8, "every moving line has its own vertexes");
    // B's walls stay put
    assert!(!m.linedef_flags[4].moving && !m.linedef_flags[5].moving);
}

#[test]
fn extract_removes_the_neighbours_face_instead_of_splitting() {
    let (mut m, shared) = two_rooms();
    m.select(Kind::Sector, 0);
    let before = m.linedefs.len();
    m.extract_sectors();
    assert_eq!(m.linedefs.len(), before, "no new line");
    assert_eq!(moving_lines(&m).len(), 4);
    let l = m.linedefs[shared];
    assert_eq!(l.sidedef2, NOTHING);
    assert_eq!(m.sidedefs[l.sidedef1 as usize].sector, 0);
    // extracting B instead keeps B's face and reverses the line
    let (mut m, shared) = two_rooms();
    m.select(Kind::Sector, 1);
    m.extract_sectors();
    let l = m.linedefs[shared];
    assert_eq!(m.sidedefs[l.sidedef1 as usize].sector, 1);
    assert!(l.sidedef2 == NOTHING);
}

#[test]
fn duplicate_copies_a_sector_to_the_right_of_the_map() {
    let mut m = MapData::new("E1M1");
    room(&mut m, 0, 0, 128, 0);
    room(&mut m, 300, 0, 128, 1);
    let mut m = fin(m);
    m.select(Kind::Sector, 0);
    let (sectors_before, lines_before) = (m.sectors.len(), m.linedefs.len());
    assert!(m.sector_duplicate());
    assert_eq!(m.sectors.len(), sectors_before + 1);
    assert_eq!(m.linedefs.len(), lines_before + 4);
    assert!(!m.is_selected(Kind::Sector, 0) && m.is_selected(Kind::Sector, 2), "the copy is selected, not the original");
    assert_eq!(m.sectors[2], m.sectors[0]);
    // offset = map right edge (428 + 50 border) - the sector's left edge (0)
    let xs: HashSet<i16> = moving_lines(&m)
        .iter()
        .flat_map(|&l| [m.linedefs[l].from, m.linedefs[l].to])
        .map(|v| m.vertexes[v as usize].x)
        .collect();
    assert_eq!(xs, HashSet::from([478, 606]));
    assert_eq!(moving_lines(&m).len(), 4);
    assert!(!MapData::new("E1M1").sector_duplicate(), "nothing selected: nothing to do");
}

#[test]
fn dropping_a_sector_inside_another_gives_it_outward_facing_twins() {
    let mut m = MapData::new("E1M1");
    room(&mut m, 0, 0, 512, 0);
    let small = room(&mut m, 192, 192, 128, 1);
    let mut m = fin(m);
    for &l in &small {
        m.linedef_flags[l].moving = true;
    }
    let before = m.linedefs.len();
    assert_eq!(m.drop_sectors(Point::new(256, 256)), Some(0));
    assert_eq!(m.linedefs.len(), before + 4);
    for &l in &small {
        let ln = m.linedefs[l];
        assert_eq!(ln.sidedef1, NOTHING, "the dropped line was reversed");
        assert_eq!(m.sidedefs[ln.sidedef2 as usize].sector, 1);
    }
    for twin in before..before + 4 {
        let ln = m.linedefs[twin];
        assert_eq!(m.sidedefs[ln.sidedef1 as usize].sector, 0, "new faces point out into the big sector");
    }
    // dropped on top of itself or outside any sector: nothing happens
    let mut m2 = fin({
        let mut m = MapData::new("E1M1");
        room(&mut m, 0, 0, 100, 0);
        m
    });
    assert_eq!(m2.drop_sectors(Point::new(500, 500)), None);
}

// ---------- sector generators ----------

fn r(left: i32, bottom: i32, right: i32, top: i32) -> Rect {
    Rect { left, right, top, bottom }
}

#[test]
fn rectangle_sector_is_clockwise_and_selected() {
    let mut m = MapData::new("E1M1");
    let s = m.add_rect_sector(&r(0, 0, 200, 100));
    assert_eq!((m.vertexes.len(), m.linedefs.len(), m.sidedefs.len()), (4, 4, 4));
    assert_eq!(m.vertexes[0], Vertex { x: 0, y: 100 });
    assert_eq!(m.nearest_sector(Point::new(100, 50)), Some(s), "interior is on the right of every wall");
    assert_eq!(m.nearest_sector(Point::new(100, 500)), None);
    assert!(m.is_selected(Kind::Sector, s) && m.selected_count(Kind::Sector) == 1);
}

#[test]
fn polygons_and_stars() {
    let mut m = MapData::new("E1M1");
    assert_eq!(m.add_polygon_sector(&r(0, 0, 100, 100), 2), None);
    assert_eq!(m.add_polygon_sector(&r(0, 0, 100, 100), 65), None);
    let s = m.add_polygon_sector(&r(0, 0, 100, 100), 8).unwrap();
    assert_eq!(m.linedefs.len(), 8);
    assert!(m.vertexes.iter().all(|v| (0..=100).contains(&v.x) && (0..=100).contains(&v.y)));
    assert_eq!(m.vertexes[0], Vertex { x: 50 + (22.5f64.to_radians().sin() * 50.0) as i16, y: 50 + (22.5f64.to_radians().cos() * 50.0) as i16 }, "even side counts are rotated half a step");
    assert_eq!(m.nearest_sector(Point::new(50, 50)), Some(s));
    // an odd polygon starts straight up
    let t = m.add_polygon_sector(&r(200, 0, 300, 100), 5).unwrap();
    assert_eq!(m.vertexes[8], Vertex { x: 250, y: 100 });
    assert_eq!(m.nearest_sector(Point::new(250, 50)), Some(t));
    let before = m.linedefs.len();
    let star = m.add_star_sector(&r(400, 0, 500, 100));
    assert_eq!(m.linedefs.len(), before + 10);
    assert_eq!(m.nearest_sector(Point::new(450, 50)), Some(star));
}

fn steps(dir: Direction) -> StepsParams {
    StepsParams { low_height: 0, step_height: 8, num_steps: 4, direction: dir, runner_texture: "STEP4".into() }
}

#[test]
fn steps_east_build_a_welded_staircase() {
    let mut m = MapData::new("E1M1");
    m.add_steps(&r(0, 0, 256, 64), &steps(Direction::East)).unwrap();
    assert_eq!(m.sectors.len(), 4);
    assert_eq!(m.sectors.iter().map(|s| s.floor_z).collect::<Vec<_>>(), [0, 8, 16, 24]);
    assert!(m.sectors.iter().all(|s| s.ceil_z == 128), "ceiling stays at the default top");
    assert_eq!(used_lines(&m), 16 - 3, "three shared risers were fused");
    assert_eq!(used_verts(&m), 10);
    let inner = two_sided_lines(&m);
    assert_eq!(inner.len(), 3);
    for l in inner {
        let ln = m.linedefs[l];
        assert_eq!(m.sidedefs[ln.sidedef1 as usize].t2, to_name8("STEP4"), "the riser texture survives the join");
        let (lo, hi) = (m.side_sector(ln.sidedef1).unwrap(), m.side_sector(ln.sidedef2).unwrap());
        assert_eq!(hi, lo + 1);
    }
    assert_eq!(m.selected_count(Kind::Sector), 4);
}

#[test]
fn steps_in_every_direction_climb_the_right_way() {
    for (dir, probe_low, probe_high) in [
        (Direction::East, Point::new(10, 32), Point::new(250, 32)),
        (Direction::West, Point::new(250, 32), Point::new(10, 32)),
        (Direction::North, Point::new(32, 10), Point::new(32, 250)),
        (Direction::South, Point::new(32, 250), Point::new(32, 10)),
    ] {
        let mut m = MapData::new("E1M1");
        let rect = if matches!(dir, Direction::East | Direction::West) { r(0, 0, 256, 64) } else { r(0, 0, 64, 256) };
        m.add_steps(&rect, &steps(dir)).unwrap();
        let floor = |m: &MapData, p| m.sectors[m.nearest_sector(p).expect("inside a step")].floor_z;
        assert_eq!((floor(&m, probe_low), floor(&m, probe_high)), (0, 24), "{dir:?}");
        assert_eq!(two_sided_lines(&m).len(), 3, "{dir:?}");
    }
}

#[test]
fn steps_need_at_least_one_step() {
    let mut m = MapData::new("E1M1");
    let p = StepsParams { num_steps: 0, ..steps(Direction::East) };
    assert_eq!(m.add_steps(&r(0, 0, 10, 10), &p), Err(StepsError::NoSteps));
}

// ---------- map checker ----------

fn assets() -> NameSets {
    NameSets {
        lumps: HashSet::from(["FLAT5_2".to_string(), "CEIL1_1".to_string()]),
        textures: vec!["MARBLE1".into(), "STARTAN1".into()],
    }
}

fn dm_starts(m: &mut MapData, n: usize) {
    for i in 0..n {
        m.things.push(Thing { x: 10 + i as i16, y: 10, item: 11, ..Default::default() });
    }
}

#[test]
fn map_checker_reports_in_the_original_order() {
    let mut m = MapData::new("E1M1");
    let walls = room(&mut m, 0, 0, 128, 0);
    m.sectors[0].floor = to_name8("BADFLAT");
    let sd = m.linedefs[walls[1]].sidedef1 as usize;
    m.sidedefs[sd].t3 = to_name8("NOPE");
    let sd = m.linedefs[walls[2]].sidedef1 as usize;
    m.sidedefs[sd].t3 = null_wall();
    let sd = m.linedefs[walls[3]].sidedef1 as usize;
    m.sidedefs[sd].t3 = to_name8("MARB"); // a truncated name passes: prefix match
    m.things.push(Thing { x: 1000, y: 1000, ..Default::default() });
    let m = fin(m);
    let p: Vec<(String, ProblemKind, Option<usize>)> =
        m.check_map(&assets()).into_iter().map(|p| (p.desc, p.what, p.which)).collect();
    assert_eq!(
        p,
        vec![
            ("Less than 4 Deathmatch starts".into(), ProblemKind::Thing, None),
            ("Invalid Floor: BADFLAT".into(), ProblemKind::Sector, Some(0)),
            ("Invalid Front \"Main\" Texture: NOPE".into(), ProblemKind::Line, Some(walls[1])),
            ("Missing Front \"Main\" Texture".into(), ProblemKind::Line, Some(walls[2])),
            ("Orphan Thing (not in sector)".into(), ProblemKind::Thing, Some(0)),
        ]
    );
}

#[test]
fn map_checker_counts_deathmatch_starts_and_checks_step_textures() {
    let mut m = MapData::new("E1M1");
    sectors(&mut m, 2);
    m.sectors[1].floor_z = 16;
    m.sectors[1].ceil_z = 100;
    let l = portal(&mut m, (0, 0), (0, 64), 0, 1);
    let mut m = fin(m);
    dm_starts(&mut m, 11);
    let texts: Vec<String> = m.check_map(&assets()).into_iter().map(|p| p.desc).collect();
    assert!(texts.contains(&"More than 10 Deathmatch starts".to_string()));
    // front floor (0) < back floor (16): front needs a lower texture; front ceiling higher: front needs an upper
    assert!(texts.contains(&"Missing Front \"Lower\" Texture".to_string()));
    assert!(texts.contains(&"Missing Front \"Upper\" Texture".to_string()));
    assert!(!texts.iter().any(|t| t.starts_with("Missing Back")));
    // an unpegged line is exempt
    m.linedefs[l].set_bit(line_bits::UPPER_UNPEGGED | line_bits::LOWER_UNPEGGED);
    let texts: Vec<String> = m.check_map(&assets()).into_iter().map(|p| p.desc).collect();
    assert!(!texts.iter().any(|t| t.starts_with("Missing")));
}

#[test]
fn map_checker_stops_at_fifty_problems() {
    let mut m = MapData::new("E1M1");
    sectors(&mut m, 80);
    for s in &mut m.sectors {
        s.floor = to_name8("NOFLAT");
    }
    let m = fin(m);
    assert_eq!(m.check_map(&assets()).len(), MAX_PROBLEMS);
}

#[test]
fn texture_lump_names_are_parsed() {
    let mut lump = vec![];
    lump.extend(2i32.to_le_bytes());
    lump.extend(12i32.to_le_bytes());
    lump.extend(52i32.to_le_bytes());
    for name in ["AASHITTY", "BIGDOOR1"] {
        lump.extend(name.as_bytes());
        lump.extend([0u8; 32]);
    }
    assert_eq!(parse_texture_names(&lump), ["AASHITTY", "BIGDOOR1"]);
    assert!(parse_texture_names(&[1, 2]).is_empty());

    let mut wad = Wad::new_pwad();
    wad.entries.push(WadEntry::new("TEXTURE1", lump));
    wad.entries.push(WadEntry::new("FLAT5_2", vec![0; 4]));
    wad.classify();
    let sets = NameSets::from_wads(&[&wad]);
    assert!(sets.lump_exists("flat5_2") && !sets.lump_exists("") && !sets.lump_exists("NOPE"));
    assert!(sets.texture_matches("bigdoor1") && sets.texture_matches("BIGD") && !sets.texture_matches(""));
}

// ---------- editing tools feed the builders ----------

#[test]
fn a_level_made_only_with_editor_tools_builds_saves_and_reloads() {
    let mut m = MapData::new("E1M1");
    // a big room, a staircase down its middle, and a hexagonal pillar dropped in
    let big = m.add_rect_sector(&r(0, 0, 512, 512));
    m.thing_new();
    m.things[0] = Thing { x: 32, y: 32, face: 0, item: 1, lev: 7 };
    m.add_steps(&r(128, 128, 384, 192), &steps(Direction::East)).unwrap();

    m.unselect_all(Kind::Sector);
    let hex = m.add_polygon_sector(&r(400, 300, 480, 380), 6).unwrap();
    assert!(m.is_selected(Kind::Sector, hex), "a new sector is left selected");
    m.detach_sectors();
    assert!(!moving_lines(&m).is_empty());
    assert_eq!(m.drop_sectors(Point::new(440, 340)), Some(big));

    let opts = SaveOptions::default();
    let out = m.prepare_for_save(&opts, &mut NoObserver).unwrap();
    let PrepareOutcome::Built(st) = out else { panic!("{out:?}") };
    assert!(st.nodes > 0 && st.ssectors == st.nodes + 1);
    assert!(!m.blockmap.is_empty());
    assert!(m.linedef_flags.iter().all(|f| f.used), "PackMap removed everything deleted or fused");

    let mut wad = Wad::new_pwad();
    m.save_into(&mut wad);
    let wad = Wad::from_bytes(&wad.to_bytes()).unwrap();
    let back = MapData::load(&wad, 0).unwrap();
    assert_eq!(back.nodes, m.nodes);
    assert_eq!(back.sectors.len(), m.sectors.len());
    assert_eq!(back.linedefs, m.linedefs);
    // the staircase survived as sectors at four different heights
    let mut floors: Vec<i16> = back.sectors.iter().map(|s| s.floor_z).collect();
    floors.sort();
    floors.dedup();
    assert_eq!(floors, [0, 8, 16, 24]);
    // and the checker finds nothing structurally wrong with textures that exist
    let sets = NameSets {
        lumps: HashSet::from(["FLAT5_2".to_string(), "CEIL1_1".to_string()]),
        textures: vec!["MARBLE1".into(), "STEP4".into()],
    };
    let problems = back.check_map(&sets);
    let serious: Vec<_> = problems.iter().filter(|p| !p.desc.contains("Deathmatch")).collect();
    assert!(serious.is_empty(), "{serious:#?}");
}

// ---------- delete, door, rotate/scale ----------

#[test]
fn full_delete_removes_the_sector_and_every_line_touching_it() {
    let (mut m, _) = two_rooms();
    m.select(Kind::Sector, 0);
    m.delete_selected(Kind::Sector);
    assert!(!m.sector_flags[0].used && m.sector_flags[1].used);
    assert_eq!(used_lines(&m), 3, "only B's own walls survive; the shared wall went too");
}

#[test]
fn partial_delete_leaves_the_neighbour_its_wall() {
    let (mut m, _) = two_rooms();
    m.select(Kind::Sector, 0);
    m.partial_delete_selected(Kind::Sector);
    assert!(!m.sector_flags[0].used && m.sector_flags[1].used);
    assert_eq!(used_lines(&m), 4, "B's three walls plus its half of the old shared wall");
    assert_eq!(m.selected_count(Kind::Sector), 0);
}

#[test]
fn delete_with_the_vertex_tool_does_nothing() {
    let (mut m, _) = two_rooms();
    m.select(Kind::Vertex, 0);
    m.delete_selected(Kind::Vertex);
    assert_eq!(used_verts(&m), 6);
}

fn door_map() -> MapData {
    let mut m = MapData::new("E1M1");
    let v: Vec<i16> = [(0, 0), (0, 64), (64, 0), (64, 64), (128, 0), (128, 64)].iter().map(|&p| vnew(&mut m, p)).collect();
    portal_v(&mut m, v[2], v[3], 1, 0);
    portal_v(&mut m, v[5], v[4], 1, 2);
    wall_v(&mut m, v[3], v[5], 1);
    wall_v(&mut m, v[4], v[2], 1);
    sectors(&mut m, 3);
    m.sectors[1].floor_z = 0;
    m.sectors[1].ceil_z = 128;
    fin(m)
}

#[test]
fn make_sector_door_builds_a_manual_door() {
    let mut m = door_map();
    m.select(Kind::Sector, 1);
    assert_eq!(m.make_sector_door(), Ok(1));
    assert_eq!(m.sectors[1].ceil_z, m.sectors[1].floor_z);
    assert_eq!(m.sectors[1].ceil, to_name8("FLAT20"));
    for l in 0..2 {
        let ln = m.linedefs[l];
        assert_eq!(ln.special, 1);
        assert_eq!(m.side_sector(ln.sidedef1), Some(if l == 0 { 0 } else { 2 }), "door texture sits on the outside face");
        assert_eq!(m.sidedefs[ln.sidedef1 as usize].t1, to_name8("DOOR3"));
        assert_eq!(m.side_sector(ln.sidedef2), Some(1));
    }
    for l in 2..4 {
        assert_eq!(m.sidedefs[m.linedefs[l].sidedef1 as usize].t3, to_name8("DOORTRAK"));
    }
}

#[test]
fn make_sector_door_checks_its_preconditions() {
    let (mut m, _) = two_rooms();
    m.select(Kind::Sector, 0);
    assert_eq!(m.make_sector_door(), Err(DoorError::NotSandwiched), "four sides but only one neighbour");
    wall(&mut m, (300, 0), (300, 8), 0);
    m.normalize_flags();
    assert_eq!(m.make_sector_door(), Err(DoorError::NotFourSides));
    let mut m = door_map();
    m.sectors[2].floor_z = 24;
    m.select(Kind::Sector, 1);
    assert_eq!(m.make_sector_door(), Err(DoorError::FloorsDiffer));
}

#[test]
fn rotate_scale_scales_about_the_selection_centre() {
    let mut m = MapData::new("E1M1");
    room(&mut m, 0, 0, 128, 0);
    let mut m = fin(m);
    m.select(Kind::Sector, 0);
    assert!(m.rotate_scale_selected(200, 100, 0));
    let xs: Vec<i16> = (0..m.vertexes.len()).filter(|&i| m.vertex_flags[i].used).map(|i| m.vertexes[i].x).collect();
    assert_eq!((*xs.iter().min().unwrap(), *xs.iter().max().unwrap()), (-64, 192));
}

#[test]
fn rotate_by_a_quarter_turn_swaps_the_extents() {
    let mut m = MapData::new("E1M1");
    let v = [vnew(&mut m, (0, 0)), vnew(&mut m, (0, 64)), vnew(&mut m, (256, 64)), vnew(&mut m, (256, 0))];
    wall_v(&mut m, v[0], v[1], 0);
    wall_v(&mut m, v[1], v[2], 0);
    wall_v(&mut m, v[2], v[3], 0);
    wall_v(&mut m, v[3], v[0], 0);
    let mut m = fin(m);
    m.select(Kind::Sector, 0);
    m.rotate_scale_selected(100, 100, 90);
    let ys: Vec<i16> = (0..m.vertexes.len()).filter(|&i| m.vertex_flags[i].used).map(|i| m.vertexes[i].y).collect();
    let span = *ys.iter().max().unwrap() as i32 - *ys.iter().min().unwrap() as i32;
    assert!((span - 256).abs() <= 2, "span {span}");
}

// ---------- search and replace ----------

#[test]
fn search_and_replace_match_by_prefix() {
    let (mut m, _) = two_rooms();
    for s in m.sidedefs.iter_mut() {
        if s.t3 == to_name8("MARBLE1") {
            s.t3 = to_name8("STARTAN2");
        }
    }
    m.sidedefs[0].t3 = to_name8("STARTAN1");
    m.sectors[1].floor = to_name8("FLOOR4_8");
    let found = m.search_textures("STAR");
    assert_eq!(found, m.selected_count(Kind::LineDef));
    assert!(found >= 2);
    assert_eq!(m.search_textures("STARTAN1"), 1);
    assert_eq!(m.search_textures("NOPE"), 0);
    assert_eq!(m.search_flats("FLOOR4"), 1, "only the sector using that floor");
    assert!(m.sector_selected(1) && !m.sector_selected(0));
    let n = m.replace_textures("STARTAN", "BRICK1");
    assert!(n >= 2);
    assert_eq!(m.sidedefs[0].t3, to_name8("BRICK1"), "the whole name is replaced");
    assert_eq!(m.replace_flats("FLOOR4_8", "FLAT1"), 1);
    assert_eq!(m.sectors[1].floor, to_name8("FLAT1"));
    m.things.push(Thing { item: 2018, ..Default::default() });
    m.normalize_flags();
    assert_eq!(m.search_things(2018), 1);
    assert_eq!(m.replace_things(2018, 2019), 1);
    assert_eq!(m.things[0].item, 2019);
}

/// Sector 0 is a 256 square room; sector 1 is a 64 square platform inside it,
/// its walls two-sided with sector 0 on the far side.
fn room_with_island() -> MapData {
    let mut m = MapData::new("E1M1");
    let o: Vec<i16> = [(0, 0), (0, 256), (256, 256), (256, 0)].iter().map(|&p| vnew(&mut m, p)).collect();
    for k in 0..4 {
        wall_v(&mut m, o[k], o[(k + 1) % 4], 0);
    }
    let i: Vec<i16> = [(96, 96), (96, 160), (160, 160), (160, 96)].iter().map(|&p| vnew(&mut m, p)).collect();
    for k in 0..4 {
        portal_v(&mut m, i[k], i[(k + 1) % 4], 1, 0);
    }
    fin(m)
}

#[test]
fn a_sector_inside_another_drags_the_shared_vertexes_instead_of_splitting() {
    let mut m = room_with_island();
    m.select(Kind::Sector, 1);
    let (lines, verts) = (m.linedefs.len(), m.vertexes.len());
    m.detach_sectors();
    assert_eq!(m.linedefs.len(), lines, "no wall was split");
    assert_eq!(m.vertexes.len(), verts, "no vertexes were duplicated");
    assert_eq!(moving_lines(&m), vec![4, 5, 6, 7]);
    assert_eq!(m.vertex_flags.iter().filter(|f| f.moving).count(), 4);
    for k in 4..8 {
        let l = m.linedefs[k];
        assert_ne!(l.sidedef2, NOTHING, "still two-sided, so the outer room follows");
    }
    // the room's own walls stay put
    assert!((0..4).all(|k| !m.linedef_flags[k].moving));
}

#[test]
fn a_sector_that_shares_a_wall_with_two_others_is_still_detached() {
    let (mut m, _) = two_rooms();
    m.select(Kind::Sector, 0);
    let lines = m.linedefs.len();
    m.detach_sectors();
    assert_eq!(m.linedefs.len(), lines + 1);
}
