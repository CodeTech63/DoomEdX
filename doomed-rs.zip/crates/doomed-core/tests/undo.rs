use doomed_core::*;

fn map_with_things(n: usize) -> MapData {
    let mut m = MapData::new("E1M1");
    for i in 0..n {
        let t = m.thing_new();
        m.things[t].x = i as i16 * 10;
    }
    m
}

#[test]
fn each_idle_change_is_one_step_and_undo_redo_walk_them() {
    let mut m = map_with_things(1);
    let mut u = UndoStack::new(10);
    u.reset(&m);
    assert!(!u.commit_if_changed(&m), "nothing changed");
    m.things[0].x = 100;
    m.things[0].x = 200; // two edits before the next idle moment: one step
    assert!(u.commit_if_changed(&m));
    m.things[0].x = 300;
    assert!(u.commit_if_changed(&m));
    assert_eq!(u.undo_len(), 2);
    assert!(u.undo(&mut m));
    assert_eq!(m.things[0].x, 200);
    assert!(u.undo(&mut m));
    assert_eq!(m.things[0].x, 0);
    assert!(!u.undo(&mut m), "nothing older");
    assert!(u.redo(&mut m));
    assert_eq!(m.things[0].x, 200);
    assert!(u.redo(&mut m));
    assert_eq!(m.things[0].x, 300);
    assert!(!u.redo(&mut m));
}

#[test]
fn a_new_edit_clears_redo_and_undo_captures_pending_changes() {
    let mut m = map_with_things(1);
    let mut u = UndoStack::new(10);
    u.reset(&m);
    m.things[0].x = 5;
    u.commit_if_changed(&m);
    u.undo(&mut m);
    assert_eq!(u.redo_len(), 1);
    m.things[0].x = 77;
    assert!(u.undo(&mut m), "undo first records the uncommitted edit, then steps back over it");
    assert_eq!(m.things[0].x, 0);
    assert_eq!(u.redo_len(), 1);
    assert!(u.redo(&mut m));
    assert_eq!(m.things[0].x, 77);
}

#[test]
fn history_is_limited_and_deletions_and_additions_are_undone() {
    let mut m = map_with_things(0);
    let mut u = UndoStack::new(10);
    u.reset(&m);
    for i in 0..15 {
        let t = m.thing_new();
        m.things[t].x = i;
        u.commit_if_changed(&m);
    }
    assert_eq!(u.undo_len(), 10, "oldest steps drop off");
    for _ in 0..10 {
        assert!(u.undo(&mut m));
    }
    assert!(!u.undo(&mut m));
    assert_eq!(m.things.len(), 5, "ten of the fifteen additions are gone");
    // lazy delete is a content change too
    m.thing_flags[0].used = false;
    assert!(u.commit_if_changed(&m));
    assert!(u.undo(&mut m));
    assert!(m.thing_flags[0].used);
}

#[test]
fn selection_alone_is_not_an_edit_and_undo_clears_it() {
    let mut m = map_with_things(2);
    let mut u = UndoStack::new(4);
    u.reset(&m);
    m.select(Kind::Thing, 1);
    assert!(!u.commit_if_changed(&m));
    m.things[1].y = 9;
    u.commit_if_changed(&m);
    u.undo(&mut m);
    assert!(!m.is_selected(Kind::Thing, 1));
    assert!(m.edited && m.nodes_dirty);
}
