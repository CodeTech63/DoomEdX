use doomed_core::nodes::{partition_score, BAMS180};
use doomed_core::*;
use std::collections::HashMap;

// ---------- map construction helpers ----------

fn vert(m: &mut MapData, p: (i16, i16)) -> i16 {
    if let Some(i) = m.vertexes.iter().position(|v| v.x == p.0 && v.y == p.1) {
        return i as i16;
    }
    m.vertexes.push(Vertex { x: p.0, y: p.1 });
    (m.vertexes.len() - 1) as i16
}

fn side(m: &mut MapData, sector: i16) -> i16 {
    m.sidedefs.push(SideDef { t1: null_wall(), t2: null_wall(), t3: to_name8("WALL"), sector, ..Default::default() });
    (m.sidedefs.len() - 1) as i16
}

fn ensure_sectors(m: &mut MapData, n: usize) {
    while m.sectors.len() < n {
        m.sectors.push(Sector { ceil_z: 128, light: 160, ..Default::default() });
    }
}

/// One-sided wall; the sector is on its right.
fn wall(m: &mut MapData, a: (i16, i16), b: (i16, i16), sector: i16) -> usize {
    ensure_sectors(m, sector as usize + 1);
    let (from, to) = (vert(m, a), vert(m, b));
    let s1 = side(m, sector);
    m.linedefs.push(LineDef { from, to, solidity: 1, sidedef1: s1, sidedef2: NOTHING, ..Default::default() });
    m.linedefs.len() - 1
}

fn portal(m: &mut MapData, a: (i16, i16), b: (i16, i16), right: i16, left: i16) -> usize {
    ensure_sectors(m, right.max(left) as usize + 1);
    let (from, to) = (vert(m, a), vert(m, b));
    let (s1, s2) = (side(m, right), side(m, left));
    m.linedefs.push(LineDef { from, to, solidity: 4, sidedef1: s1, sidedef2: s2, ..Default::default() });
    m.linedefs.len() - 1
}

/// Clockwise square room (interior on the right of every wall).
fn room_cw(m: &mut MapData, x: i16, y: i16, size: i16, sector: i16) {
    let c = [(x, y), (x, y + size), (x + size, y + size), (x + size, y), (x, y)];
    for w in c.windows(2) {
        wall(m, w[0], w[1], sector);
    }
}

fn finish(mut m: MapData) -> MapData {
    m.normalize_flags();
    m
}

fn pillar_room() -> MapData {
    let mut m = MapData::new("E1M1");
    room_cw(&mut m, 0, 0, 256, 0);
    // counter-clockwise pillar: solid inside, walls face the room
    let p = [(96, 96), (160, 96), (160, 160), (96, 160), (96, 96)];
    for w in p.windows(2) {
        wall(&mut m, w[0], w[1], 0);
    }
    m.things.push(Thing { x: 32, y: 32, face: 0, item: 1, lev: 7 });
    finish(m)
}

// ---------- BSP structural checker ----------

fn segs_under(m: &MapData, child: i16) -> Vec<Seg> {
    if (child as u16) & 0x8000 != 0 {
        let ss = m.ssectors[((child as u16) & 0x7fff) as usize];
        m.segs[ss.segs as usize..(ss.segs + ss.num) as usize].to_vec()
    } else {
        let n = m.nodes[child as usize];
        let mut v = segs_under(m, n.ssector1);
        v.extend(segs_under(m, n.ssector2));
        v
    }
}

fn len(m: &MapData, s: &Seg) -> f64 {
    let (a, b) = (m.vertexes[s.from as usize], m.vertexes[s.to as usize]);
    (((a.x - b.x) as f64).powi(2) + ((a.y - b.y) as f64).powi(2)).sqrt()
}

fn check_bsp(m: &MapData, check_distances: bool) {
    assert_eq!(m.ssectors.len(), m.nodes.len() + 1, "binary tree: leaves = nodes + 1");
    let total: i32 = m.ssectors.iter().map(|s| s.num as i32).sum();
    assert_eq!(total as usize, m.segs.len(), "every seg is in exactly one subsector");
    let mut next = 0;
    for s in &m.ssectors {
        assert_eq!(s.segs as i32, next, "subsector seg ranges are contiguous");
        next += s.num as i32;
    }

    // every linedef side is covered by one chain of segs from its start to its end
    for (i, l) in m.linedefs.iter().enumerate() {
        for normal in [0i16, 1] {
            if normal == 1 && !l.two_sided() {
                continue;
            }
            let (start, end) = if normal == 0 { (l.from, l.to) } else { (l.to, l.from) };
            let mine: Vec<&Seg> = m.segs.iter().filter(|s| s.linedef == i as i16 && s.normal == normal).collect();
            let by_from: HashMap<i16, &Seg> = mine.iter().map(|s| (s.from, *s)).collect();
            assert_eq!(by_from.len(), mine.len(), "linedef {i}/{normal}: duplicate start vertex");
            let (mut at, mut seen, mut prev): (i16, usize, Option<&Seg>) = (start, 0, None);
            while at != end {
                let s = by_from.get(&at).unwrap_or_else(|| panic!("linedef {i}/{normal}: chain broken at vertex {at}"));
                if let (true, Some(p)) = (check_distances, prev) {
                    let expect = p.distance as f64 + len(m, p);
                    assert!(
                        (s.distance as f64 - expect).abs() <= 3.0,
                        "linedef {i}/{normal}: offset {} but previous piece ends at {expect:.1}",
                        s.distance
                    );
                }
                prev = Some(s);
                at = s.to;
                seen += 1;
                assert!(seen <= mine.len());
            }
            assert_eq!(seen, mine.len(), "linedef {i}/{normal}: stray segs");
        }
    }

    // every node: right segs lie right of its line, left segs left, bounds hold
    for n in &m.nodes {
        let pd = ((n.dx as f64).powi(2) + (n.dy as f64).powi(2)).sqrt();
        let val = |v: Vertex| n.dx as f64 * (v.y as f64 - n.y as f64) - n.dy as f64 * (v.x as f64 - n.x as f64);
        for (child, is_right, b) in [
            (n.ssector1, true, (n.minx1, n.maxx1, n.miny1, n.maxy1)),
            (n.ssector2, false, (n.minx2, n.maxx2, n.miny2, n.maxy2)),
        ] {
            for s in segs_under(m, child) {
                for vi in [s.from, s.to] {
                    let v = m.vertexes[vi as usize];
                    if is_right {
                        assert!(val(v) <= 2.0 * pd, "right-side seg strays left of its node line");
                    } else {
                        assert!(val(v) >= -2.0 * pd, "left-side seg strays right of its node line");
                    }
                    assert!(v.x >= b.0 && v.x <= b.1 && v.y >= b.2 && v.y <= b.3, "seg outside node bounds");
                }
            }
        }
    }
}

// ---------- node builder ----------

#[derive(Default)]
struct Counter {
    progress: usize,
    problems: usize,
    splits: usize,
}
impl BuildObserver for Counter {
    fn split(&mut self, _: (i16, i16), _: (i16, i16)) {
        self.splits += 1;
    }
    fn problem(&mut self, _: (i16, i16), _: (i16, i16)) {
        self.problems += 1;
    }
    fn progress(&mut self) {
        self.progress += 1;
    }
}

#[test]
fn convex_room_gives_one_node_and_an_empty_left_subsector() {
    let mut m = MapData::new("E1M1");
    room_cw(&mut m, 0, 0, 256, 0);
    let mut m = finish(m);
    let mut obs = Counter::default();
    let st = m.build_nodes(&Quirks::original(), &mut obs).unwrap();
    assert_eq!((st.nodes, st.ssectors, st.segs, st.splits), (1, 2, 4, 0));
    // the original's "potential problem" case: nothing is on the left
    assert_eq!(m.ssectors, vec![SSector { num: 0, segs: 0 }, SSector { num: 4, segs: 0 }]);
    assert_eq!((obs.progress, obs.problems), (2, 1));
    let n = m.nodes[0];
    assert_eq!((n.x, n.y, n.dx, n.dy), (0, 0, 0, 256));
    assert_eq!(n.ssector1 as u16, 0x8001); // right: subsector 1
    assert_eq!(n.ssector2 as u16, 0x8000); // left: subsector 0
    assert_eq!((n.minx1, n.maxx1, n.miny1, n.maxy1), (0, 256, 0, 256));
    assert_eq!((n.minx2, n.maxx2, n.miny2, n.maxy2), (32767, -32767, 32767, -32767));
    check_bsp(&m, true);
    assert!(!m.nodes_dirty);
}

#[test]
fn seg_angles_use_bams() {
    let mut m = MapData::new("E1M1");
    room_cw(&mut m, 0, 0, 256, 0);
    let mut m = finish(m);
    m.build_nodes(&Quirks::original(), &mut NoObserver).unwrap();
    let mut by_line = vec![0i16; 4];
    for s in &m.segs {
        by_line[s.linedef as usize] = s.angle;
    }
    assert_eq!(by_line, [16384, 0, -16384, BAMS180]); // north, east, south, west
}

#[test]
fn two_sided_line_makes_a_left_seg_facing_back() {
    let mut m = MapData::new("E1M1");
    // room A (sector 0) | room B (sector 1) sharing one two-sided wall
    wall(&mut m, (0, 0), (0, 128), 0);
    wall(&mut m, (0, 128), (128, 128), 0);
    let shared = portal(&mut m, (128, 128), (128, 0), 0, 1);
    wall(&mut m, (128, 0), (0, 0), 0);
    wall(&mut m, (128, 128), (256, 128), 1);
    wall(&mut m, (256, 128), (256, 0), 1);
    wall(&mut m, (256, 0), (128, 0), 1);
    let mut m = finish(m);
    let st = m.build_nodes(&Quirks::original(), &mut NoObserver).unwrap();
    assert_eq!(st.segs - st.splits, 8, "7 linedefs, one of them two-sided");
    let (r, l): (Vec<Seg>, Vec<Seg>) =
        m.segs.iter().copied().filter(|s| s.linedef == shared as i16).partition(|s| s.normal == 0);
    assert!(!r.is_empty() && !l.is_empty());
    assert_eq!(r[0].angle, -16384); // south
    assert_eq!(l[0].angle, 16384, "left seg = right angle + 180 degrees");
    check_bsp(&m, true);
}

#[test]
fn pillar_room_forces_splits_and_stays_a_valid_bsp() {
    for q in [Quirks::original(), Quirks::corrected()] {
        let mut m = pillar_room();
        let mut obs = Counter::default();
        let st = m.build_nodes(&q, &mut obs).unwrap();
        assert!(st.splits >= 2, "extended pillar edges must cut the walls");
        assert_eq!(obs.splits, st.splits);
        assert_eq!(st.segs, 8 + st.splits);
        check_bsp(&m, !q.split_offset_from_wrong_end);
        // no linedef or vertex references broke
        assert!(m.segs.iter().all(|s| (s.from as usize) < m.vertexes.len() && (s.to as usize) < m.vertexes.len()));
    }
}

#[test]
fn split_vertices_reuse_unused_vertex_slots_first() {
    let mut m = pillar_room();
    let used_before = m.vertexes.len();
    m.vertexes.push(Vertex { x: 1234, y: 1234 }); // orphan: no linedef uses it
    let m_len = m.vertexes.len();
    let mut m = finish(m);
    let st = m.build_nodes(&Quirks::original(), &mut NoObserver).unwrap();
    assert!(st.splits >= 1);
    assert_eq!(m.vertexes.len(), used_before + st.splits, "orphan slot reused, rest appended");
    assert_eq!(m.vertexes.len(), m_len + st.splits - 1);
    assert_ne!(m.vertexes[used_before], Vertex { x: 1234, y: 1234 });
}

#[test]
fn partition_score_wraps_in_16_bit_like_the_original() {
    let (o, c) = (Quirks::original(), Quirks::corrected());
    assert_eq!(partition_score(3, 4, 0, &o), 1200);
    assert_eq!(partition_score(3, 4, 0, &c), 1200);
    // 100 * 50 * 50 = 250000, which wraps to -12144 in 16 bits
    assert_eq!(partition_score(50, 50, 0, &o), -12144);
    assert_eq!(partition_score(50, 50, 0, &c), 250000);
    // divisor: 16 * 2 / 3 + 1 = 11
    assert_eq!(partition_score(10, 10, 2, &o), 10000 / 11);
}

#[test]
fn builder_errors_instead_of_crashing() {
    let mut m = finish(MapData::new("E1M1"));
    assert_eq!(m.build_nodes(&Quirks::default(), &mut NoObserver), Err(BuildError::NoLinedefs));
    let mut m = MapData::new("E1M1");
    m.vertexes.push(Vertex::default());
    m.linedefs.push(LineDef { from: 0, to: 5, sidedef1: 0, sidedef2: NOTHING, ..Default::default() });
    let mut m = finish(m);
    assert_eq!(m.build_nodes(&Quirks::default(), &mut NoObserver), Err(BuildError::BadVertexRef { linedef: 0 }));
}

// ---------- blockmap ----------

fn parse_blockmap(b: &[u8]) -> (i16, i16, i16, i16, Vec<Vec<i16>>) {
    let w: Vec<i16> = b.chunks_exact(2).map(|c| i16::from_le_bytes([c[0], c[1]])).collect();
    let (xo, yo, xn, yn) = (w[0], w[1], w[2], w[3]);
    let mut blocks = vec![];
    for i in 0..(xn as usize * yn as usize) {
        let mut o = w[4 + i] as usize;
        assert_eq!(w[o], 0, "block list starts with 0");
        o += 1;
        let mut list = vec![];
        while w[o] != -1 {
            list.push(w[o]);
            o += 1;
        }
        blocks.push(list);
    }
    (xo, yo, xn, yn, blocks)
}

#[test]
fn blockmap_of_a_square_room() {
    let mut m = MapData::new("E1M1");
    room_cw(&mut m, 0, 0, 256, 0);
    let mut m = finish(m);
    for q in [Quirks::original(), Quirks::corrected()] {
        m.build_blockmap(&q);
        let (xo, yo, xn, yn, blocks) = parse_blockmap(&m.blockmap);
        assert_eq!((xo, yo, xn, yn), (-8, -8, 3, 3));
        let expect: Vec<Vec<i16>> =
            vec![vec![0, 3], vec![3], vec![2, 3], vec![0], vec![], vec![2], vec![0, 1], vec![1], vec![1, 2]];
        assert_eq!(blocks, expect);
    }
}

#[test]
fn blockmap_steep_diagonal_wraps_only_with_original_quirks() {
    let mut m = MapData::new("E1M1");
    wall(&mut m, (0, 0), (200, 0), 0); // widens the grid to 2 columns in both modes
    let steep = wall(&mut m, (118, 0), (126, 400), 0); // slope 50:1 straddling a block edge
    let mut m = finish(m);
    let blocks_of = |m: &mut MapData, q: Quirks| -> Vec<usize> {
        m.build_blockmap(&q);
        let (_, _, xn, yn, blocks) = parse_blockmap(&m.blockmap);
        assert_eq!((xn, yn), (2, 4));
        (0..blocks.len()).filter(|&b| blocks[b].contains(&(steep as i16))).collect()
    };
    let good = blocks_of(&mut m, Quirks::corrected());
    assert!(good.contains(&0) && good.contains(&7), "start block (0,0) and end block (1,3): {good:?}");
    let bad = blocks_of(&mut m, Quirks::original());
    assert_ne!(good, bad, "16-bit slope wraps for steep lines in the original");
}

#[test]
fn blockmap_grid_is_one_short_in_original_for_some_sizes() {
    let mut m = MapData::new("E1M1");
    wall(&mut m, (0, 0), (250, 0), 0);
    wall(&mut m, (250, 0), (0, 0), 0);
    let mut m = finish(m);
    m.build_blockmap(&Quirks::original());
    assert_eq!(parse_blockmap(&m.blockmap).2, 2);
    m.build_blockmap(&Quirks::corrected());
    assert_eq!(parse_blockmap(&m.blockmap).2, 3);
}

// ---------- reject ----------

fn four_rooms() -> MapData {
    let mut m = MapData::new("E1M1");
    // A and B are close, C and D are close, the pairs are far apart
    for (sector, x) in [(0, 0), (1, 300), (2, 1500), (3, 1700)] {
        room_cw(&mut m, x, 0, 64, sector);
    }
    finish(m)
}

#[test]
fn reject_quick_and_full_agree_on_well_separated_rooms() {
    for method in [RejectMethod::Quick, RejectMethod::Full] {
        let mut m = four_rooms();
        m.build_reject(method, &Quirks::original());
        // bit = from * 4 + to; cleared: A<->A,B and C<->C,D
        assert_eq!(m.reject, vec![0xCC, 0x33], "{method:?}");
    }
}

#[test]
fn reject_lump_is_too_short_in_original_when_sectors_not_multiple_of_4() {
    let mut m = MapData::new("E1M1");
    for s in 0..3 {
        room_cw(&mut m, s * 200, 0, 64, s);
    }
    let mut m = finish(m);
    m.build_reject(RejectMethod::Quick, &Quirks::original());
    assert_eq!(m.reject.len(), 1); // 9 bits / 8, rounded down
    m.build_reject(RejectMethod::Quick, &Quirks::corrected());
    assert_eq!(m.reject.len(), 2);
}

// ---------- full save pipeline ----------

#[test]
fn prepare_for_save_runs_the_original_sequence_and_roundtrips() {
    let mut m = pillar_room();
    // an item the user deleted must not survive packing
    m.linedef_flags.push(Flags { used: false, ..Flags::default() });
    m.linedefs.push(LineDef { from: 0, to: 1, sidedef1: NOTHING, sidedef2: NOTHING, ..Default::default() });
    m.mark_nodes_dirty();
    let nlines = m.linedefs.len() - 1;

    let out = m.prepare_for_save(&SaveOptions { quirks: Quirks::original(), ..SaveOptions::default() }, &mut NoObserver).unwrap();
    let PrepareOutcome::Built(st) = out else { panic!("expected a build, got {out:?}") };
    assert_eq!(m.linedefs.len(), nlines, "PackMap ran first");
    assert!(!m.blockmap.is_empty());
    assert!(m.reject.is_empty(), "1 sector: 1*1/8 rounds down to 0 bytes in the original");
    assert_eq!(m.nodes.len(), st.nodes);
    assert!(!m.nodes_dirty);
    check_bsp(&m, false);

    // not dirty any more: nothing to do
    assert_eq!(m.prepare_for_save(&SaveOptions::default(), &mut NoObserver).unwrap(), PrepareOutcome::UpToDate);

    // write and read back through real WAD bytes
    let mut wad = Wad::new_pwad();
    m.save_into(&mut wad);
    let wad = Wad::from_bytes(&wad.to_bytes()).unwrap();
    let back = MapData::load(&wad, 0).unwrap();
    assert_eq!(back.nodes, m.nodes);
    assert_eq!(back.segs, m.segs);
    assert_eq!(back.ssectors, m.ssectors);
    assert_eq!(back.blockmap, m.blockmap);
    assert_eq!(back.reject, m.reject);
    check_bsp(&back, false);
}

#[test]
fn node_action_none_skips_nodes_but_keeps_them_dirty() {
    let mut m = pillar_room();
    m.mark_nodes_dirty();
    let opts = SaveOptions { node_action: NodeAction::None, ..SaveOptions::default() };
    assert_eq!(m.prepare_for_save(&opts, &mut NoObserver).unwrap(), PrepareOutcome::NodesSkipped);
    assert!(m.nodes.is_empty() && m.nodes_dirty && !m.blockmap.is_empty());
    let opts = SaveOptions { node_action: NodeAction::IdBsp, ..SaveOptions::default() };
    assert!(matches!(m.prepare_for_save(&opts, &mut NoObserver), Err(PrepareError::IdBspNotPorted)));
}

// ---------- larger map: exercises the 16-bit scoring range ----------

fn pillar_field(cols: i16, rows: i16, seed: u32) -> MapData {
    let mut m = MapData::new("E1M1");
    room_cw(&mut m, 0, 0, cols.max(rows) * 64, 0);
    let mut rng = seed;
    let mut next = move || {
        rng = rng.wrapping_mul(1664525).wrapping_add(1013904223);
        (rng >> 16) as i16
    };
    for cy in 0..rows {
        for cx in 0..cols {
            if next() % 3 == 0 {
                continue;
            }
            let (x, y) = (cx * 64 + 12 + next() % 8, cy * 64 + 12 + next() % 8);
            let s = 24 + next() % 12;
            let p = [(x, y), (x + s, y), (x + s, y + s), (x, y + s), (x, y)];
            for w in p.windows(2) {
                wall(&mut m, w[0], w[1], 0); // counter-clockwise: solid inside
            }
        }
    }
    finish(m)
}

#[test]
fn many_pillars_build_valid_trees_in_both_modes() {
    for seed in [1, 7, 42] {
        let mut sizes = vec![];
        for q in [Quirks::original(), Quirks::corrected()] {
            let mut m = pillar_field(8, 8, seed);
            assert!(m.linedefs.len() > 100, "want nodes with well over 18 segs per side");
            let st = m.build_nodes(&q, &mut NoObserver).unwrap();
            check_bsp(&m, !q.split_offset_from_wrong_end);
            m.build_blockmap(&q);
            m.build_reject(RejectMethod::Quick, &q);
            sizes.push((st.nodes, st.splits));
        }
        println!("seed {seed}: original {:?}, corrected {:?}", sizes[0], sizes[1]);
    }
}

#[test]
fn rebuilding_a_saved_map_is_deterministic() {
    let mut m = pillar_field(6, 6, 9);
    m.mark_nodes_dirty();
    m.prepare_for_save(&SaveOptions { quirks: Quirks::original(), ..SaveOptions::default() }, &mut NoObserver).unwrap();
    let mut wad = Wad::new_pwad();
    m.save_into(&mut wad);
    let wad = Wad::from_bytes(&wad.to_bytes()).unwrap();
    let orig = MapData::load(&wad, 0).unwrap();
    // same steps as the `rebuild` example
    let mut again = orig.clone();
    let q = Quirks::original();
    again.build_blockmap(&q);
    again.build_reject(RejectMethod::Quick, &q);
    again.build_nodes(&q, &mut NoObserver).unwrap();
    assert_eq!(again.nodes, orig.nodes);
    assert_eq!(again.segs, orig.segs);
    assert_eq!(again.ssectors, orig.ssectors);
    assert_eq!(again.blockmap, orig.blockmap);
    assert_eq!(again.reject, orig.reject);
}

#[test]
fn saving_corrects_the_originals_bugs_by_default() {
    assert_eq!(SaveOptions::default().quirks, Quirks::corrected());
}
