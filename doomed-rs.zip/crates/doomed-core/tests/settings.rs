use doomed_core::*;

#[test]
fn defaults_match_the_original_ini_defaults() {
    let s = Settings::from_text("");
    assert_eq!(s.colors, Colors::default());
    assert_eq!((s.options.grid_size, s.options.node_builder, s.options.reject_builder), (16, 2, 2));
    assert!(s.options.show_64_grid && !s.options.show_snap_to_grid && s.options.verify_exit);
    assert_eq!(s.styles.len(), 3);
    assert_eq!(s.styles[0].name, "Stone floor, Stone walls");
    assert_eq!((s.default_wall.as_str(), s.default_floor.as_str(), s.default_ceil.as_str()), ("GRAY1", "FLOOR0_5", "FLAT9"));
    assert_eq!((s.floor_height, s.ceiling_height, s.light), (0, 128, 200));
    assert_eq!(s.save_options().node_action, NodeAction::Internal);
    assert_eq!(s.save_options().reject_method, RejectMethod::Full);
}

#[test]
fn an_existing_ini_loads_with_the_original_names() {
    let text = "[Colors]\nSelected=FF00FF\nBackground=202020\n[Options]\nGridSize=32\nNodeBuilder=1\nRejectBuilder=1\nShow64x64Grid=0\n\
                [Files]\nRecentFile1=C:\\DOOM\\E1M1.WAD\n[Styles]\nNumberOfStyles=1\n[Style0]\nName=Brick\nFloor=FLOOR4_8\nCeiling=CEIL3_5\nWalls=BRICK1\n\
                [DefaultSettings]\nWalls=null\nFloor=FLAT1\nLight=160\n[Builders]\nNumberOfBuilders=1\n[Builder0]\nName=BSP\nCommand=bsp.exe\nFormat=1\n";
    let s = Settings::from_text(text);
    assert_eq!(s.colors.background, 0x202020);
    assert_eq!(s.options.grid_size, 32);
    assert_eq!(s.save_options().node_action, NodeAction::None);
    assert_eq!(s.save_options().reject_method, RejectMethod::Quick);
    assert!(!s.options.show_64_grid);
    assert_eq!(s.recent_files[0], "C:\\DOOM\\E1M1.WAD");
    assert_eq!(s.styles, vec![Style::new("Brick", "BRICK1", "FLOOR4_8", "CEIL3_5")]);
    assert_eq!(s.default_wall, "BRICK1", "\"null\" falls back to style 0");
    assert_eq!(s.default_floor, "FLAT1");
    assert_eq!(s.light, 160);
    assert_eq!(s.builders, vec![Builder { name: "BSP".into(), command: "bsp.exe".into(), format: 1 }]);
}

#[test]
fn settings_round_trip_and_keep_unknown_sections() {
    let mut s = Settings::default();
    s.colors.selected = 0x123456;
    s.options.grid_size = 24;
    s.styles.push(Style::new("Mine", "A", "B", "C"));
    s.add_recent("one.wad");
    s.add_recent("two.wad");
    s.add_recent("one.wad");
    assert_eq!(&s.recent_files[..3], ["one.wad", "two.wad", ""]);
    let text = s.to_text(Some("[Custom Colors]\nColor0=1\n"));
    assert!(text.contains("[Custom Colors]") && text.contains("Selected=123456"));
    assert_eq!(Settings::from_text(&text), s);
    // removing a style removes its section
    s.styles.pop();
    let text2 = s.to_text(Some(&text));
    assert!(!text2.contains("Mine"));
    assert_eq!(Settings::from_text(&text2), s);
}

#[test]
fn colorref_is_blue_green_red() {
    assert_eq!(colors_rgb(0x833FC0), (0xC0, 0x3F, 0x83));
    assert_eq!(settings::rgb_colorref(0xC0, 0x3F, 0x83), 0x833FC0);
}
fn colors_rgb(c: u32) -> (u8, u8, u8) { settings::colorref_rgb(c) }

fn wall_room() -> MapData {
    let mut m = MapData::new("E1M1");
    m.sectors.push(m.defaults.sector);
    for &(x, y) in &[(0i16, 0i16), (0, 64), (64, 64), (64, 0)] {
        m.vertexes.push(Vertex { x, y });
    }
    for i in 0..4i16 {
        m.sidedefs.push(SideDef { t3: to_name8("MARBLE1"), t1: null_wall(), t2: null_wall(), sector: 0, ..Default::default() });
        m.linedefs.push(LineDef { from: i, to: (i + 1) % 4, solidity: 1, sidedef1: i, sidedef2: NOTHING, ..Default::default() });
    }
    m.things.push(Thing { x: 32, y: 32, face: 90, item: 1, lev: 7 });
    m.normalize_flags();
    m
}

#[test]
fn apply_style_only_touches_set_textures_of_selected_sectors() {
    let mut m = wall_room();
    assert_eq!(m.apply_style(&Style::new("x", "BRICK1", "F1", "C1")), 0, "nothing selected");
    m.select(Kind::Sector, 0);
    assert_eq!(m.apply_style(&Style::new("x", "BRICK1", "F1", "C1")), 1);
    assert_eq!(m.sidedefs[0].t3, to_name8("BRICK1"));
    assert_eq!(m.sidedefs[0].t1[0], b'-', "an unset upper stays unset");
    assert_eq!((m.sectors[0].floor, m.sectors[0].ceil), (to_name8("F1"), to_name8("C1")));
}

#[test]
fn dwd_export_has_the_worldserver_layout() {
    let mut m = wall_room();
    let d = m.export_dwd();
    let lines: Vec<&str> = d.lines().collect();
    assert_eq!(&lines[..3], ["WorldServer version 4", "level:E1M1", "lines:4"]);
    assert_eq!(lines[3], "(0,0) to (0,64) : 1 : 0 : 0");
    assert!(lines[4].starts_with("    0 (0 : -"), "{}", lines[4]);
    assert!(lines[5].starts_with("    0 : "), "{}", lines[5]);
    assert!(d.contains("\nthings:1\n(32,32, 90) :1, 7\n"));
}

#[test]
fn custom_colors_round_trip_through_the_ini() {
    let mut s = Settings::default();
    s.custom_colors[0] = 0x0000FF;
    s.custom_colors[15] = 0xABCDEF;
    let text = s.to_text(None);
    assert!(text.contains("[Custom Colors]") && text.contains("ColorA=FF") && text.contains("ColorP=ABCDEF"));
    let back = Settings::from_text(&text);
    assert_eq!(back.custom_colors, s.custom_colors);
    assert_eq!(Settings::from_text("").custom_colors, [0; 16]);
}

#[test]
fn the_iwad_path_survives_a_save_and_reload() {
    use doomed_core::settings::Settings;
    let mut s = Settings::default();
    s.iwad = "C:\\games\\DOOM2.WAD".into();
    let back = Settings::from_text(&s.to_text(None));
    assert_eq!(back.iwad, "C:\\games\\DOOM2.WAD");
}
