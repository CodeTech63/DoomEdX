use doomed_core::preview3d::*;
use doomed_core::*;

fn room() -> MapData {
    let mut m = MapData::new("E1M1");
    m.sectors.push(m.defaults.sector);
    m.sectors[0].floor_z = 0;
    m.sectors[0].ceil_z = 128;
    let pts = [(0, 0), (0, 256), (256, 256), (256, 0)];
    for &(x, y) in &pts {
        m.vertexes.push(Vertex { x, y });
    }
    for i in 0..4 {
        m.sidedefs.push(SideDef { sector: 0, ..Default::default() });
        m.linedefs.push(LineDef { from: i, to: (i + 1) % 4, solidity: 1, sidedef1: i, sidedef2: NOTHING, ..Default::default() });
    }
    m.normalize_flags();
    m
}

#[test]
fn a_room_is_four_floor_to_ceiling_panels() {
    let p = panels(&room());
    assert_eq!(p.len(), 4);
    assert_eq!((p[0].p1, p[0].p2), ((0, 0, 0), (0, 256, 128)));
}

#[test]
fn two_sided_lines_only_get_panels_where_heights_differ() {
    let mut m = room();
    m.sectors.push(Sector { floor_z: 16, ceil_z: 128, ..m.defaults.sector });
    m.sidedefs.push(SideDef { sector: 1, ..Default::default() });
    m.linedefs[0].solidity = 4;
    m.linedefs[0].sidedef2 = (m.sidedefs.len() - 1) as i16;
    m.normalize_flags();
    let p = panels(&m);
    assert_eq!(p.len(), 3 + 1, "3 solid walls + one step riser (ceilings match)");
    assert!(p.contains(&Panel { p1: (0, 0, 0), p2: (0, 256, 16) }));
}

#[test]
fn the_look_toward_point_projects_to_screen_centre() {
    let cam = Camera { vx: 1000, vy: 1000, vz: -200, ox: 128, oy: 128, oz: 0, zoom: 5 };
    // a panel whose corner is exactly the look-toward point at height 0
    let p = Panel { p1: (128, 128, 0), p2: (140, 128, 10) };
    let r = project(&[p], &cam, 800, 600, false);
    assert_eq!(r.len(), 1);
    let (x, y) = r[0].s[0];
    assert!((x - 400).abs() <= 2 && (y - 300).abs() <= 2, "({x},{y})");
}

#[test]
fn geometry_behind_the_viewer_is_dropped() {
    let cam = Camera { vx: 1000, vy: 0, vz: -50, ox: 0, oy: 0, oz: 0, zoom: 5 };
    let behind = Panel { p1: (3000, 0, 0), p2: (3000, 64, 64) };
    assert!(project(&[behind], &cam, 800, 600, false).is_empty());
    let ahead = Panel { p1: (0, 0, 0), p2: (0, 64, 64) };
    assert_eq!(project(&[ahead], &cam, 800, 600, false).len(), 1);
}

#[test]
fn hidden_mode_sorts_far_to_near() {
    let cam = Camera { vx: 1000, vy: 0, vz: -50, ox: 0, oy: 0, oz: 0, zoom: 5 };
    let near = Panel { p1: (400, 0, 0), p2: (400, 64, 64) };
    let far = Panel { p1: (-300, 0, 0), p2: (-300, 64, 64) };
    let r = project(&[near, far], &cam, 800, 600, true);
    assert_eq!(r.len(), 2);
    assert!(r[0].distance > r[1].distance);
}

#[test]
fn orbit_keeps_the_distance_and_dolly_changes_it() {
    let mut c = Camera { vx: 1000, vy: 0, vz: -200, ox: 0, oy: 0, oz: 0, zoom: 5 };
    c.orbit(90, 0); // 45 degrees
    let d = ((c.vx * c.vx + c.vy * c.vy) as f64).sqrt();
    assert!((d - 1000.0).abs() < 3.0, "{d}");
    assert!(c.vy != 0);
    let mut c = Camera { vx: 1000, vy: 0, vz: -200, ox: 0, oy: 0, oz: 0, zoom: 5 };
    c.dolly(10);
    assert_eq!(c.vx, 900);
    c.orbit(0, 3);
    assert_eq!(c.vz, -170);
    c.turn(0, -2);
    assert_eq!(c.oz, -20);
}

#[test]
fn camera_opens_on_the_map_centre() {
    let c = Camera::for_extent(Some(Rect { left: 0, right: 400, top: 200, bottom: 0 }));
    assert_eq!((c.ox, c.oy), (200, 100));
}

#[test]
fn wheel_moves_the_viewer_along_the_line_to_the_target() {
    use doomed_core::preview3d::Camera;
    let mut c = Camera { vx: 1000, vy: 0, vz: -100, ox: 0, oy: 0, oz: 0, zoom: 5 };
    c.wheel(1);
    assert_eq!((c.vx, c.vy, c.vz), (850, 0, -100), "nearer, same height");
    c.wheel(-1);
    assert!((c.vx - 1000).abs() <= 1, "and back out");
    for _ in 0..100 {
        c.wheel(1);
    }
    assert_eq!(c.vx, 16, "stops 16 units from the target");
}
