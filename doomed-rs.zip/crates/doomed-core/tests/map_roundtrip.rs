use doomed_core::*;

#[test]
fn record_sizes_match_original_structs() {
    assert_eq!(Thing::SIZE, 10);
    assert_eq!(LineDef::SIZE, 14);
    assert_eq!(SideDef::SIZE, 30);
    assert_eq!(Vertex::SIZE, 4);
    assert_eq!(Seg::SIZE, 12);
    assert_eq!(SSector::SIZE, 4);
    assert_eq!(Node::SIZE, 28);
    assert_eq!(Sector::SIZE, 26);
    assert_eq!(Tag::SIZE, 274);
}

#[test]
fn record_bytes_roundtrip() {
    let sd = SideDef { x: -3, y: 9, t1: to_name8("STARTAN1"), t2: null_wall(), t3: to_name8("DOOR"), sector: 4 };
    let mut b = vec![];
    sd.write(&mut b);
    assert_eq!(b.len(), 30);
    assert_eq!(SideDef::read(&b), sd);
    let t = Tag { num: 7, name: "Lift".into(), desc: "Main lift".into() };
    let mut b = vec![];
    t.write(&mut b);
    assert_eq!(b.len(), 274);
    assert_eq!(Tag::read(&b), t);
}

#[test]
fn wall_macros() {
    assert_eq!(null_wall(), *b"-\0\0\0\0\0\0\0");
    assert_eq!(copy_wall(b"AB\0garbage"), *b"AB\0\0\0\0\0\0");
    assert_eq!(copy_wall(b"LONGERTHAN8"), *b"LONGERTH");
    let mut l = LineDef::default();
    l.set_bit(line_bits::TWO_SIDED | line_bits::SECRET);
    l.clear_bit(line_bits::TWO_SIDED);
    assert!(l.test_bit(line_bits::SECRET) && !l.test_bit(line_bits::TWO_SIDED));
}

/// A 128x128 room: 4 vertices, 4 one-sided linedefs, 1 sector, 2 things.
fn room(name: &str, sector_tag: i16) -> MapData {
    let mut m = MapData::new(name);
    m.vertexes = vec![Vertex { x: 0, y: 0 }, Vertex { x: 128, y: 0 }, Vertex { x: 128, y: 128 }, Vertex { x: 0, y: 128 }];
    for i in 0..4i16 {
        m.linedefs.push(LineDef { from: i, to: (i + 1) % 4, solidity: 1, special: 0, tag: 0, sidedef1: i, sidedef2: NOTHING });
        m.sidedefs.push(SideDef { t3: to_name8("STARTAN1"), t1: null_wall(), t2: null_wall(), sector: 0, ..Default::default() });
    }
    m.sectors = vec![Sector { ceil_z: 128, floor: to_name8("FLOOR4_8"), ceil: to_name8("CEIL3_5"), light: 160, tag: sector_tag, ..Default::default() }];
    m.things = vec![Thing { x: 64, y: 64, face: 90, item: 1, lev: 7 }, Thing { x: 32, y: 32, face: 0, item: 2001, lev: 7 }];
    m.thing_flags = vec![Flags::default(); 2];
    m.linedef_flags = vec![Flags::default(); 4];
    m.sidedef_flags = vec![Flags::default(); 4];
    m.sector_flags = vec![Flags::default(); 1];
    m.vertex_flags = vec![Flags::default(); 4];
    m
}

fn base_wad() -> Wad {
    let mut w = Wad::new_pwad();
    w.entries.push(WadEntry::new("PLAYPAL", vec![1; 4]));
    w.entries.push(WadEntry::new("DSBOOM", vec![2; 4]));
    w.classify();
    w
}

#[test]
fn save_appends_then_loads_back_identically() {
    let m = room("E1M1", 0);
    let mut wad = base_wad();
    let at = m.save_into(&mut wad);
    assert_eq!(at, 2);
    let titles: Vec<_> = wad.entries[2..].iter().map(|e| e.title.as_str()).collect();
    assert_eq!(
        titles,
        ["E1M1", "THINGS", "LINEDEFS", "SIDEDEFS", "VERTEXES", "SEGS", "SSECTORS", "NODES", "SECTORS", "REJECT", "BLOCKMAP", "TAGDESC"]
    );
    assert_eq!(wad.entries[2].ty, WadType::Map);

    // through actual bytes
    let wad = Wad::from_bytes(&wad.to_bytes()).unwrap();
    let back = MapData::load(&wad, wad.maps()[0]).unwrap();
    assert_eq!(back.name, "E1M1");
    assert_eq!(back.things, m.things);
    assert_eq!(back.vertexes, m.vertexes);
    assert_eq!(back.linedefs, m.linedefs);
    assert_eq!(back.sidedefs, m.sidedefs);
    assert_eq!(back.sectors, m.sectors);
    assert!(back.vertex_flags.iter().all(|f| f.used));
}

#[test]
fn save_replaces_existing_map_in_place() {
    let mut wad = base_wad();
    room("E1M1", 0).save_into(&mut wad);
    wad.entries.push(WadEntry::new("DSLAST", vec![9; 2]));
    wad.classify();
    let before = wad.entries.len();

    let mut edited = room("E1M1", 0);
    edited.things.push(Thing { x: 1, y: 1, face: 0, item: 3004, lev: 7 });
    let at = edited.save_into(&mut wad);

    assert_eq!(at, 2);
    assert_eq!(wad.entries.len(), before, "old group must be replaced, not duplicated");
    assert_eq!(wad.entries.last().unwrap().title, "DSLAST");
    assert_eq!(MapData::load(&wad, at).unwrap().things.len(), 3);
}

#[test]
fn second_map_keeps_first() {
    let mut wad = base_wad();
    room("E1M1", 0).save_into(&mut wad);
    let h2 = room("E1M2", 0).save_into(&mut wad);
    assert_eq!(wad.maps().len(), 2);
    assert_eq!(wad.entries[h2].title, "E1M2");
}

#[test]
fn tags_derived_from_sectors_when_no_tag_lump() {
    let mut w = Wad::new_pwad();
    let mut m = room("E1M1", 5);
    m.save_into(&mut w);
    // strip the TAGDESC lump the save added
    let i = w.find("TAGDESC").unwrap();
    w.entries.remove(i);
    w.classify();
    m = MapData::load(&w, 0).unwrap();
    assert_eq!(m.tags.len(), 2);
    assert_eq!(m.tags[0], Tag::none());
    assert_eq!(m.tags[1], Tag { num: 5, name: "Tag5".into(), desc: String::new() });
    assert_eq!(m.next_tag, 6);
}

#[test]
fn tag_lump_roundtrips_and_drops_zero_entries() {
    let mut m = room("E1M1", 0);
    m.tags.push(Tag { num: 3, name: "Door".into(), desc: "East door".into() });
    m.tags.push(Tag { num: 0, name: "stale".into(), desc: String::new() });
    m.tags.push(Tag { num: 9, name: "Lift".into(), desc: "".into() });
    let mut w = Wad::new_pwad();
    m.save_into(&mut w);
    let back = MapData::load(&w, 0).unwrap();
    let nums: Vec<_> = back.tags.iter().map(|t| t.num).collect();
    assert_eq!(nums, [0, 3, 9]);
    assert_eq!(back.next_tag, 10);
}

#[test]
fn extent_has_50_unit_border() {
    let m = room("E1M1", 0);
    assert_eq!(m.map_extent(), Some(Rect { left: -50, right: 178, top: 178, bottom: -50 }));
    assert_eq!(MapData::new("E1M1").map_extent(), None);
}

#[test]
fn pack_drops_deleted_orphans_and_compacts_sidedefs() {
    // two sectors; sector 0 gets orphaned by deleting its walls, sector 1 survives
    let mut m = room("E1M1", 0);
    m.sectors.push(Sector { floor: to_name8("FLAT1"), ..Default::default() });
    m.sector_flags.push(Flags::default());
    // second room's walls, sidedefs point at sector 1
    let base = m.vertexes.len() as i16;
    m.vertexes.extend([Vertex { x: 300, y: 0 }, Vertex { x: 400, y: 0 }, Vertex { x: 400, y: 100 }]);
    for i in 0..3i16 {
        m.linedefs.push(LineDef { from: base + i, to: base + (i + 1) % 3, solidity: 1, special: 0, tag: 0, sidedef1: 4 + i, sidedef2: NOTHING });
        m.sidedefs.push(SideDef { sector: 1, ..Default::default() });
    }
    m.linedef_flags = vec![Flags::default(); m.linedefs.len()];
    m.sidedef_flags = vec![Flags::default(); m.sidedefs.len()];
    m.vertex_flags = vec![Flags::default(); m.vertexes.len()];
    // user deletes the first room's four walls and one thing
    for f in &mut m.linedef_flags[0..4] {
        f.used = false;
    }
    m.thing_flags[1].used = false;

    m.pack();

    assert_eq!(m.sectors.len(), 1);
    assert_eq!(m.sectors[0].floor, to_name8("FLAT1"));
    assert_eq!(m.linedefs.len(), 3);
    assert_eq!(m.things.len(), 1);
    assert_eq!(m.sidedefs.len(), 3);
    assert!(m.sidedefs.iter().all(|s| s.sector == 0), "sector refs must be renumbered");
    let sides: Vec<_> = m.linedefs.iter().map(|l| l.sidedef1).collect();
    assert_eq!(sides, [0, 1, 2], "sidedefs packed in linedef order");
    assert!(m.linedef_flags.len() == 3 && m.sidedef_flags.len() == 3 && m.sector_flags.len() == 1);
}
