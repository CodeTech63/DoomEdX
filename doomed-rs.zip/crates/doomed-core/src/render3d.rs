//! A software textured renderer for the 3D preview (an addition to the
//! original, which only drew wireframe / hidden-line panels).
//!
//! Geometry comes from the same map data as `preview3d`; the camera and view
//! matrix are shared so both views agree. Walls follow the Doom peg rules
//! (upper/lower unpegged, x/y offsets), floors and ceilings are 64x64 flats
//! anchored at the map origin. Rasterisation is perspective-correct with a
//! depth buffer; back faces are culled so rooms can be viewed from outside.

use std::collections::HashMap;

use crate::gfx::{GfxAssets, Image};
use crate::map::{is_used, MapData};
use crate::preview3d::Camera;
use crate::sectorfill::Trap;
use crate::structs::{line_bits, NOTHING};

/// Lazily loaded wall textures and flats.
#[derive(Default)]
pub struct TexCache {
    walls: HashMap<String, Option<Image>>,
    flats: HashMap<String, Option<Image>>,
    sprites: HashMap<String, Option<(Image, i16, i16)>>,
}

impl TexCache {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn clear(&mut self) {
        self.walls.clear();
        self.flats.clear();
        self.sprites.clear();
    }
    fn load_wall(&mut self, g: &GfxAssets, n: &str) -> Option<&Image> {
        self.walls.entry(n.to_string()).or_insert_with(|| g.texture_image(n)).as_ref()
    }
    fn load_sprite(&mut self, g: &GfxAssets, n: &str) -> Option<&(Image, i16, i16)> {
        self.sprites.entry(n.to_string()).or_insert_with(|| g.sprite_image(n)).as_ref()
    }
    fn load_flat(&mut self, g: &GfxAssets, n: &str) -> Option<&Image> {
        self.flats.entry(n.to_string()).or_insert_with(|| g.flat_image(n)).as_ref()
    }
}

#[derive(Clone, Debug)]
enum Tex {
    Wall(String),
    Flat(String),
    Sprite(String),
    Sky,
}

#[derive(Clone, Debug)]
struct Face {
    v: [[f32; 3]; 4],
    uv: [[f32; 2]; 4],
    tex: Tex,
    light: f32,
    /// what a click on this face selects (see [`Pick`])
    id: u32,
    masked: bool,
    /// sprites do not tile in either direction
    sprite: bool,
    /// texture height, for masked (non-tiling) faces
    th: f32,
}

fn name_of(n: &[u8; 8]) -> String {
    let end = n.iter().position(|&c| c == 0).unwrap_or(8);
    String::from_utf8_lossy(&n[..end]).trim().to_ascii_uppercase()
}

fn is_sky(n: &str) -> bool {
    n.starts_with("F_SKY")
}

fn shade(light: i16) -> f32 {
    0.3 + 0.7 * (light.clamp(0, 255) as f32 / 255.0)
}

const ID_WALL: u32 = 1 << 28;
const ID_FLOOR: u32 = 2 << 28;
const ID_CEIL: u32 = 3 << 28;
const ID_THING: u32 = 4 << 28;

/// What is visible at one pixel of a rendered view.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Pick {
    /// A wall surface: linedef and side (0 = first sidedef, 1 = second).
    Wall(usize, usize),
    /// The floor of this sector.
    Floor(usize),
    /// The ceiling of this sector.
    Ceiling(usize),
    /// A thing: index into the `things` slice given to the renderer.
    Thing(usize),
}

impl Pick {
    fn from_id(id: u32) -> Option<Pick> {
        let n = (id & 0x0FFF_FFFF) as usize;
        match id >> 28 {
            1 => Some(Pick::Wall(n >> 1, n & 1)),
            2 => Some(Pick::Floor(n)),
            3 => Some(Pick::Ceiling(n)),
            4 => Some(Pick::Thing(n)),
            _ => None,
        }
    }
}

/// The result of [`render_ids`]: the picture plus a per-pixel pick buffer.
pub struct View3d {
    pub image: Image,
    ids: Vec<u32>,
}

impl View3d {
    /// What is under pixel `(x, y)`, if anything solid is drawn there.
    pub fn pick(&self, x: usize, y: usize) -> Option<Pick> {
        if x >= self.image.width || y >= self.image.height {
            return None;
        }
        Pick::from_id(self.ids[y * self.image.width + x])
    }
}

const SKY: [u8; 3] = [120, 150, 210];

fn build_faces(map: &MapData, traps: &[Vec<Trap>], things: &[(i32, i32, String)], eye: (f32, f32, f32), g: &GfxAssets, cache: &mut TexCache) -> Vec<Face> {
    let mut faces = Vec::new();
    for i in 0..map.linedefs.len() {
        if !is_used(&map.linedef_flags, i) {
            continue;
        }
        let l = map.linedefs[i];
        let (Some(a), Some(b)) = (map.vertexes.get(l.from as usize), map.vertexes.get(l.to as usize)) else { continue };
        let (a, b) = ((a.x as f32, a.y as f32), (b.x as f32, b.y as f32));
        let len = ((b.0 - a.0).powi(2) + (b.1 - a.1).powi(2)).sqrt();
        if len == 0.0 {
            continue;
        }
        let upper_unpeg = l.solidity & line_bits::UPPER_UNPEGGED != 0;
        let lower_unpeg = l.solidity & line_bits::LOWER_UNPEGGED != 0;
        for side in 0..2 {
            let (sd_i, back_i, p, q) = if side == 0 { (l.sidedef1, l.sidedef2, a, b) } else { (l.sidedef2, l.sidedef1, b, a) };
            if sd_i == NOTHING {
                continue;
            }
            let Some(sd) = map.sidedefs.get(sd_i as usize) else { continue };
            let Some(f) = map.sectors.get(sd.sector as usize) else { continue };
            let back = if back_i == NOTHING { None } else { map.side_sector(back_i).and_then(|s| map.sectors.get(s)) };
            // front side is to the right of p -> q
            let (dx, dy) = (q.0 - p.0, q.1 - p.1);
            if (eye.0 - p.0) * dy - (eye.1 - p.1) * dx <= 0.0 {
                continue;
            }
            let light = shade(f.light) * if dx == 0.0 { 0.9 } else if dy == 0.0 { 0.95 } else { 1.0 };
            let (u0, u1) = (sd.x as f32, sd.x as f32 + len);
            let yoff = sd.y as f32;
            let quad = |name: &[u8; 8], zlo: f32, zhi: f32, top_ref: f32, masked: bool, faces: &mut Vec<Face>, cache: &mut TexCache| {
                let n = name_of(name);
                if n.is_empty() || n == "-" || zhi <= zlo {
                    return;
                }
                let th = cache.load_wall(g, &n).map_or(128.0, |im| im.height as f32);
                let top_ref = if top_ref.is_nan() { th + zlo } else { top_ref };
                let vv = |z: f32| top_ref - z + yoff;
                faces.push(Face {
                    v: [[p.0, p.1, zlo], [p.0, p.1, zhi], [q.0, q.1, zhi], [q.0, q.1, zlo]],
                    uv: [[u0, vv(zlo)], [u0, vv(zhi)], [u1, vv(zhi)], [u1, vv(zlo)]],
                    tex: Tex::Wall(n),
                    light,
                    id: ID_WALL | (i as u32) << 1 | side as u32,
                    masked,
                    sprite: false,
                    th,
                });
            };
            let (fl, fc) = (f.floor_z as f32, f.ceil_z as f32);
            let height = |n: &[u8; 8], cache: &mut TexCache| -> f32 {
                let n = name_of(n);
                cache.load_wall(g, &n).map_or(128.0, |im| im.height as f32)
            };
            match back {
                None => {
                    let h = height(&sd.t3, cache);
                    let top = if lower_unpeg { fl + h } else { fc };
                    quad(&sd.t3, fl, fc, top, false, &mut faces, cache);
                }
                Some(bk) => {
                    let (bl, bc) = (bk.floor_z as f32, bk.ceil_z as f32);
                    if fc > bc && !(is_sky(&name_of(&f.ceil)) && is_sky(&name_of(&bk.ceil))) {
                        let h = height(&sd.t1, cache);
                        let top = if upper_unpeg { fc } else { bc + h };
                        quad(&sd.t1, bc, fc, top, false, &mut faces, cache);
                    }
                    if fl < bl {
                        let top = if lower_unpeg { fc } else { bl };
                        quad(&sd.t2, fl, bl, top, false, &mut faces, cache);
                    }
                    let (lo, hi) = (fl.max(bl), fc.min(bc));
                    if hi > lo {
                        let h = height(&sd.t3, cache);
                        let top = if lower_unpeg { lo + h } else { hi };
                        let (zlo, zhi) = ((top - h).max(lo), top.min(hi));
                        quad(&sd.t3, zlo, zhi, top, true, &mut faces, cache);
                    }
                }
            }
        }
    }
    for (si, s) in map.sectors.iter().enumerate() {
        let Some(ts) = traps.get(si) else { continue };
        let light = shade(s.light);
        for (z, nm, visible, kind) in [
            (s.floor_z as f32, name_of(&s.floor), eye.2 > s.floor_z as f32, ID_FLOOR),
            (s.ceil_z as f32, name_of(&s.ceil), eye.2 < s.ceil_z as f32, ID_CEIL),
        ] {
            if !visible {
                continue;
            }
            let tex = if is_sky(&nm) { Tex::Sky } else { Tex::Flat(nm.clone()) };
            if let Tex::Flat(n) = &tex {
                cache.load_flat(g, n);
            }
            for t in ts {
                let pts = [(t.x0, t.y0[0]), (t.x0, t.y0[1]), (t.x1, t.y1[1]), (t.x1, t.y1[0])];
                faces.push(Face {
                    v: pts.map(|(x, y)| [x, y, z]),
                    uv: pts.map(|(x, y)| [x, -y]),
                    tex: tex.clone(),
                    light,
                    id: kind | si as u32,
                    masked: false,
                    sprite: false,
                    th: 64.0,
                });
            }
        }
    }
    // things: upright billboards facing the viewer, standing on their sector's floor
    for (ti, (tx, ty, name)) in things.iter().enumerate() {
        let (tx, ty) = (*tx as f32, *ty as f32);
        let Some(floor) = floor_at(map, traps, tx, ty) else { continue };
        let Some((im, left, top)) = cache.load_sprite(g, name).map(|(i, l, t)| ((i.width as f32, i.height as f32), *l as f32, *t as f32)) else { continue };
        let (w, h) = im;
        let (fx, fy) = (tx - eye.0, ty - eye.1);
        let d = (fx * fx + fy * fy).sqrt();
        if d < 1.0 {
            continue;
        }
        let (rx, ry) = (fy / d, -fx / d);
        let (l, r) = (-left, w - left);
        let (zhi, zlo) = (floor + top, floor + top - h);
        faces.push(Face {
            v: [[tx + rx * l, ty + ry * l, zlo], [tx + rx * l, ty + ry * l, zhi], [tx + rx * r, ty + ry * r, zhi], [tx + rx * r, ty + ry * r, zlo]],
            uv: [[0.0, h], [0.0, 0.0], [w, 0.0], [w, h]],
            tex: Tex::Sprite(name.clone()),
            light: 1.0,
            id: ID_THING | ti as u32,
            masked: true,
            sprite: true,
            th: h,
        });
    }
    faces
}

/// Floor height of the sector containing a map point.
fn floor_at(map: &MapData, traps: &[Vec<Trap>], x: f32, y: f32) -> Option<f32> {
    for (si, ts) in traps.iter().enumerate() {
        for t in ts {
            if x < t.x0 || x > t.x1 {
                continue;
            }
            let f = (x - t.x0) / (t.x1 - t.x0).max(1e-6);
            let lo = t.y0[0] + (t.y1[0] - t.y0[0]) * f;
            let hi = t.y0[1] + (t.y1[1] - t.y0[1]) * f;
            if y >= lo && y <= hi {
                return map.sectors.get(si).map(|s| s.floor_z as f32);
            }
        }
    }
    None
}

type V3 = [f64; 3];

fn sub(a: V3, b: V3) -> V3 {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}
fn dot(a: V3, b: V3) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}
fn cross(a: V3, b: V3) -> V3 {
    [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
}

fn clip_near(poly: &[V3], near: f64) -> Vec<V3> {
    let mut out = Vec::with_capacity(poly.len() + 1);
    for i in 0..poly.len() {
        let (a, b) = (poly[i], poly[(i + 1) % poly.len()]);
        let (ia, ib) = (a[2] >= near, b[2] >= near);
        if ia {
            out.push(a);
        }
        if ia != ib {
            let t = (near - a[2]) / (b[2] - a[2]);
            out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, near]);
        }
    }
    out
}

/// Render the map as seen by `cam` into a `w` x `h` image. `traps` is
/// `MapData::sector_traps` for each sector (so the caller can cache it).
/// `things` are `(x, y, sprite lump)` billboards.
///
/// Depth and texture coordinates come from each face's plane equation in eye
/// space rather than from interpolating clipped screen vertices, which stays
/// accurate for huge polygons that pass through the eye plane.
pub fn render(map: &MapData, traps: &[Vec<Trap>], things: &[(i32, i32, String)], g: &GfxAssets, cache: &mut TexCache, cam: &Camera, w: usize, h: usize, bg: [u8; 3]) -> Image {
    render_ids(map, traps, things, g, cache, cam, w, h, bg).image
}

/// Like [`render`], but also records what is visible at every pixel so a
/// click can select it.
pub fn render_ids(map: &MapData, traps: &[Vec<Trap>], things: &[(i32, i32, String)], g: &GfxAssets, cache: &mut TexCache, cam: &Camera, w: usize, h: usize, bg: [u8; 3]) -> View3d {
    let mut img = Image::blank(w, h);
    for px in img.rgba.chunks_exact_mut(4) {
        px.copy_from_slice(&[bg[0], bg[1], bg[2], 255]);
    }
    let mut ids = vec![0u32; w * h];
    if w < 2 || h < 2 {
        return View3d { image: img, ids };
    }
    let eye = (cam.vx as f32, cam.vy as f32, -cam.vz as f32);
    let faces = build_faces(map, traps, things, eye, g, cache);
    let m = cam.matrix();
    let (cx, cy) = (w as f64 / 2.0, h as f64 / 2.0);
    let aspect = h as f64 / w as f64;
    let mut zbuf = vec![0.0f64; w * h]; // 1/z, larger = nearer

    for f in &faces {
        let e: Vec<V3> = (0..4)
            .map(|k| {
                let (x, y, z) = (f.v[k][0], f.v[k][1], -f.v[k][2]);
                [
                    (m[0][0] * x + m[1][0] * y + m[2][0] * z + m[3][0]) as f64,
                    (m[0][1] * x + m[1][1] * y + m[2][1] * z + m[3][1]) as f64,
                    (m[0][2] * x + m[1][2] * y + m[2][2] * z + m[3][2]) as f64,
                ]
            })
            .collect();
        // best-conditioned vertex triple for the plane and uv gradients
        let mut best = (0.0f64, [0usize, 1, 2]);
        for t in [[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]] {
            let n = cross(sub(e[t[1]], e[t[0]]), sub(e[t[2]], e[t[0]]));
            let m2 = dot(n, n);
            if m2 > best.0 {
                best = (m2, t);
            }
        }
        if best.0 < 1e-9 {
            continue;
        }
        let [i0, i1, i2] = best.1;
        let (a, b) = (sub(e[i1], e[i0]), sub(e[i2], e[i0]));
        let n = cross(a, b);
        let n2 = dot(n, n);
        let d = dot(n, e[i0]);
        if d.abs() < 1e-9 {
            continue; // plane passes through the eye: edge-on
        }
        let grad = |k: usize| -> (f64, V3) {
            let (d1, d2) = ((f.uv[i1][k] - f.uv[i0][k]) as f64, (f.uv[i2][k] - f.uv[i0][k]) as f64);
            let (bn, na) = (cross(b, n), cross(n, a));
            (f.uv[i0][k] as f64, [0, 1, 2].map(|c| (d1 * bn[c] + d2 * na[c]) / n2))
        };
        let (u0, gu) = grad(0);
        let (v0, gv) = grad(1);

        let poly = clip_near(&e, 0.5);
        if poly.len() < 3 {
            continue;
        }
        let sv: Vec<[f64; 2]> = poly.iter().map(|c| [aspect * cx * c[0] / c[2] + cx, cy * c[1] / c[2] + cy]).collect();
        let tex: Option<&Image> = match &f.tex {
            Tex::Wall(n) => cache.walls.get(n).and_then(|o| o.as_ref()),
            Tex::Flat(n) => cache.flats.get(n).and_then(|o| o.as_ref()),
            Tex::Sprite(n) => cache.sprites.get(n).and_then(|o| o.as_ref()).map(|t| &t.0),
            Tex::Sky => None,
        };
        let (fb, shade) = match (&f.tex, tex) {
            (Tex::Sky, _) => (SKY, 1.0),
            (_, None) => ([150, 90, 150], f.light),
            _ => ([0, 0, 0], f.light),
        };
        for tri in 1..sv.len() - 1 {
            let (pa, pb, pc) = (sv[0], sv[tri], sv[tri + 1]);
            let area = (pb[0] - pa[0]) * (pc[1] - pa[1]) - (pb[1] - pa[1]) * (pc[0] - pa[0]);
            if area.abs() < 1e-9 {
                continue;
            }
            let minx = pa[0].min(pb[0]).min(pc[0]).floor().max(0.0);
            let maxx = pa[0].max(pb[0]).max(pc[0]).ceil().min(w as f64 - 1.0);
            let miny = pa[1].min(pb[1]).min(pc[1]).floor().max(0.0);
            let maxy = pa[1].max(pb[1]).max(pc[1]).ceil().min(h as f64 - 1.0);
            if minx > maxx || miny > maxy {
                continue;
            }
            let inv = 1.0 / area;
            for y in miny as usize..=maxy as usize {
                let py = y as f64 + 0.5;
                let ry = (py - cy) / cy;
                for x in minx as usize..=maxx as usize {
                    let px = x as f64 + 0.5;
                    let w0 = ((pb[0] - px) * (pc[1] - py) - (pb[1] - py) * (pc[0] - px)) * inv;
                    let w1 = ((pc[0] - px) * (pa[1] - py) - (pc[1] - py) * (pa[0] - px)) * inv;
                    let w2 = 1.0 - w0 - w1;
                    if w0 < -1e-9 || w1 < -1e-9 || w2 < -1e-9 {
                        continue;
                    }
                    let ray = [(px - cx) / (aspect * cx), ry, 1.0];
                    let iz = dot(n, ray) / d;
                    let zi = y * w + x;
                    if iz <= 0.0 || iz <= zbuf[zi] {
                        continue;
                    }
                    let col = match tex {
                        Some(t) => {
                            let z = 1.0 / iz;
                            let p = sub([ray[0] * z, ray[1] * z, z], e[i0]);
                            let u = u0 + dot(gu, p);
                            let v = v0 + dot(gv, p);
                            if f.masked && (v < 0.0 || v >= f.th as f64) {
                                continue;
                            }
                            if f.sprite && (u < 0.0 || u >= t.width as f64) {
                                continue;
                            }
                            let tx = (u.floor() as i64).rem_euclid(t.width as i64) as usize;
                            let ty = (v.floor() as i64).rem_euclid(t.height as i64) as usize;
                            let o = (ty * t.width + tx) * 4;
                            if f.masked && t.rgba[o + 3] < 128 {
                                continue;
                            }
                            [t.rgba[o], t.rgba[o + 1], t.rgba[o + 2]]
                        }
                        None => fb,
                    };
                    zbuf[zi] = iz;
                    ids[zi] = f.id;
                    let o = zi * 4;
                    img.rgba[o] = (col[0] as f32 * shade) as u8;
                    img.rgba[o + 1] = (col[1] as f32 * shade) as u8;
                    img.rgba[o + 2] = (col[2] as f32 * shade) as u8;
                }
            }
        }
    }
    View3d { image: img, ids }
}
