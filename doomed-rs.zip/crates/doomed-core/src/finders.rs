//! Hit-testing (`FINDERS.CPP`): what is under the mouse?

use crate::map::{is_used, MapData};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Point {
    pub x: i32,
    pub y: i32,
}

impl Point {
    pub fn new(x: i32, y: i32) -> Self {
        Point { x, y }
    }
}

/// How close (in map units) the mouse must be to a vertex or thing.
pub const PICK_RADIUS: i32 = 64;

/// "Quick sqrt from Graphics Gems I": `|dx| + |dy| - min(|dx|, |dy|) / 2`.
pub fn hypotenuse(p1: Point, p2: Point) -> i32 {
    let (dx, dy) = ((p2.x - p1.x).abs(), (p2.y - p1.y).abs());
    dx + dy - (dx.min(dy) >> 1)
}

impl MapData {
    /// `LineDefNear`: does linedef `ldn` touch the square of half-width
    /// `amount` around `mouse`?
    pub fn linedef_near(&self, ldn: usize, mouse: Point, amount: i32) -> bool {
        if !is_used(&self.linedef_flags, ldn) {
            return false;
        }
        let Some(l) = self.linedefs.get(ldn) else { return false };
        let (Some(a), Some(b)) = (self.vertexes.get(l.from as usize), self.vertexes.get(l.to as usize)) else {
            return false;
        };
        let (x0, y0, x1, y1) = (mouse.x - amount, mouse.y - amount, mouse.x + amount, mouse.y + amount);
        let (lx0, ly0, lx1, ly1) = (a.x as i64, a.y as i64, b.x as i64, b.y as i64);
        let (ix0, iy0, ix1, iy1) = (x0 as i64, y0 as i64, x1 as i64, y1 as i64);
        // crosses the bottom / top / left / right side of the square?
        if (ly0 > iy0) != (ly1 > iy0) {
            let i = lx0 + (iy0 - ly0) * (lx1 - lx0) / (ly1 - ly0);
            if i >= ix0 && i <= ix1 {
                return true;
            }
        }
        if (ly0 > iy1) != (ly1 > iy1) {
            let i = lx0 + (iy1 - ly0) * (lx1 - lx0) / (ly1 - ly0);
            if i >= ix0 && i <= ix1 {
                return true;
            }
        }
        if (lx0 > ix0) != (lx1 > ix0) {
            let i = ly0 + (ix0 - lx0) * (ly1 - ly0) / (lx1 - lx0);
            if i >= iy0 && i <= iy1 {
                return true;
            }
        }
        if (lx0 > ix1) != (lx1 > ix1) {
            let i = ly0 + (ix1 - lx0) * (ly1 - ly0) / (lx1 - lx0);
            if i >= iy0 && i <= iy1 {
                return true;
            }
        }
        // an endpoint inside the square
        let inside = |x: i64, y: i64| x >= ix0 && x <= ix1 && y >= iy0 && y <= iy1;
        inside(lx0, ly0) || inside(lx1, ly1)
    }

    /// `NearestVertex`: closest in-use vertex within [`PICK_RADIUS`].
    pub fn nearest_vertex(&self, mouse: Point) -> Option<usize> {
        let mut best: Option<(usize, i32)> = None;
        for (i, v) in self.vertexes.iter().enumerate() {
            if !is_used(&self.vertex_flags, i) {
                continue;
            }
            let d = hypotenuse(mouse, Point::new(v.x as i32, v.y as i32));
            if d < best.map_or(i16::MAX as i32, |b| b.1) {
                best = Some((i, d));
            }
        }
        best.filter(|&(_, d)| d <= PICK_RADIUS).map(|(i, _)| i)
    }

    /// `NearestThing`: closest in-use thing within [`PICK_RADIUS`].
    pub fn nearest_thing(&self, mouse: Point) -> Option<usize> {
        let mut best: Option<(usize, i32)> = None;
        for (i, t) in self.things.iter().enumerate() {
            if !is_used(&self.thing_flags, i) {
                continue;
            }
            let d = hypotenuse(mouse, Point::new(t.x as i32, t.y as i32));
            if d < best.map_or(i16::MAX as i32, |b| b.1) {
                best = Some((i, d));
            }
        }
        best.filter(|&(_, d)| d <= PICK_RADIUS).map(|(i, _)| i)
    }

    /// `NearestLineDef`: starts with a 64-unit box around the mouse; if more
    /// than one linedef is touched the box is halved and the search repeated.
    /// Gives up (returns `None`) when the box shrinks to 1.
    pub fn nearest_linedef(&self, mouse: Point) -> Option<usize> {
        let mut amount = PICK_RADIUS;
        loop {
            let mut found = 0;
            let mut ret = None;
            for i in 0..self.linedefs.len() {
                if self.linedef_near(i, mouse, amount) {
                    found += 1;
                    ret = Some(i);
                }
            }
            if found > 1 {
                amount /= 2;
                if amount == 1 {
                    return None;
                }
                continue;
            }
            return ret;
        }
    }

    fn sector_at(&self, mouse: Point, skip_moving: bool) -> Option<usize> {
        // Cast a ray toward +X; the nearest linedef crossing mouse.y decides.
        let mut curx: i64 = i16::MAX as i64;
        let mut cur: Option<usize> = None;
        for (n, l) in self.linedefs.iter().enumerate() {
            if !is_used(&self.linedef_flags, n) || (skip_moving && self.linedef_flags.get(n).map_or(false, |f| f.moving)) {
                continue;
            }
            let (Some(a), Some(b)) = (self.vertexes.get(l.from as usize), self.vertexes.get(l.to as usize)) else {
                continue;
            };
            let my = mouse.y as i64;
            if (a.y as i64 > my) != (b.y as i64 > my) {
                let (lx0, ly0, lx1, ly1) = (a.x as i64, a.y as i64, b.x as i64, b.y as i64);
                let m = lx0 + (my - ly0) * (lx1 - lx0) / (ly1 - ly0);
                if m >= mouse.x as i64 && m < curx {
                    curx = m;
                    cur = Some(n);
                }
            }
        }
        // A downward line has the sector we are in on its right (sidedef 1).
        let l = self.linedefs[cur?];
        let down = self.vertexes.get(l.from as usize)?.y > self.vertexes.get(l.to as usize)?.y;
        let side = if down { l.sidedef1 } else { l.sidedef2 };
        if side >= 0 {
            self.side_sector(side)
        } else {
            None
        }
    }

    /// `NearestSector`: the sector containing `mouse`, if any.
    pub fn nearest_sector(&self, mouse: Point) -> Option<usize> {
        self.sector_at(mouse, false)
    }

    /// `NearestSectorNotMove`: like `nearest_sector` but ignoring linedefs
    /// flagged as moving (used when dropping a dragged sector).
    pub fn nearest_sector_not_moving(&self, mouse: Point) -> Option<usize> {
        self.sector_at(mouse, true)
    }
}
