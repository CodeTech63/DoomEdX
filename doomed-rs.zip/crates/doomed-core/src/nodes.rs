//! Internal BSP node builder (`NODES.CPP`), loosely based by the original
//! author on Robert Fenske Jr.'s Verda node builder.
//!
//! Faithfully keeps the original's structure and quirks: segs are made one per
//! linedef side; the partition line is chosen among the node's own segs by a
//! balance score; segs crossing the line are split at a (rounded) new vertex;
//! a node is a subsector when every seg lies on the right of every other.
//! Nodes are emitted post-order, left subtree first, root last.

use crate::map::MapData;
use crate::quirks::Quirks;
use crate::structs::*;

const RAD_TO_BAMS: f64 = 10430.37835047045272494957;
/// `BAMS180` as stored in a 16-bit `bams`.
pub const BAMS180: i16 = i16::MIN;
/// `MAXINT` / `MININT` as defined in DOOMED40.HPP (note MININT is -32767).
const MAXINT: i16 = 32767;
const MININT: i16 = -32767;

/// Hooks for the original's live drawing and progress while building
/// (it painted straight onto the map window).
pub trait BuildObserver {
    /// A seg was split: the part from the far endpoint to the new vertex
    /// (drawn in the "marked" pen).
    fn split(&mut self, _from: (i16, i16), _to: (i16, i16)) {}
    /// A node ended up with an empty side ("Potential Problem!"): the
    /// partition line (drawn in the "selected" pen).
    fn problem(&mut self, _from: (i16, i16), _to: (i16, i16)) {}
    /// A subsector was found (`ReportProgress`).
    fn progress(&mut self) {}
}

/// Observer that ignores everything.
pub struct NoObserver;
impl BuildObserver for NoObserver {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BuildError {
    /// There are no linedefs to build from (the original would crash).
    NoLinedefs,
    /// More linedefs than a 16-bit index can address.
    TooManyLinedefs,
    /// A linedef refers to a vertex that does not exist.
    BadVertexRef { linedef: usize },
    /// Splitting needs more vertices than a 16-bit index can address.
    TooManyVertexes,
}

impl std::fmt::Display for BuildError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            BuildError::NoLinedefs => write!(f, "map has no linedefs"),
            BuildError::TooManyLinedefs => write!(f, "too many linedefs for 16-bit indexes"),
            BuildError::BadVertexRef { linedef } => write!(f, "linedef {linedef} refers to a missing vertex"),
            BuildError::TooManyVertexes => write!(f, "too many vertexes for 16-bit indexes"),
        }
    }
}
impl std::error::Error for BuildError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct NodeStats {
    pub nodes: usize,
    pub ssectors: usize,
    pub segs: usize,
    /// How many segs were created by splitting.
    pub splits: usize,
}

#[derive(Debug, Clone, Copy)]
struct Bounds {
    xmin: i16,
    xmax: i16,
    ymin: i16,
    ymax: i16,
}

struct Child {
    bounds: Bounds,
    tree: Box<Tree>,
}

enum Tree {
    Leaf(Vec<Seg>),
    Branch { pseg: Seg, left: Child, right: Child },
}

/// `BspInitialize` angle: east = 0, north = 16384, west = -32768.
fn seg_angle(vf: Vertex, vt: Vertex) -> i16 {
    if vt.y == vf.y && vt.x < vf.x {
        return BAMS180;
    }
    let dy = vt.y as i32 - vf.y as i32;
    let dx = vt.x as i32 - vf.x as i32;
    let sgn = (0 < dy) as i32 - (dy < 0) as i32;
    let a = (dy as f64).atan2(dx as f64) * RAD_TO_BAMS + 0.5 * sgn as f64;
    a as i32 as i16 // (bams) conversion: truncate, keep low 16 bits
}

/// `BspInitialize`: one seg per linedef, plus a left-side seg when two-sided.
fn initial_segs(linedefs: &[LineDef], verts: &[Vertex]) -> Vec<Seg> {
    let mut segs = Vec::with_capacity(linedefs.len() * 2);
    for (i, l) in linedefs.iter().enumerate() {
        let (vf, vt) = (verts[l.from as usize], verts[l.to as usize]);
        let angle = seg_angle(vf, vt);
        segs.push(Seg { from: l.from, to: l.to, angle, linedef: i as i16, normal: 0, distance: 0 });
        if l.two_sided() {
            segs.push(Seg {
                from: l.to,
                to: l.from,
                angle: angle.wrapping_add(BAMS180),
                linedef: i as i16,
                normal: 1,
                distance: 0,
            });
        }
    }
    segs
}

/// Partition quality score. With `partition_16bit_math` this is evaluated in
/// 16-bit `int` exactly as the original's expression
/// `100 * rcnt * lcnt / (16 * splits / 3 + 1)`.
pub fn partition_score(rcnt: usize, lcnt: usize, splits: usize, q: &Quirks) -> i64 {
    if q.partition_16bit_math {
        let num = 100i16.wrapping_mul(rcnt as i16).wrapping_mul(lcnt as i16);
        let den = (16i16.wrapping_mul(splits as i16) / 3).wrapping_add(1);
        if den == 0 {
            num as i64 // the original would divide by zero here
        } else {
            num.wrapping_div(den) as i64
        }
    } else {
        100 * rcnt as i64 * lcnt as i64 / (16 * splits as i64 / 3 + 1)
    }
}

struct Builder<'a> {
    map: &'a mut MapData,
    q: Quirks,
    obs: &'a mut dyn BuildObserver,
    split_count: usize,
}

impl Builder<'_> {
    fn v(&self, i: i16) -> Vertex {
        self.map.vertexes[i as usize]
    }

    /// `BspSelectSide`: 0 = right of the partition line, 1 = left,
    /// -1 = crosses it (needs splitting).
    fn select_side(&self, p: &Seg, s: &Seg) -> i32 {
        const RIGHT_LEFT: [[i32; 3]; 3] = [[1, 1, -1], [1, -2, 0], [-1, 0, 0]];
        let (pf, pt) = (self.v(p.from), self.v(p.to));
        let (vf, vt) = (self.v(s.from), self.v(s.to));
        // partition line is A x + B y + C = 0
        let a = -(pt.y as i64 - pf.y as i64);
        let b = pt.x as i64 - pf.x as i64;
        let c = pt.y as i64 * pf.x as i64 - pt.x as i64 * pf.y as i64;
        let pd = ((a * a + b * b) as f64).sqrt() as i64;
        let pfd = a * vf.x as i64 + b * vf.y as i64 + c;
        let ptd = a * vt.x as i64 + b * vt.y as i64 + c;
        let fside = (pfd >= pd) as i32 - (pfd <= -pd) as i32;
        let tside = (ptd >= pd) as i32 - (ptd <= -pd) as i32;
        let mut side = RIGHT_LEFT[(1 - fside) as usize][(1 - tside) as usize];
        if side == -2 {
            // collinear: decide by direction
            side = (p.angle != s.angle) as i32;
        }
        side
    }

    /// `BspSplitSeg`: returns the (right, left) pieces of `seg` cut by `p`.
    fn split_seg(&mut self, p: &Seg, seg: &Seg) -> Result<(Seg, Seg), BuildError> {
        // new vertex FIRST, as in the original (it may reuse an unused slot)
        let v = self.map.vertex_new().ok_or(BuildError::TooManyVertexes)? as i16;
        let (pf, pt) = (self.v(p.from), self.v(p.to));
        let (vf, vt) = (self.v(seg.from), self.v(seg.to));

        let ap = -(pt.y as i64 - pf.y as i64);
        let bp = pt.x as i64 - pf.x as i64;
        let cp = pt.y as i64 * pf.x as i64 - pt.x as i64 * pf.y as i64;
        let as_ = -(vt.y as i64 - vf.y as i64);
        let bs = vt.x as i64 - vf.x as i64;
        let cs = vt.y as i64 * vf.x as i64 - vt.x as i64 * vf.y as i64;

        let denom = bp as f64 * as_ as f64 - bs as f64 * ap as f64;
        let x = (bs as f64 * cp as f64 - bp as f64 * cs as f64) / denom;
        let y = -(as_ as f64 * cp as f64 - ap as f64 * cs as f64) / denom;
        let sgn = |a: f64| ((0.0 < a) as i32 - (a < 0.0) as i32) as f64;
        let iv = Vertex { x: (x + sgn(x) * 0.5) as i32 as i16, y: (y + sgn(y) * 0.5) as i32 as i16 };
        self.map.vertexes[v as usize] = iv;

        let side_of = |q: Vertex| ap * q.x as i64 + bp * q.y as i64 + cp;
        let dist = |a: Vertex| -> i16 {
            let dx = a.x as i64 - iv.x as i64;
            let dy = a.y as i64 - iv.y as i64;
            ((dx * dx + dy * dy) as f64).sqrt() as i64 as i16
        };
        let from_end = |far: Vertex| if self.q.split_offset_from_wrong_end { far } else { vf };

        let (mut right, mut left) = (*seg, *seg);
        if seg.normal == 0 {
            // right-side seg
            if side_of(vf) < 0 {
                right.to = v;
                left.from = v;
                left.distance = seg.distance.wrapping_add(dist(vf));
                self.obs.split((vf.x, vf.y), (iv.x, iv.y));
            } else {
                right.from = v;
                right.distance = seg.distance.wrapping_add(dist(from_end(vt)));
                left.to = v;
                self.obs.split((vt.x, vt.y), (iv.x, iv.y));
            }
        } else {
            // left-side seg
            if side_of(vt) < 0 {
                right.from = v;
                right.distance = seg.distance.wrapping_add(dist(from_end(vt)));
                left.to = v;
                self.obs.split((vt.x, vt.y), (iv.x, iv.y));
            } else {
                right.to = v;
                left.from = v;
                left.distance = seg.distance.wrapping_add(dist(vf));
                self.obs.split((vf.x, vf.y), (iv.x, iv.y));
            }
        }
        Ok((right, left))
    }

    /// `BspCalculateSegBounds`.
    fn bounds(&self, segs: &[Seg]) -> Bounds {
        let mut b = Bounds { xmin: MAXINT, ymin: MAXINT, xmax: MININT, ymax: MININT };
        for s in segs {
            for vi in [s.from, s.to] {
                let v = self.v(vi);
                b.xmin = b.xmin.min(v.x);
                b.ymin = b.ymin.min(v.y);
                b.xmax = b.xmax.max(v.x);
                b.ymax = b.ymax.max(v.y);
            }
        }
        b
    }

    /// `BspFindPartitionSeg`: index of the best partition seg.
    fn find_partition(&self, segs: &[Seg]) -> usize {
        let n = segs.len();
        let (mut agm, mut igm) = (-1i64, -1i64);
        // the original leaves these uninitialised; 0 is the sane choice
        let (mut apndx, mut ipndx) = (0usize, 0usize);
        for (s, p) in segs.iter().enumerate() {
            let (mut rcnt, mut lcnt, mut splits) = (0, 0, 0);
            for iseg in segs {
                match self.select_side(p, iseg) {
                    0 => rcnt += 1,
                    1 => lcnt += 1,
                    _ => splits += 1,
                }
            }
            let gm = partition_score(rcnt, lcnt, splits, &self.q);
            if agm < gm {
                agm = gm;
                apndx = s;
            }
            if rcnt != n && lcnt != n && igm < gm {
                igm = gm;
                ipndx = s;
            }
        }
        if igm >= 0 {
            ipndx
        } else {
            apndx
        }
    }

    /// `BspDivideNode`: partition `segs` by `p`. Right segs keep their order;
    /// left segs (including the left half of every split) follow in the order
    /// they were met.
    fn divide(&mut self, p: &Seg, segs: Vec<Seg>) -> Result<(Vec<Seg>, Vec<Seg>), BuildError> {
        let (mut right, mut left) = (Vec::new(), Vec::new());
        for s in segs {
            match self.select_side(p, &s) {
                0 => right.push(s),
                1 => left.push(s),
                _ => {
                    // The original also executes `if(end == SegInfo) node->segs =
                    // SegInfo->prev;` here, which would drop earlier right segs
                    // from the list. That corruption is not reproduced.
                    let (r, l) = self.split_seg(p, &s)?;
                    right.push(r);
                    left.push(l);
                    self.split_count += 1;
                }
            }
        }
        Ok((right, left))
    }

    /// `BspSSectorTest`: true when every seg has all others on its right
    /// (i.e. the group is convex and can be a subsector).
    fn is_subsector(&self, segs: &[Seg]) -> bool {
        for (s, a) in segs.iter().enumerate() {
            for (i, b) in segs.iter().enumerate() {
                if i != s && self.select_side(a, b) != 0 {
                    return false;
                }
            }
        }
        true
    }

    /// `BspPartitionNode`. Left is decided (and built) before right.
    fn partition_node(&mut self, segs: Vec<Seg>) -> Result<Tree, BuildError> {
        let pseg = segs[self.find_partition(&segs)];
        let (right, left) = self.divide(&pseg, segs)?;
        let (rb, lb) = (self.bounds(&right), self.bounds(&left));
        let line = ((self.v(pseg.from).x, self.v(pseg.from).y), (self.v(pseg.to).x, self.v(pseg.to).y));
        let (right_empty, left_empty) = (right.is_empty(), left.is_empty());

        // Note the original's quirk: whether the LEFT side is a leaf also
        // depends on the RIGHT side being empty (and vice versa).
        let left_tree = if right_empty || self.is_subsector(&left) {
            self.obs.progress();
            if right_empty {
                self.obs.problem(line.0, line.1);
            }
            Tree::Leaf(left)
        } else {
            self.partition_node(left)?
        };
        let right_tree = if left_empty || self.is_subsector(&right) {
            self.obs.progress();
            if left_empty {
                self.obs.problem(line.0, line.1);
            }
            Tree::Leaf(right)
        } else {
            self.partition_node(right)?
        };
        Ok(Tree::Branch {
            pseg,
            left: Child { bounds: lb, tree: Box::new(left_tree) },
            right: Child { bounds: rb, tree: Box::new(right_tree) },
        })
    }
}

fn encode_child(n: i32) -> i16 {
    if n < 0 {
        (0x8000u16 | (-n - 1) as u16) as i16 // marks a subsector
    } else {
        n as i16
    }
}

/// `BspPlaceNode`: flattens the tree. Returns the node number, or a negative
/// number `-(subsector + 1)` for a leaf.
fn place(tree: &Tree, verts: &[Vertex], nodes: &mut Vec<Node>, ss: &mut Vec<SSector>, segs: &mut Vec<Seg>) -> i32 {
    match tree {
        Tree::Leaf(list) => {
            let first = ss.last().map_or(0, |p| p.segs.wrapping_add(p.num));
            ss.push(SSector { num: list.len() as i16, segs: first });
            segs.extend_from_slice(list);
            -(ss.len() as i32)
        }
        Tree::Branch { pseg, left, right } => {
            let l = place(&left.tree, verts, nodes, ss, segs);
            let r = place(&right.tree, verts, nodes, ss, segs);
            let (pf, pt) = (verts[pseg.from as usize], verts[pseg.to as usize]);
            nodes.push(Node {
                x: pf.x,
                y: pf.y,
                dx: pt.x.wrapping_sub(pf.x),
                dy: pt.y.wrapping_sub(pf.y),
                maxy1: right.bounds.ymax,
                miny1: right.bounds.ymin,
                minx1: right.bounds.xmin,
                maxx1: right.bounds.xmax,
                maxy2: left.bounds.ymax,
                miny2: left.bounds.ymin,
                minx2: left.bounds.xmin,
                maxx2: left.bounds.xmax,
                ssector1: encode_child(r),
                ssector2: encode_child(l),
            });
            (nodes.len() - 1) as i32
        }
    }
}

impl MapData {
    /// `BspBuild` (internal builder): rebuilds `segs`, `ssectors` and `nodes`.
    ///
    /// Like the original it first recomputes which vertices are in use, and new
    /// split vertices reuse unused vertex slots before appending. The map
    /// should be packed first (see [`MapData::pack`]); all linedefs are used.
    pub fn build_nodes(&mut self, q: &Quirks, obs: &mut dyn BuildObserver) -> Result<NodeStats, BuildError> {
        self.normalize_flags();
        if self.linedefs.is_empty() {
            return Err(BuildError::NoLinedefs);
        }
        if self.linedefs.len() > i16::MAX as usize {
            return Err(BuildError::TooManyLinedefs);
        }
        for (i, l) in self.linedefs.iter().enumerate() {
            for v in [l.from, l.to] {
                if v < 0 || v as usize >= self.vertexes.len() {
                    return Err(BuildError::BadVertexRef { linedef: i });
                }
            }
        }
        self.find_vertexes_in_use(); // "clear unused vertexes"

        let segs = initial_segs(&self.linedefs, &self.vertexes);
        let mut b = Builder { map: self, q: *q, obs, split_count: 0 };
        let tree = b.partition_node(segs)?;
        let splits = b.split_count;

        let (mut nodes, mut ssectors, mut out_segs) = (Vec::new(), Vec::new(), Vec::new());
        place(&tree, &self.vertexes, &mut nodes, &mut ssectors, &mut out_segs);
        let stats = NodeStats { nodes: nodes.len(), ssectors: ssectors.len(), segs: out_segs.len(), splits };
        self.nodes = nodes;
        self.ssectors = ssectors;
        self.segs = out_segs;
        self.nodes_dirty = false;
        Ok(stats)
    }
}
