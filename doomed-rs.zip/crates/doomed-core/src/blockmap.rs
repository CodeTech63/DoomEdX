//! Internal blockmap builder (`BLOCKMAP.CPP`).
//!
//! Layout (16-bit words): `xorig, yorig, columns, rows`, one offset per block,
//! then per block `0, linedef..., -1`. Blocks are 128 units, origin 8 units
//! below/left of the lowest used vertex.

use crate::map::MapData;
use crate::quirks::Quirks;

const SIZE: i64 = 0x80; // block size in map units
const SCL: i64 = 1000; // fixed-point scale for diagonal following

fn sgn(a: i64) -> i64 {
    (0 < a) as i64 - (a < 0) as i64
}

impl MapData {
    /// `BuildBlockmap`: rebuilds `self.blockmap` from the in-use linedefs'
    /// vertices (every linedef is traced, as in the original).
    ///
    /// Not reproduced: the original's fixed per-block capacity of
    /// `min(linedefs, 50)` entries, which overflows its buffer in dense blocks.
    /// Division by zero for near-flat diagonals (which would crash the
    /// original) falls back to a slope of +/-1; runaway loops are capped.
    pub fn build_blockmap(&mut self, q: &Quirks) {
        let used = self.used_vertex_mask();
        let (mut xmin, mut ymin, mut xmax, mut ymax) = (32767i64, 32767i64, -32767i64, -32767i64);
        let mut any = false;
        for (v, _) in self.vertexes.iter().zip(&used).filter(|(_, &u)| u) {
            any = true;
            xmin = xmin.min(v.x as i64);
            xmax = xmax.max(v.x as i64);
            ymin = ymin.min(v.y as i64);
            ymax = ymax.max(v.y as i64);
        }
        if !any {
            self.blockmap.clear();
            return;
        }
        let (xorig, yorig) = (xmin - 8, ymin - 8);
        let (xn, yn) = if q.blockmap_quirks {
            ((xmax - xmin + SIZE) / SIZE, (ymax - ymin + SIZE) / SIZE)
        } else {
            ((xmax - xorig) / SIZE + 1, (ymax - yorig) / SIZE + 1)
        };
        let mut boxes: Vec<Vec<i16>> = vec![Vec::new(); (xn * yn) as usize];
        let mut add = |b: i64, l: usize| {
            if b >= 0 && (b as usize) < boxes.len() {
                boxes[b as usize].push(l as i16);
            }
        };

        for (l, ld) in self.linedefs.iter().enumerate() {
            let (Some(vf), Some(vt)) = (
                self.vertexes.get(ld.from as usize).copied(),
                self.vertexes.get(ld.to as usize).copied(),
            ) else {
                continue;
            };
            let (xf, yf) = (vf.x as i64 - xorig, vf.y as i64 - yorig);
            let (xt, yt) = (vt.x as i64 - xorig, vt.y as i64 - yorig);
            let (xd, yd) = (sgn(xt - xf), sgn(yt - yf));

            let (c, p) = match 2 * (xf / SIZE == xt / SIZE) as i32 + (yf / SIZE == yt / SIZE) as i32 {
                0 => (0, yd * xn),                                  // diagonal
                1 => ((xt / SIZE - xf / SIZE).abs() + 1, xd),       // horizontal
                2 => ((yt / SIZE - yf / SIZE).abs() + 1, yd * xn),  // vertical
                _ => (1, 1),                                        // within one block
            };
            let mut b = xf / SIZE + xn * (yf / SIZE);
            for _ in 0..c {
                add(b, l);
                b += p;
            }
            if c == 0 {
                // diagonal spanning more than one block
                let mut m = SCL * (yt - yf) / (xt - xf);
                if q.blockmap_quirks {
                    m = m as i16 as i64; // `int m` in the original
                }
                if m == 0 {
                    m = if xd * yd < 0 { -1 } else { 1 };
                }
                let wrap = |v: i64| if q.blockmap_quirks { v as i16 as i64 } else { v };
                let mut xcl = xf;
                let mut xcc = if yd == -1 {
                    wrap(xf + SCL * ((yf / SIZE) * SIZE - 1 - yf) / m)
                } else {
                    wrap(xf + SCL * ((yf / SIZE) * SIZE + 128 - yf) / m)
                };
                let mut guard = 0;
                loop {
                    for _ in 0..((xcc / SIZE - xcl / SIZE).abs() + 1) {
                        add(b, l);
                        b += xd;
                    }
                    b += p - xd;
                    xcl = xcc;
                    xcc = wrap(xcc + yd * SCL * SIZE / m);
                    if xd * xcc > xd * xt {
                        xcc = xt; // don't overrun endpoint
                    }
                    guard += 1;
                    if !(xd * xcl < xd * xt) || guard > 4 * (xn + yn) + 16 {
                        break;
                    }
                }
            }
        }

        let mut words: Vec<i16> = vec![xorig as i16, yorig as i16, xn as i16, yn as i16];
        let table = words.len();
        words.resize(table + boxes.len(), 0);
        for (i, list) in boxes.iter().enumerate() {
            words[table + i] = words.len() as i16; // offset of this block's list
            words.push(0); // always zero
            words.extend_from_slice(list);
            words.push(-1); // end of block
        }
        self.blockmap = words.iter().flat_map(|w| w.to_le_bytes()).collect();
    }
}
