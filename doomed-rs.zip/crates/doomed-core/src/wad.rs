//! WAD container: header, lump directory, and DoomEd's lump classification
//! (`LoadWad` in `LOAD.CPP`).

use std::{fmt, fs, io, path::Path};

/// Lump classes. Discriminants match the original `WD_*` constants.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
#[repr(u8)]
pub enum WadType {
    #[default]
    Unclassified = 0,
    Id = 1,
    Things = 2,
    LineDefs = 3,
    SideDefs = 4,
    Vertexes = 5,
    Segs = 6,
    SSectors = 7,
    Nodes = 8,
    Sectors = 9,
    Reject = 10,
    BlockMap = 11,
    Sprite = 12,
    Panel = 13,
    Tile = 14,
    Music = 15,
    Sound = 16,
    Beep = 17,
    Texture = 18,
    PlayPal = 19,
    ColorMap = 20,
    EnDoom = 21,
    Demo = 22,
    PNames = 23,
    Driver = 24,
    Status = 25,
    Level = 26,
    Menu = 27,
    Graphic = 28,
    Map = 29,
    Tag = 30,
}

impl WadType {
    /// Lumps that belong to a map group (the set `DoomEdFileSave` deletes
    /// when replacing a map).
    pub fn is_map_lump(self) -> bool {
        use WadType::*;
        matches!(
            self,
            Things | LineDefs | SideDefs | Vertexes | Segs | SSectors | Nodes | Sectors | Reject | BlockMap | Id | Tag
        )
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WadKind {
    Iwad,
    Pwad,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WadEntry {
    /// Lump name (at most 8 characters).
    pub title: String,
    pub data: Vec<u8>,
    pub ty: WadType,
}

impl WadEntry {
    pub fn new(title: &str, data: Vec<u8>) -> Self {
        WadEntry { title: title.chars().take(8).collect(), data, ty: WadType::Unclassified }
    }
}

#[derive(Debug)]
pub enum WadError {
    Io(io::Error),
    /// Not an `IWAD`/`PWAD`, or too short to hold a header.
    BadHeader,
    /// Directory or a lump extends past the end of the file.
    Truncated,
}

impl fmt::Display for WadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            WadError::Io(e) => write!(f, "I/O error: {e}"),
            WadError::BadHeader => write!(f, "not a WAD file (expected IWAD or PWAD)"),
            WadError::Truncated => write!(f, "WAD directory or lump data runs past end of file"),
        }
    }
}
impl std::error::Error for WadError {}
impl From<io::Error> for WadError {
    fn from(e: io::Error) -> Self {
        WadError::Io(e)
    }
}

#[derive(Debug, Clone)]
pub struct Wad {
    pub kind: WadKind,
    pub entries: Vec<WadEntry>,
}

fn rd_i32(b: &[u8], o: usize) -> i32 {
    i32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]])
}

impl Wad {
    /// An empty patch WAD (what "Save As" starts from).
    pub fn new_pwad() -> Self {
        Wad { kind: WadKind::Pwad, entries: Vec::new() }
    }

    pub fn open(path: impl AsRef<Path>) -> Result<Self, WadError> {
        Self::from_bytes(&fs::read(path)?)
    }

    pub fn save(&self, path: impl AsRef<Path>) -> Result<(), WadError> {
        fs::write(path, self.to_bytes())?;
        Ok(())
    }

    pub fn from_bytes(bytes: &[u8]) -> Result<Self, WadError> {
        if bytes.len() < 12 {
            return Err(WadError::BadHeader);
        }
        let kind = match &bytes[0..4] {
            b"IWAD" => WadKind::Iwad,
            b"PWAD" => WadKind::Pwad,
            _ => return Err(WadError::BadHeader),
        };
        let count = rd_i32(bytes, 4);
        let dir_off = rd_i32(bytes, 8);
        if count < 0 || dir_off < 0 {
            return Err(WadError::Truncated);
        }
        let (count, dir_off) = (count as usize, dir_off as usize);
        let dir_end = count.checked_mul(16).and_then(|n| n.checked_add(dir_off)).ok_or(WadError::Truncated)?;
        if dir_end > bytes.len() {
            return Err(WadError::Truncated);
        }
        let mut entries = Vec::with_capacity(count);
        for i in 0..count {
            let o = dir_off + i * 16;
            let (off, len) = (rd_i32(bytes, o), rd_i32(bytes, o + 4));
            if off < 0 || len < 0 {
                return Err(WadError::Truncated);
            }
            let (off, len) = (off as usize, len as usize);
            let data = if len == 0 {
                Vec::new()
            } else {
                let end = off.checked_add(len).ok_or(WadError::Truncated)?;
                bytes.get(off..end).ok_or(WadError::Truncated)?.to_vec()
            };
            let raw = &bytes[o + 8..o + 16];
            let end = raw.iter().position(|&c| c == 0).unwrap_or(8);
            let title: String = raw[..end].iter().map(|&c| c as char).collect();
            entries.push(WadEntry { title, data, ty: WadType::Unclassified });
        }
        let mut wad = Wad { kind, entries };
        wad.classify();
        Ok(wad)
    }

    /// Serializes with lumps packed back to back and the directory last
    /// (equivalent to a save followed by `PurgeWad`).
    pub fn to_bytes(&self) -> Vec<u8> {
        let total: usize = self.entries.iter().map(|e| e.data.len()).sum();
        let mut out = Vec::with_capacity(12 + total + self.entries.len() * 16);
        out.extend_from_slice(match self.kind {
            WadKind::Iwad => b"IWAD",
            WadKind::Pwad => b"PWAD",
        });
        out.extend_from_slice(&(self.entries.len() as i32).to_le_bytes());
        out.extend_from_slice(&((12 + total) as i32).to_le_bytes());
        let mut offsets = Vec::with_capacity(self.entries.len());
        for e in &self.entries {
            offsets.push(out.len() as i32);
            out.extend_from_slice(&e.data);
        }
        for (e, off) in self.entries.iter().zip(offsets) {
            out.extend_from_slice(&off.to_le_bytes());
            out.extend_from_slice(&(e.data.len() as i32).to_le_bytes());
            let mut name = [0u8; 8];
            for (i, c) in e.title.chars().take(8).enumerate() {
                name[i] = if (c as u32) < 256 { c as u8 } else { b'?' };
            }
            out.extend_from_slice(&name);
        }
        out
    }

    /// First entry titled `title` within `[from, from + count)`.
    pub fn find_in(&self, from: usize, count: usize, title: &str) -> Option<usize> {
        let hi = self.entries.len().min(from.saturating_add(count));
        (from..hi).find(|&i| self.entries[i].title == title)
    }

    pub fn find(&self, title: &str) -> Option<usize> {
        self.find_in(0, self.entries.len(), title)
    }

    /// Directory indices of every map header (`ExMy` / `MAPnn`).
    pub fn maps(&self) -> Vec<usize> {
        (0..self.entries.len()).filter(|&i| self.entries[i].ty == WadType::Map).collect()
    }

    /// Classifies every entry exactly as `LoadWad` does, including its
    /// ordering quirks (e.g. names starting `ST` or `WI` match before the
    /// map-lump names, and range membership only applies to non-empty lumps).
    pub fn classify(&mut self) {
        let (mut in_sprites, mut in_panels, mut in_tiles) = (false, false, false);
        for e in &mut self.entries {
            e.ty = classify_one(&e.title, e.data.len(), &mut in_sprites, &mut in_panels, &mut in_tiles);
        }
    }
}

fn classify_one(title: &str, len: usize, spr: &mut bool, pan: &mut bool, til: &mut bool) -> WadType {
    use WadType::*;
    let t = title.as_bytes();
    let at = |i: usize| t.get(i).copied().unwrap_or(0);

    if len > 0 {
        if *spr {
            return Sprite;
        }
        if *pan {
            return Panel;
        }
        if *til {
            return Tile;
        }
    }
    match (at(0), at(1)) {
        (b'D', b'S') => return Sound,
        (b'D', b'P') => return Beep,
        (b'D', b'_') => return Music,
        (b'W', b'I') => return Level,
        (b'M', b'_') => return Menu,
        (b'S', b'T') => return Status,
        _ => {}
    }
    if t.starts_with(b"DEMO") {
        return Demo;
    }
    if t.starts_with(b"PNAM") {
        return PNames;
    }
    match title {
        "PLAYPAL" => return PlayPal,
        "COLORMAP" => return ColorMap,
        _ => {}
    }
    if t.starts_with(b"TEXTUR") {
        return Texture;
    }
    match title {
        "THINGS" => return Things,
        "LINEDEFS" => return LineDefs,
        "SIDEDEFS" => return SideDefs,
        "VERTEXES" => return Vertexes,
        "SEGS" => return Segs,
        "SSECTORS" => return SSectors,
        "NODES" => return Nodes,
        "SECTORS" => return Sectors,
        "REJECT" => return Reject,
        "BLOCKMAP" => return BlockMap,
        "PLATFORM" | "TAGDESC" => return Tag,
        "ENDOOM" => return EnDoom,
        _ => {}
    }
    if len == 0 {
        if (at(0) == b'E' && at(2) == b'M' && at(4) == 0) || t.starts_with(b"MAP") {
            return Map;
        }
        match title {
            "S_START" => *spr = true,
            "S_END" => *spr = false,
            "P_START" => *pan = true,
            "P_END" => *pan = false,
            "F_START" => *til = true,
            "F_END" => *til = false,
            _ => {}
        }
        return Id;
    }
    Graphic
}

#[cfg(test)]
mod tests {
    use super::*;

    fn wad_of(names: &[(&str, usize)]) -> Wad {
        let mut w = Wad::new_pwad();
        for (n, l) in names {
            w.entries.push(WadEntry::new(n, vec![7; *l]));
        }
        w.classify();
        w
    }

    #[test]
    fn classification_matches_original() {
        use WadType::*;
        let w = wad_of(&[
            ("PLAYPAL", 5), ("S_START", 0), ("TROOA1", 4), ("S_END", 0),
            ("E1M1", 0), ("THINGS", 10), ("DSPISTOL", 3), ("DPPISTOL", 3), ("D_E1M1", 3),
            ("F_START", 0), ("FLOOR4_8", 4096), ("F_END", 0), ("TEXTURE1", 9),
            ("PNAMES", 9), ("ENDOOM", 9), ("MAP01", 0), ("PLATFORM", 0), ("WIMAP0", 5),
            ("M_DOOM", 5), ("STBAR", 5), ("DEMO1", 5), ("COLORMAP", 5), ("BIGGRAPH", 5),
        ]);
        let got: Vec<_> = w.entries.iter().map(|e| e.ty).collect();
        assert_eq!(
            got,
            vec![
                PlayPal, Id, Sprite, Id, Map, Things, Sound, Beep, Music, Id, Tile, Id, Texture,
                PNames, EnDoom, Map, Tag, Level, Menu, Status, Demo, ColorMap, Graphic
            ]
        );
        assert_eq!(w.maps(), vec![4, 15]);
    }

    #[test]
    fn bytes_roundtrip() {
        let mut w = wad_of(&[("E1M1", 0), ("THINGS", 20), ("DSBOOM", 3)]);
        w.kind = WadKind::Iwad;
        let w2 = Wad::from_bytes(&w.to_bytes()).unwrap();
        assert_eq!(w2.kind, WadKind::Iwad);
        assert_eq!(w2.entries, w.entries);
    }

    #[test]
    fn rejects_garbage() {
        assert!(matches!(Wad::from_bytes(b"nope"), Err(WadError::BadHeader)));
        let mut b = wad_of(&[("X", 4)]).to_bytes();
        b.truncate(b.len() - 8);
        assert!(matches!(Wad::from_bytes(&b), Err(WadError::Truncated)));
    }
}
