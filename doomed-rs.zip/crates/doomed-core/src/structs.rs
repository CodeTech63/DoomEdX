//! On-disk record layouts (all little-endian; the original's `int` is 16-bit).

/// The original's "null" index (`#define Nothing -1`).
pub const NOTHING: i16 = -1;

/// LineDef `solidity` bit masks (standard Doom meanings).
pub mod line_bits {
    pub const IMPASSABLE: i16 = 0x0001;
    pub const BLOCK_MONSTERS: i16 = 0x0002;
    pub const TWO_SIDED: i16 = 0x0004;
    pub const UPPER_UNPEGGED: i16 = 0x0008;
    pub const LOWER_UNPEGGED: i16 = 0x0010;
    pub const SECRET: i16 = 0x0020;
    pub const BLOCK_SOUND: i16 = 0x0040;
    pub const NOT_ON_MAP: i16 = 0x0080;
    pub const ALREADY_ON_MAP: i16 = 0x0100;
}

/// A fixed-size binary record.
pub trait Record: Sized + Clone {
    const SIZE: usize;
    /// `b` must hold at least `SIZE` bytes.
    fn read(b: &[u8]) -> Self;
    fn write(&self, out: &mut Vec<u8>);
}

/// Reads as many whole records as fit; a trailing partial record is ignored,
/// like the original's `Length / sizeof(...)`.
pub fn read_records<T: Record>(data: &[u8]) -> Vec<T> {
    data.chunks_exact(T::SIZE).map(T::read).collect()
}

pub fn write_records<T: Record>(v: &[T]) -> Vec<u8> {
    let mut out = Vec::with_capacity(v.len() * T::SIZE);
    for r in v {
        r.write(&mut out);
    }
    out
}

fn i16_at(b: &[u8], o: usize) -> i16 {
    i16::from_le_bytes([b[o], b[o + 1]])
}
fn name_at(b: &[u8], o: usize) -> [u8; 8] {
    let mut a = [0u8; 8];
    a.copy_from_slice(&b[o..o + 8]);
    a
}

macro_rules! i16_record {
    ($(#[$m:meta])* $name:ident { $($f:ident),* $(,)? }) => {
        $(#[$m])*
        #[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
        pub struct $name { $(pub $f: i16),* }
        impl Record for $name {
            const SIZE: usize = [$(stringify!($f)),*].len() * 2;
            #[allow(unused_assignments)]
            fn read(b: &[u8]) -> Self {
                let mut o = 0;
                $( let $f = i16_at(b, o); o += 2; )*
                Self { $($f),* }
            }
            fn write(&self, out: &mut Vec<u8>) {
                $( out.extend_from_slice(&self.$f.to_le_bytes()); )*
            }
        }
    };
}

i16_record!(/** 10 bytes. `lev` is the skill-level / multiplayer bit mask. */
    Thing { x, y, face, item, lev });
i16_record!(/** 14 bytes. */
    LineDef { from, to, solidity, special, tag, sidedef1, sidedef2 });
i16_record!(/** 4 bytes. */
    Vertex { x, y });
i16_record!(/** 12 bytes. `normal`: 1 = vertex1->vertex2, 0 = reversed. */
    Seg { from, to, angle, linedef, normal, distance });
i16_record!(/** 4 bytes. */
    SSector { num, segs });
i16_record!(/** 28 bytes. Bit 15 of `ssector1/2` marks a subsector. */
    Node { x, y, dx, dy, maxy1, miny1, minx1, maxx1, maxy2, miny2, minx2, maxx2, ssector1, ssector2 });

/// 30 bytes. Texture names are 8 bytes, NUL padded.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct SideDef {
    pub x: i16,
    pub y: i16,
    /// upper texture
    pub t1: [u8; 8],
    /// lower texture
    pub t2: [u8; 8],
    /// middle texture
    pub t3: [u8; 8],
    pub sector: i16,
}

impl Record for SideDef {
    const SIZE: usize = 30;
    fn read(b: &[u8]) -> Self {
        Self {
            x: i16_at(b, 0),
            y: i16_at(b, 2),
            t1: name_at(b, 4),
            t2: name_at(b, 12),
            t3: name_at(b, 20),
            sector: i16_at(b, 28),
        }
    }
    fn write(&self, out: &mut Vec<u8>) {
        out.extend_from_slice(&self.x.to_le_bytes());
        out.extend_from_slice(&self.y.to_le_bytes());
        out.extend_from_slice(&self.t1);
        out.extend_from_slice(&self.t2);
        out.extend_from_slice(&self.t3);
        out.extend_from_slice(&self.sector.to_le_bytes());
    }
}

/// 26 bytes.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Sector {
    pub floor_z: i16,
    pub ceil_z: i16,
    pub floor: [u8; 8],
    pub ceil: [u8; 8],
    pub light: i16,
    pub flash: i16,
    pub tag: i16,
}

impl Record for Sector {
    const SIZE: usize = 26;
    fn read(b: &[u8]) -> Self {
        Self {
            floor_z: i16_at(b, 0),
            ceil_z: i16_at(b, 2),
            floor: name_at(b, 4),
            ceil: name_at(b, 12),
            light: i16_at(b, 20),
            flash: i16_at(b, 22),
            tag: i16_at(b, 24),
        }
    }
    fn write(&self, out: &mut Vec<u8>) {
        out.extend_from_slice(&self.floor_z.to_le_bytes());
        out.extend_from_slice(&self.ceil_z.to_le_bytes());
        out.extend_from_slice(&self.floor);
        out.extend_from_slice(&self.ceil);
        out.extend_from_slice(&self.light.to_le_bytes());
        out.extend_from_slice(&self.flash.to_le_bytes());
        out.extend_from_slice(&self.tag.to_le_bytes());
    }
}

/// DoomEd's own `PLATFORM`/`TAGDESC` lump record: 274 bytes
/// (`int Num; char Name[16]; char Desc[256]`).
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct Tag {
    pub num: i16,
    pub name: String,
    pub desc: String,
}

impl Tag {
    /// Entry 0 of the tag list, always present.
    pub fn none() -> Self {
        Tag { num: 0, name: "0".into(), desc: "No Tag Number".into() }
    }
}

fn c_string(b: &[u8]) -> String {
    let end = b.iter().position(|&c| c == 0).unwrap_or(b.len());
    b[..end].iter().map(|&c| c as char).collect()
}

fn put_c_string(out: &mut Vec<u8>, s: &str, field_len: usize) {
    let start = out.len();
    out.extend(s.chars().map(|c| if (c as u32) < 256 { c as u8 } else { b'?' }).take(field_len - 1));
    out.resize(start + field_len, 0);
}

impl Record for Tag {
    const SIZE: usize = 274;
    fn read(b: &[u8]) -> Self {
        Tag { num: i16_at(b, 0), name: c_string(&b[2..18]), desc: c_string(&b[18..274]) }
    }
    fn write(&self, out: &mut Vec<u8>) {
        out.extend_from_slice(&self.num.to_le_bytes());
        put_c_string(out, &self.name, 16);
        put_c_string(out, &self.desc, 256);
    }
}

// ---- texture-name helpers (MACROS.HPP) ---------------------------------

/// `NullWall`: the "no texture" marker, `-` followed by NULs.
pub fn null_wall() -> [u8; 8] {
    let mut a = [0u8; 8];
    a[0] = b'-';
    a
}

/// `CopyWall`: `strncpy(to, from, 8)` semantics (copy up to the first NUL,
/// zero-pad the rest).
pub fn copy_wall(from: &[u8]) -> [u8; 8] {
    let mut a = [0u8; 8];
    for (i, &c) in from.iter().take(8).enumerate() {
        if c == 0 {
            break;
        }
        a[i] = c;
    }
    a
}

/// Texture/lump name bytes -> `String` (stops at the first NUL).
pub fn name8(b: &[u8; 8]) -> String {
    c_string(b)
}

/// `String` -> 8 byte NUL-padded name (truncating).
pub fn to_name8(s: &str) -> [u8; 8] {
    copy_wall(&s.chars().map(|c| if (c as u32) < 256 { c as u8 } else { b'?' }).collect::<Vec<_>>())
}

impl LineDef {
    pub fn set_bit(&mut self, mask: i16) {
        self.solidity |= mask;
    }
    pub fn clear_bit(&mut self, mask: i16) {
        self.solidity &= !mask;
    }
    pub fn test_bit(&self, mask: i16) -> bool {
        self.solidity & mask != 0
    }
    pub fn one_sided(&self) -> bool {
        self.sidedef1 == NOTHING || self.sidedef2 == NOTHING
    }
    pub fn two_sided(&self) -> bool {
        self.sidedef1 != NOTHING && self.sidedef2 != NOTHING
    }
}
