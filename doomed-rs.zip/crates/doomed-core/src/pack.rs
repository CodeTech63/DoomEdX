//! `PackMap` (ITEMADD.CPP) and `GetSectorExtents` (SELECT.CPP).
//!
//! Run before a node build: drops deleted items, drops sectors nothing
//! references, and rewrites the sidedef list in linedef order.

use crate::map::{Flags, MapData, Rect};
use crate::structs::*;

impl MapData {
    /// `GetSectorExtents`: bounding box per sector (index-aligned with
    /// `sectors`). `None` means no in-use linedef touches the sector.
    pub fn sector_extents(&self) -> Vec<Option<Rect>> {
        let mut out: Vec<Option<Rect>> = vec![None; self.sectors.len()];
        for (i, l) in self.linedefs.iter().enumerate() {
            if !crate::map::is_used(&self.linedef_flags, i) {
                continue;
            }
            let (Some(a), Some(b)) = (self.vertex(l.from), self.vertex(l.to)) else { continue };
            for side in [l.sidedef1, l.sidedef2] {
                if side == NOTHING {
                    continue;
                }
                let Some(sec) = self.sidedef(side).and_then(|s| usize::try_from(s.sector).ok()) else { continue };
                let Some(slot) = out.get_mut(sec) else { continue };
                let (x0, x1) = ((a.x as i32).min(b.x as i32), (a.x as i32).max(b.x as i32));
                let (y0, y1) = ((a.y as i32).min(b.y as i32), (a.y as i32).max(b.y as i32));
                *slot = Some(match *slot {
                    None => Rect { left: x0, right: x1, top: y1, bottom: y0 },
                    Some(r) => Rect {
                        left: r.left.min(x0),
                        right: r.right.max(x1),
                        top: r.top.max(y1),
                        bottom: r.bottom.min(y0),
                    },
                });
            }
        }
        out
    }

    fn vertex(&self, i: i16) -> Option<&Vertex> {
        usize::try_from(i).ok().and_then(|i| self.vertexes.get(i))
    }

    fn sidedef(&self, i: i16) -> Option<&SideDef> {
        usize::try_from(i).ok().and_then(|i| self.sidedefs.get(i))
    }

    /// `PackMap`.
    pub fn pack(&mut self) {
        self.normalize_flags();
        // --- sectors: orphans (no in-use linedef references them) are deleted
        let extents = self.sector_extents();
        for (f, e) in self.sector_flags.iter_mut().zip(&extents) {
            if f.used && e.is_none() {
                f.used = false;
            }
        }
        // new_index[k] = k minus the number of deleted sectors before k;
        // this is what the original's repeated delete-and-decrement yields.
        let mut deleted_before = Vec::with_capacity(self.sectors.len() + 1);
        let mut n = 0i32;
        for f in &self.sector_flags {
            deleted_before.push(n);
            if !f.used {
                n += 1;
            }
        }
        deleted_before.push(n);
        let mut old_sidedefs = std::mem::take(&mut self.sidedefs);
        for sd in &mut old_sidedefs {
            if let Ok(s) = usize::try_from(sd.sector) {
                sd.sector -= deleted_before[s.min(self.sector_flags.len())] as i16;
            }
        }
        retain_used(&mut self.sectors, &mut self.sector_flags);

        // --- linedefs and things: drop deleted ones
        retain_used(&mut self.linedefs, &mut self.linedef_flags);
        retain_used(&mut self.things, &mut self.thing_flags);

        // --- sidedefs: rebuilt in linedef order (side 1 then side 2)
        self.sidedefs.clear();
        for l in &mut self.linedefs {
            for side in [&mut l.sidedef1, &mut l.sidedef2] {
                if *side == NOTHING {
                    continue;
                }
                match usize::try_from(*side).ok().and_then(|i| old_sidedefs.get(i)) {
                    Some(sd) => {
                        *side = self.sidedefs.len() as i16;
                        self.sidedefs.push(*sd);
                    }
                    None => *side = NOTHING, // dangling reference
                }
            }
        }
        self.sidedef_flags = vec![Flags::default(); self.sidedefs.len()];
    }
}

fn retain_used<T>(items: &mut Vec<T>, flags: &mut Vec<Flags>) {
    let mut keep = flags.iter().map(|f| f.used);
    items.retain(|_| keep.next().unwrap_or(true));
    flags.retain(|f| f.used);
}
