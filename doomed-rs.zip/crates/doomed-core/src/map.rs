//! The current map: everything `READ.CPP` loads and `DoomEdFileSave` writes.

use crate::defaults::Defaults;
use crate::structs::*;
use crate::wad::{Wad, WadEntry};

/// Editor-side per-item state (the original's `Extra*` arrays).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Flags {
    /// `false` once the item has been deleted (removed for real by `pack`).
    pub used: bool,
    pub selected: bool,
    pub moving: bool,
}

impl Default for Flags {
    fn default() -> Self {
        Flags { used: true, selected: false, moving: false }
    }
}

/// Screen-style rectangle: `top` is the greater Y, `bottom` the lesser.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Rect {
    pub left: i32,
    pub right: i32,
    pub top: i32,
    pub bottom: i32,
}

/// Window of directory entries after a map header that `ReadMap` searches
/// (the header plus its 11 lumps).
pub const MAP_GROUP: usize = 12;

#[derive(Debug, Clone)]
pub struct MapData {
    /// e.g. `E1M1`, `MAP01`.
    pub name: String,
    pub things: Vec<Thing>,
    pub vertexes: Vec<Vertex>,
    pub linedefs: Vec<LineDef>,
    pub sidedefs: Vec<SideDef>,
    pub segs: Vec<Seg>,
    pub ssectors: Vec<SSector>,
    pub nodes: Vec<Node>,
    pub sectors: Vec<Sector>,
    /// Raw `REJECT` lump.
    pub reject: Vec<u8>,
    /// Raw `BLOCKMAP` lump (little-endian 16-bit words).
    pub blockmap: Vec<u8>,
    /// Tag list; index 0 is always the "No Tag Number" placeholder.
    pub tags: Vec<Tag>,
    /// Next tag number to hand out (the original's `NextTag`).
    pub next_tag: i32,

    pub thing_flags: Vec<Flags>,
    pub vertex_flags: Vec<Flags>,
    pub linedef_flags: Vec<Flags>,
    pub sidedef_flags: Vec<Flags>,
    pub sector_flags: Vec<Flags>,

    /// `MapEdited`: something changed that requires a save.
    pub edited: bool,
    /// `MapNodes`: something changed that requires the nodes to be rebuilt.
    pub nodes_dirty: bool,

    /// Templates for newly created items (`DefThing`, `DefSector`, ...).
    /// Editor-session state, kept here so edit operations can create items.
    pub defaults: Defaults,
}

/// Missing flag entries count as "in use" (the editor only ever clears them).
pub(crate) fn is_used(flags: &[Flags], i: usize) -> bool {
    flags.get(i).map_or(true, |f| f.used)
}

impl MapData {
    pub fn new(name: &str) -> Self {
        MapData {
            name: name.to_string(),
            things: vec![],
            vertexes: vec![],
            linedefs: vec![],
            sidedefs: vec![],
            segs: vec![],
            ssectors: vec![],
            nodes: vec![],
            sectors: vec![],
            reject: vec![],
            blockmap: vec![],
            tags: vec![Tag::none()],
            // ReadMap starts at 1 and always increments once more at the end.
            next_tag: 2,
            thing_flags: vec![],
            vertex_flags: vec![],
            linedef_flags: vec![],
            sidedef_flags: vec![],
            sector_flags: vec![],
            edited: false,
            nodes_dirty: false,
            defaults: Defaults::default(),
        }
    }

    /// `MapChange`: something requires a save.
    pub fn mark_changed(&mut self) {
        self.edited = true;
    }

    /// `MapChangeNode`: something requires the nodes to be rebuilt.
    pub fn mark_nodes_dirty(&mut self) {
        self.mark_changed();
        self.nodes_dirty = true;
    }

    /// Makes every flag vector the same length as its item vector; new
    /// entries are "in use". Cheap insurance for code that pushes items.
    pub fn normalize_flags(&mut self) {
        self.thing_flags.resize(self.things.len(), Flags::default());
        self.vertex_flags.resize(self.vertexes.len(), Flags::default());
        self.linedef_flags.resize(self.linedefs.len(), Flags::default());
        self.sidedef_flags.resize(self.sidedefs.len(), Flags::default());
        self.sector_flags.resize(self.sectors.len(), Flags::default());
    }

    /// Which vertices are referenced by in-use linedefs (non-mutating
    /// `FindVertexesInUse`).
    pub fn used_vertex_mask(&self) -> Vec<bool> {
        let mut used = vec![false; self.vertexes.len()];
        for (i, l) in self.linedefs.iter().enumerate() {
            if is_used(&self.linedef_flags, i) {
                for v in [l.from, l.to] {
                    if let Some(u) = usize::try_from(v).ok().and_then(|v| used.get_mut(v)) {
                        *u = true;
                    }
                }
            }
        }
        used
    }

    /// `VertexNew` (ITEMADD.CPP): the first unused vertex slot, else a new one
    /// at the end. The slot is marked used. `None` if the 16-bit index space
    /// is exhausted.
    pub fn vertex_new(&mut self) -> Option<usize> {
        self.normalize_flags();
        let i = match self.vertex_flags.iter().position(|f| !f.used) {
            Some(i) => i,
            None => {
                self.vertexes.push(Vertex::default());
                self.vertex_flags.push(Flags::default());
                self.vertexes.len() - 1
            }
        };
        if i > i16::MAX as usize {
            return None;
        }
        self.vertex_flags[i].used = true;
        self.nodes_dirty = true;
        self.edited = true;
        Some(i)
    }

    /// `ReadMap`: loads the map whose header is at directory index `header`.
    ///
    /// Lumps are looked up by exact title inside the 12-entry window starting
    /// at the header; a missing lump loads as empty.
    pub fn load(wad: &Wad, header: usize) -> Option<MapData> {
        let head = wad.entries.get(header)?;
        let mut m = MapData::new(&head.title);
        let lump = |title: &str| -> &[u8] {
            wad.find_in(header, MAP_GROUP, title).map(|i| wad.entries[i].data.as_slice()).unwrap_or(&[])
        };

        m.things = read_records(lump("THINGS"));
        m.vertexes = read_records(lump("VERTEXES"));
        m.linedefs = read_records(lump("LINEDEFS"));
        m.sidedefs = read_records(lump("SIDEDEFS"));
        m.segs = read_records(lump("SEGS"));
        m.ssectors = read_records(lump("SSECTORS"));
        m.nodes = read_records(lump("NODES"));
        m.sectors = read_records(lump("SECTORS"));
        m.reject = lump("REJECT").to_vec();
        m.blockmap = lump("BLOCKMAP").to_vec();

        // Everything loaded is "in use" (the original sets Used for the
        // editable item types only).
        m.thing_flags = vec![Flags::default(); m.things.len()];
        m.vertex_flags = vec![Flags::default(); m.vertexes.len()];
        m.linedef_flags = vec![Flags::default(); m.linedefs.len()];
        m.sidedef_flags = vec![Flags::default(); m.sidedefs.len()];
        m.sector_flags = vec![Flags::default(); m.sectors.len()];

        // Tags: PLATFORM or TAGDESC lump if present, else derive from sectors.
        let mut next_tag: i32 = 1;
        m.tags = vec![Tag::none()];
        let tag_lump = (header..wad.entries.len().min(header + MAP_GROUP))
            .find(|&i| matches!(wad.entries[i].title.as_str(), "PLATFORM" | "TAGDESC"));
        if let Some(i) = tag_lump {
            // Unused (number 0) entries are dropped.
            m.tags.extend(read_records::<Tag>(&wad.entries[i].data).into_iter().filter(|t| t.num != 0));
            for t in &m.tags {
                next_tag = next_tag.max(t.num as i32);
            }
        } else {
            for s in &m.sectors {
                if s.tag > 0 && !m.tags[1..].iter().any(|t| t.num == s.tag) {
                    next_tag = next_tag.max(s.tag as i32);
                    m.tags.push(Tag { num: s.tag, name: format!("Tag{}", s.tag), desc: String::new() });
                }
            }
        }
        m.next_tag = next_tag + 1;

        m.find_vertexes_in_use();
        Some(m)
    }

    /// `FindVertexesInUse`: clears all vertex state, then marks vertices
    /// referenced by in-use linedefs. (Like the original this also clears
    /// selection/moving flags on vertices.)
    pub fn find_vertexes_in_use(&mut self) {
        let used = self.used_vertex_mask();
        self.vertex_flags = used.into_iter().map(|u| Flags { used: u, selected: false, moving: false }).collect();
    }

    /// `GetMapExtents`: bounding box of vertices used by in-use linedefs, with
    /// the original's 50-unit border. `None` for an empty map.
    ///
    /// Unlike the original (whose loop starts at vertex 1), vertex 0 is
    /// included, and this does not disturb vertex selection state.
    pub fn map_extent(&self) -> Option<Rect> {
        let used = self.used_vertex_mask();
        let mut r: Option<Rect> = None;
        for (v, _) in self.vertexes.iter().zip(&used).filter(|(_, &u)| u) {
            let (x, y) = (v.x as i32, v.y as i32);
            r = Some(match r {
                None => Rect { left: x, right: x, top: y, bottom: y },
                Some(r) => Rect {
                    left: r.left.min(x),
                    right: r.right.max(x),
                    top: r.top.max(y),
                    bottom: r.bottom.min(y),
                },
            });
        }
        r.map(|r| Rect { left: r.left - 50, right: r.right + 50, top: r.top + 50, bottom: r.bottom - 50 })
    }

    /// The 11 lumps DoomEd writes for a map, in its order.
    fn lumps(&self) -> Vec<WadEntry> {
        let tag_bytes = write_records(self.tags.get(1..).unwrap_or(&[]));
        vec![
            WadEntry::new("THINGS", write_records(&self.things)),
            WadEntry::new("LINEDEFS", write_records(&self.linedefs)),
            WadEntry::new("SIDEDEFS", write_records(&self.sidedefs)),
            WadEntry::new("VERTEXES", write_records(&self.vertexes)),
            WadEntry::new("SEGS", write_records(&self.segs)),
            WadEntry::new("SSECTORS", write_records(&self.ssectors)),
            WadEntry::new("NODES", write_records(&self.nodes)),
            WadEntry::new("SECTORS", write_records(&self.sectors)),
            WadEntry::new("REJECT", self.reject.clone()),
            WadEntry::new("BLOCKMAP", self.blockmap.clone()),
            WadEntry::new("TAGDESC", tag_bytes),
        ]
    }

    /// `DoomEdFileSave`: writes this map into `wad`, returning the header's
    /// directory index.
    ///
    /// An existing group whose title starts with the map name is replaced in
    /// place (the header plus the following map lumps, including DoomEd's own
    /// tag lump, are removed first); otherwise the map is appended.
    pub fn save_into(&self, wad: &mut Wad) -> usize {
        let existing = wad.entries.iter().position(|e| e.title.starts_with(&self.name));
        let at = match existing {
            None => wad.entries.len(),
            Some(h) => {
                let t = wad.entries[h].title.as_bytes();
                let is_header = (t.first() == Some(&b'E') && t.get(2) == Some(&b'M')) || t.starts_with(b"MAP");
                if is_header {
                    let mut count = 1;
                    for i in h + 1..(h + MAP_GROUP).min(wad.entries.len()) {
                        if wad.entries[i].ty.is_map_lump() {
                            count += 1;
                        } else {
                            break;
                        }
                    }
                    wad.entries.drain(h..h + count);
                }
                h
            }
        };
        let mut group = vec![WadEntry::new(&self.name, Vec::new())];
        group.extend(self.lumps());
        wad.entries.splice(at..at, group);
        wad.classify();
        at
    }
}
