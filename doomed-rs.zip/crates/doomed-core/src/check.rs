//! The map checker (`DialogMapCheck` in `TOOLS.CPP`).
//!
//! Looks up flat/lump names and wall textures through the [`Assets`] trait so
//! the model needs no file access. Problem texts match the original's exactly,
//! including a labelling inconsistency: the "Invalid ... Texture" messages call
//! a sidedef's first texture "Lower" and its second "Upper" (the reverse of
//! Doom's upper/lower naming), while the "Missing ..." messages use the
//! conventional meaning.

use crate::finders::Point;
use crate::map::{is_used, MapData};
use crate::structs::*;
use crate::wad::{Wad, WadType};
use std::collections::HashSet;

/// The original lists at most 50 problems.
pub const MAX_PROBLEMS: usize = 50;

/// What the checker validates names against.
pub trait Assets {
    /// `DoomEntry`: is there a lump with exactly this title? (Used for
    /// floors and ceilings; the name is upper-cased first; empty never matches.)
    fn lump_exists(&self, name: &str) -> bool;
    /// `TextureEntry`: does any texture name *start with* `name`? The
    /// original compares only `strlen(name)` characters, so a truncated name
    /// passes. Empty never matches.
    fn texture_matches(&self, name: &str) -> bool;
}

/// A ready-made [`Assets`] built from WADs.
#[derive(Debug, Clone, Default)]
pub struct NameSets {
    pub lumps: HashSet<String>,
    pub textures: Vec<String>,
}

/// Names from a `TEXTURE1`/`TEXTURE2` lump.
pub fn parse_texture_names(data: &[u8]) -> Vec<String> {
    let rd = |o: usize| data.get(o..o + 4).map(|b| i32::from_le_bytes([b[0], b[1], b[2], b[3]]));
    let Some(count) = rd(0).filter(|&c| c >= 0) else { return vec![] };
    (0..count as usize)
        .filter_map(|i| {
            let off = rd(4 + i * 4)? as usize;
            let raw = data.get(off..off + 8)?;
            let end = raw.iter().position(|&c| c == 0).unwrap_or(8);
            Some(raw[..end].iter().map(|&c| c as char).collect())
        })
        .collect()
}

impl NameSets {
    /// Adds every lump title and texture name of `wad`.
    pub fn add_wad(&mut self, wad: &Wad) {
        for e in &wad.entries {
            self.lumps.insert(e.title.clone());
            if e.ty == WadType::Texture {
                self.textures.extend(parse_texture_names(&e.data));
            }
        }
    }

    pub fn from_wads(wads: &[&Wad]) -> Self {
        let mut s = NameSets::default();
        for w in wads {
            s.add_wad(w);
        }
        s
    }
}

impl Assets for NameSets {
    fn lump_exists(&self, name: &str) -> bool {
        !name.is_empty() && self.lumps.contains(&name.to_ascii_uppercase())
    }
    fn texture_matches(&self, name: &str) -> bool {
        let up = name.to_ascii_uppercase();
        !up.is_empty() && self.textures.iter().any(|t| t.starts_with(&up))
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProblemKind {
    Thing,
    Line,
    Sector,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Problem {
    pub desc: String,
    pub what: ProblemKind,
    /// The item to jump to; `None` for map-wide problems.
    pub which: Option<usize>,
}

impl MapData {
    /// `DialogMapCheck` / `IDC_BEGIN`.
    pub fn check_map(&self, assets: &dyn Assets) -> Vec<Problem> {
        let mut out: Vec<Problem> = Vec::new();
        let mut add = |desc: String, what: ProblemKind, which: Option<usize>| {
            if out.len() < MAX_PROBLEMS {
                out.push(Problem { desc, what, which });
            }
        };

        // deathmatch starts
        let dm = (0..self.things.len()).filter(|&i| is_used(&self.thing_flags, i) && self.things[i].item == 11).count();
        if dm < 4 {
            add("Less than 4 Deathmatch starts".into(), ProblemKind::Thing, None);
        }
        if dm > 10 {
            add("More than 10 Deathmatch starts".into(), ProblemKind::Thing, None);
        }

        // floors, then ceilings
        for (label, pick) in [("Invalid Floor", true), ("Invalid Ceiling", false)] {
            for (i, s) in self.sectors.iter().enumerate() {
                if is_used(&self.sector_flags, i) {
                    let name = name8(if pick { &s.floor } else { &s.ceil });
                    if !assets.lump_exists(&name) {
                        add(format!("{label}: {name}"), ProblemKind::Sector, Some(i));
                    }
                }
            }
        }

        // wall textures that don't exist
        for (i, l) in self.linedefs.iter().enumerate() {
            if !is_used(&self.linedef_flags, i) {
                continue;
            }
            for (face, sd) in [("Front", l.sidedef1), ("Back", l.sidedef2)] {
                let Some(s) = usize::try_from(sd).ok().and_then(|s| self.sidedefs.get(s)) else { continue };
                for (label, t) in [("Lower", &s.t1), ("Upper", &s.t2), ("Main", &s.t3)] {
                    if t[0] != b'-' {
                        let name = name8(t);
                        if !assets.texture_matches(&name) {
                            add(format!("Invalid {face} \"{label}\" Texture: {name}"), ProblemKind::Line, Some(i));
                        }
                    }
                }
            }
        }

        // textures missing where they are needed
        for (i, l) in self.linedefs.iter().enumerate() {
            if !is_used(&self.linedef_flags, i) {
                continue;
            }
            let side = |sd: i16| usize::try_from(sd).ok().and_then(|s| self.sidedefs.get(s));
            let (s1, s2) = (side(l.sidedef1), side(l.sidedef2));
            if l.sidedef1 == NOTHING || l.sidedef2 == NOTHING {
                if s1.map_or(false, |s| s.t3[0] == b'-') {
                    add("Missing Front \"Main\" Texture".into(), ProblemKind::Line, Some(i));
                }
                if s2.map_or(false, |s| s.t3[0] == b'-') {
                    add("Missing Back \"Main\" Texture".into(), ProblemKind::Line, Some(i));
                }
            } else if let (Some(a), Some(b)) = (s1, s2) {
                let (Some(sa), Some(sb)) = (self.sectors.get(a.sector as usize), self.sectors.get(b.sector as usize))
                else {
                    continue;
                };
                let blank = |t: &[u8; 8]| t[0] == b'-' || t[0] == 0;
                let pegtop = l.test_bit(line_bits::UPPER_UNPEGGED);
                let pegbottom = l.test_bit(line_bits::LOWER_UNPEGGED);
                if sa.floor_z < sb.floor_z && blank(&a.t2) && !pegtop {
                    add("Missing Front \"Lower\" Texture".into(), ProblemKind::Line, Some(i));
                }
                if sa.floor_z > sb.floor_z && blank(&b.t2) && !pegtop {
                    add("Missing Back \"Lower\" Texture".into(), ProblemKind::Line, Some(i));
                }
                if sa.ceil_z > sb.ceil_z && blank(&a.t1) && !pegbottom {
                    add("Missing Front \"Upper\" Texture".into(), ProblemKind::Line, Some(i));
                }
                if sa.ceil_z < sb.ceil_z && blank(&b.t1) && !pegbottom {
                    add("Missing Back \"Upper\" Texture".into(), ProblemKind::Line, Some(i));
                }
            }
        }

        // things outside every sector
        for (i, t) in self.things.iter().enumerate() {
            if is_used(&self.thing_flags, i) && self.nearest_sector(Point::new(t.x as i32, t.y as i32)).is_none() {
                add("Orphan Thing (not in sector)".into(), ProblemKind::Thing, Some(i));
            }
        }
        out
    }
}
