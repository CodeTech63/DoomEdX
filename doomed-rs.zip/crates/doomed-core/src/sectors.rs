//! Sector-level editing: detach / extract / duplicate / drop, and the sector
//! generators (rectangle, polygon, star, steps).
//! From `SECTOR.CPP`, `TOOLS.CPP`, `NEWSECT.CPP` and `STEPS.CPP`.
//!
//! Detach, extract, duplicate and the generators work by marking new
//! vertexes and linedefs as *moving*; the caller then drags them and finishes
//! with [`MapData::process_joins`], which welds whatever ends up touching.

use crate::finders::Point;
use crate::map::{is_used, MapData, Rect};
use crate::select::Kind;
use crate::structs::*;

const PI180: f64 = 0.017453292;

/// `Direction` of a stair (`East`, `North`, ... as in the Steps dialog).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Direction {
    East,
    North,
    West,
    South,
}

/// The Steps dialog's settings.
#[derive(Debug, Clone)]
pub struct StepsParams {
    pub low_height: i16,
    pub step_height: i16,
    pub num_steps: i16,
    pub direction: Direction,
    /// Texture put on the riser of each step (the dialog defaults to `STEP4`).
    pub runner_texture: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StepsError {
    /// The original divides the stair length by the number of steps.
    NoSteps,
}

impl MapData {
    /// Gives line `i` its own fresh vertexes (copies of its ends), all marked
    /// moving, and marks the line itself moving.
    pub fn make_line_moving(&mut self, i: usize) {
        for end in [0, 1] {
            let old = if end == 0 { self.linedefs[i].from } else { self.linedefs[i].to };
            let newv = self.vertex_new().expect("vertex space");
            self.vertexes[newv] = self.vertexes[old as usize];
            self.vertex_flags[newv].moving = true;
            if end == 0 {
                self.linedefs[i].from = newv as i16;
            } else {
                self.linedefs[i].to = newv as i16;
            }
        }
        self.linedef_flags[i].moving = true;
    }

    pub fn clear_moving(&mut self) {
        self.normalize_flags();
        for f in self.vertex_flags.iter_mut().chain(self.linedef_flags.iter_mut()) {
            f.moving = false;
        }
    }

    pub fn sector_selected(&self, s: usize) -> bool {
        self.sector_flags.get(s).map_or(false, |f| f.selected)
    }

    /// For each selected sector that lies wholly inside one other sector (every
    /// wall it has is two-sided with that same sector on the far side), the
    /// enclosing sector. `None` for the rest.
    fn enclosing_sectors(&self) -> Vec<Option<usize>> {
        #[derive(Clone, Copy, PartialEq)]
        enum H {
            Unset,
            One(usize),
            No,
        }
        let mut h = vec![H::Unset; self.sectors.len()];
        let mut note = |h: &mut Vec<H>, a: usize, other: Option<usize>| {
            if !self.sector_selected(a) {
                return;
            }
            h[a] = match (h[a], other) {
                (H::No, _) | (_, None) => H::No,
                (H::Unset, Some(o)) => H::One(o),
                (H::One(x), Some(o)) if x == o => H::One(x),
                _ => H::No,
            };
        };
        for i in 0..self.linedefs.len() {
            if !is_used(&self.linedef_flags, i) {
                continue;
            }
            let l = self.linedefs[i];
            let (a, b) = (self.side_sector(l.sidedef1), self.side_sector(l.sidedef2));
            match (a, b) {
                (Some(a), Some(b)) if a == b => {}
                (Some(a), Some(b)) => {
                    // a selected neighbour (or an unselected one) is the "other" side
                    let (sa, sb) = (self.sector_selected(a), self.sector_selected(b));
                    if sa && !sb {
                        note(&mut h, a, Some(b));
                    } else if sb && !sa {
                        note(&mut h, b, Some(a));
                    } else if sa && sb {
                        note(&mut h, a, None);
                        note(&mut h, b, None);
                    }
                }
                (Some(a), None) | (None, Some(a)) => note(&mut h, a, None), // touches the void
                (None, None) => {}
            }
        }
        h.into_iter().map(|x| if let H::One(o) = x { Some(o) } else { None }).collect()
    }

    /// `DetachSectors`: separates the selected sectors from their neighbours.
    /// Lines between a selected and an unselected sector are split into two
    /// one-sided lines; afterwards only vertexes and linedefs marked moving
    /// belong to the selection.
    pub fn detach_sectors(&mut self) {
        self.clear_moving();
        let hosts = self.enclosing_sectors();
        let mut i = 0;
        while i < self.linedefs.len() {
            if is_used(&self.linedef_flags, i) {
                let l = self.linedefs[i];
                let (sec1, sec2) = (self.side_sector(l.sidedef1), self.side_sector(l.sidedef2));
                if let (Some(s1), Some(s2)) = (sec1, sec2) {
                    let (sel1, sel2) = (self.sector_selected(s1), self.sector_selected(s2));
                    let nested = if sel1 != sel2 {
                        let (inner, outer) = if sel1 { (s1, s2) } else { (s2, s1) };
                        hosts.get(inner).copied().flatten() == Some(outer)
                    } else {
                        false
                    };
                    if nested {
                        // a sector inside another: the shared walls are not split;
                        // their vertexes move, so the outer sector follows
                        self.linedef_flags[i].moving = true;
                        for v in [self.linedefs[i].from, self.linedefs[i].to] {
                            if let Some(f) = self.vertex_flags.get_mut(v as usize) {
                                f.moving = true;
                            }
                        }
                    } else if sel1 != sel2 {
                        // only one side is selected: make a new line to move
                        let newl = self.linedef_new();
                        let newv1 = self.vertex_new().expect("vertex space");
                        let newv2 = self.vertex_new().expect("vertex space");
                        self.vertexes[newv1] = self.vertexes[self.linedefs[i].from as usize];
                        self.vertexes[newv2] = self.vertexes[self.linedefs[i].to as usize];
                        self.linedefs[i].set_bit(line_bits::IMPASSABLE);
                        self.linedefs[i].clear_bit(line_bits::TWO_SIDED);
                        self.linedefs[newl] = self.linedefs[i];
                        self.linedefs[newl].sidedef1 = self.linedefs[i].sidedef2;
                        self.linedefs[i].sidedef2 = NOTHING;
                        self.linedefs[newl].sidedef2 = NOTHING;
                        self.fill_opening(self.linedefs[i].sidedef1);
                        self.fill_opening(self.linedefs[newl].sidedef1);
                        self.vertex_flags[newv1].moving = true;
                        self.vertex_flags[newv2].moving = true;
                        if sel1 {
                            self.linedef_flags[i].moving = true;
                            self.linedefs[newl].from = self.linedefs[i].to;
                            self.linedefs[newl].to = self.linedefs[i].from;
                            self.linedefs[i].from = newv1 as i16;
                            self.linedefs[i].to = newv2 as i16;
                        } else {
                            self.linedef_flags[newl].moving = true;
                            self.linedefs[newl].to = newv1 as i16;
                            self.linedefs[newl].from = newv2 as i16;
                        }
                    } else if sel1 && sel2 {
                        self.make_line_moving(i); // both sides selected
                    }
                } else {
                    // one sided
                    let sel = |s: Option<usize>| s.map_or(false, |s| self.sector_selected(s));
                    if sel(sec1) || sel(sec2) {
                        self.make_line_moving(i);
                    }
                }
            }
            i += 1;
        }
    }

    /// `ExtractSectors`: like detach, but the neighbours' side of each border
    /// line is removed, so the selection leaves its surroundings intact and
    /// only the selected sectors' own lines move.
    pub fn extract_sectors(&mut self) {
        self.clear_moving();
        let mut i = 0;
        while i < self.linedefs.len() {
            if is_used(&self.linedef_flags, i) {
                let l = self.linedefs[i];
                let (sec1, sec2) = (self.side_sector(l.sidedef1), self.side_sector(l.sidedef2));
                if let (Some(s1), Some(s2)) = (sec1, sec2) {
                    let (sel1, sel2) = (self.sector_selected(s1), self.sector_selected(s2));
                    if sel1 != sel2 {
                        self.linedefs[i].set_bit(line_bits::IMPASSABLE);
                        self.linedefs[i].clear_bit(line_bits::TWO_SIDED);
                        if sel1 {
                            // delete back
                            self.sidedef_del(self.linedefs[i].sidedef2);
                            self.linedefs[i].sidedef2 = NOTHING;
                        } else {
                            // delete front, reverse so sidedef 1 is used
                            self.sidedef_del(self.linedefs[i].sidedef1);
                            self.linedefs[i].sidedef1 = self.linedefs[i].sidedef2;
                            self.linedefs[i].sidedef2 = NOTHING;
                            let l = &mut self.linedefs[i];
                            std::mem::swap(&mut l.from, &mut l.to);
                        }
                        self.fill_opening(self.linedefs[i].sidedef1);
                        self.make_line_moving(i);
                    } else if sel1 && sel2 {
                        self.make_line_moving(i);
                    }
                } else {
                    let sel = |s: Option<usize>| s.map_or(false, |s| self.sector_selected(s));
                    if sel(sec1) || sel(sec2) {
                        self.make_line_moving(i);
                    }
                }
            }
            i += 1;
        }
    }

    /// `SectorDuplicate`: copies every selected sector to the right of the
    /// whole map, selecting the copies instead of the originals and leaving
    /// the new lines moving. Returns `false` when no sector is selected.
    pub fn sector_duplicate(&mut self) -> bool {
        self.normalize_flags();
        if self.selected_count(Kind::Sector) == 0 {
            return false;
        }
        let snapshot = self.sector_flags.clone();
        let original_count = self.sectors.len();
        let extent = self.map_extent();
        let ext = self.sector_extents();
        let mut re_left = i32::MAX;
        for (i, f) in snapshot.iter().enumerate() {
            if f.used && f.selected {
                if let Some(e) = ext[i] {
                    re_left = re_left.min(e.left);
                }
            }
        }
        let leftoffset = extent.map_or(0, |e| e.right) - if re_left == i32::MAX { 0 } else { re_left };

        for i in 0..original_count {
            if !(snapshot[i].used && snapshot[i].selected) {
                continue;
            }
            let news = self.sector_new();
            self.sectors[news] = self.sectors[i];
            let mut j = 0;
            while j < self.linedefs.len() {
                if is_used(&self.linedef_flags, j) {
                    for side in [1, 2] {
                        let sd = if side == 1 { self.linedefs[j].sidedef1 } else { self.linedefs[j].sidedef2 };
                        if sd != NOTHING && self.side_sector(sd) == Some(i) {
                            let newl = self.linedef_new();
                            self.linedef_flags[newl].moving = true;
                            let (src_from, src_to) = (self.linedefs[j].from as usize, self.linedefs[j].to as usize);
                            let from = self.vertex_new().expect("vertex space");
                            let to = self.vertex_new().expect("vertex space");
                            self.linedefs[newl].from = from as i16;
                            self.linedefs[newl].to = to as i16;
                            self.vertexes[from] = self.vertexes[src_from];
                            self.vertexes[to] = self.vertexes[src_to];
                            self.vertex_flags[from].moving = true;
                            self.vertex_flags[to].moving = true;
                            let src = self.linedefs[j];
                            self.linedefs[newl].solidity = src.solidity;
                            self.linedefs[newl].special = src.special;
                            self.linedefs[newl].tag = src.tag;
                            let newd = self.sidedef_new();
                            self.sidedefs[newd] = self.sidedefs[sd as usize];
                            self.sidedefs[newd].sector = news as i16;
                            if side == 1 {
                                self.linedefs[newl].sidedef1 = newd as i16;
                            } else {
                                self.linedefs[newl].sidedef2 = newd as i16;
                            }
                            self.vertexes[from].x = self.vertexes[from].x.wrapping_add(leftoffset as i16);
                            self.vertexes[to].x = self.vertexes[to].x.wrapping_add(leftoffset as i16);
                        }
                    }
                }
                j += 1;
            }
            self.select(Kind::Sector, i); // toggles the original off...
            self.select(Kind::Sector, news); // ...and the copy on
        }
        self.process_joins();
        true
    }

    /// `DropSectors`: a dragged sector was dropped at `current`. If it landed
    /// inside another (unselected) sector, its border lines are given a
    /// reversed twin facing out, so it becomes a sector-in-sector. Returns
    /// the sector it was dropped into.
    pub fn drop_sectors(&mut self, current: Point) -> Option<usize> {
        self.normalize_flags();
        let inside = self.nearest_sector_not_moving(current)?;
        if self.sector_selected(inside) {
            return None;
        }
        let mut n = 0;
        while n < self.linedefs.len() {
            if self.linedef_flags[n].moving {
                let mut j = 0;
                while j < self.linedefs.len() {
                    let ln = self.linedefs[n];
                    if is_used(&self.linedef_flags, j)
                        && (ln.sidedef1 == NOTHING || ln.sidedef2 == NOTHING)
                        && j != n
                        && self.coincident(n, j)
                    {
                        self.join_2_lines(n, j); // already a line here
                    }
                    j += 1;
                }
                let ln = self.linedefs[n];
                if ln.sidedef1 == NOTHING || ln.sidedef2 == NOTHING {
                    // add a side: a new line facing the surrounding sector
                    let newl = self.linedef_sidedef_new();
                    let (a, b) = (self.linedefs[n].from as usize, self.linedefs[n].to as usize);
                    let v = self.vertex_new().expect("vertex space");
                    self.vertexes[v] = self.vertexes[a];
                    self.linedefs[newl].from = v as i16;
                    let v = self.vertex_new().expect("vertex space");
                    self.vertexes[v] = self.vertexes[b];
                    self.linedefs[newl].to = v as i16;
                    let sd = self.linedefs[newl].sidedef1 as usize;
                    self.sidedefs[sd].sector = inside as i16;
                    // reverse the dropped line so the sector faces "out"
                    let l = &mut self.linedefs[n];
                    std::mem::swap(&mut l.from, &mut l.to);
                    std::mem::swap(&mut l.sidedef1, &mut l.sidedef2);
                }
            }
            n += 1;
        }
        Some(inside)
    }

    /// Do two linedefs occupy the same place (compared by coordinates)?
    fn coincident(&self, n: usize, j: usize) -> bool {
        let at = |i: i16| self.vertexes.get(i as usize).map(|v| (v.x, v.y));
        let (a, b) = (self.linedefs[n], self.linedefs[j]);
        let (nf, nt, jf, jt) = (at(a.from), at(a.to), at(b.from), at(b.to));
        nf.is_some() && nt.is_some() && jf.is_some() && jt.is_some() && ((nf == jt && nt == jf) || (nf == jf && nt == jt))
    }

    /// Makes a closed one-sided polygon as a new sector (the vertexes are
    /// created first, then the lines `i -> i + 1` and the closing line) and
    /// selects only that sector.
    fn new_polygon_sector(&mut self, pts: &[(i32, i32)]) -> usize {
        let news = self.sector_new();
        let verts: Vec<usize> = pts
            .iter()
            .map(|&(x, y)| {
                let v = self.vertex_new().expect("vertex space");
                self.vertexes[v] = Vertex { x: x as i16, y: y as i16 };
                v
            })
            .collect();
        for i in 0..verts.len() {
            let l = self.linedef_sidedef_new();
            let sd = self.linedefs[l].sidedef1 as usize;
            self.sidedefs[sd].sector = news as i16;
            self.linedefs[l].from = verts[i] as i16;
            self.linedefs[l].to = verts[(i + 1) % verts.len()] as i16;
        }
        self.unselect_all(Kind::Sector);
        self.select(Kind::Sector, news);
        news
    }

    /// `AddNewSector`, rectangle: a sector the size of `r`.
    pub fn add_rect_sector(&mut self, r: &Rect) -> usize {
        self.new_polygon_sector(&[(r.left, r.top), (r.right, r.top), (r.right, r.bottom), (r.left, r.bottom)])
    }

    /// `AddNewSector`, polygon: a regular `sides`-gon (3 to 64) inscribed in
    /// `r`, first corner at the top, going clockwise. `None` for a bad count.
    pub fn add_polygon_sector(&mut self, r: &Rect, sides: u32) -> Option<usize> {
        if !(3..=64).contains(&sides) {
            return None;
        }
        let (cx, cy) = (r.left + (r.right - r.left) / 2, r.bottom + (r.top - r.bottom) / 2);
        let (ex, ey) = ((r.right - r.left) as f64 / 2.0, (r.top - r.bottom) as f64 / 2.0);
        let rot = if sides % 2 == 0 { 360.0 / sides as f64 / 2.0 } else { 0.0 };
        let pts: Vec<(i32, i32)> = (0..sides)
            .map(|i| {
                let deg = i as f64 * (360.0 / sides as f64);
                (cx + (((rot + deg) * PI180).sin() * ex) as i32, cy + (((rot + deg) * PI180).cos() * ey) as i32)
            })
            .collect();
        Some(self.new_polygon_sector(&pts))
    }

    /// `AddNewSector`, star: a five-pointed star inscribed in `r`. (The inner
    /// radius is one fifth of the full width/height, as in the original.)
    pub fn add_star_sector(&mut self, r: &Rect) -> usize {
        let (cx, cy) = (r.left + (r.right - r.left) / 2, r.bottom + (r.top - r.bottom) / 2);
        let (ex, ey) = ((r.right - r.left) as f64 / 2.0, (r.top - r.bottom) as f64 / 2.0);
        let (ix, iy) = ((r.right - r.left) as f64 / 5.0, (r.top - r.bottom) as f64 / 5.0);
        let mut pts = Vec::with_capacity(10);
        for i in 0..5 {
            let deg = i as f64 * 72.0;
            pts.push((cx + ((deg * PI180).sin() * ex) as i32, cy + ((deg * PI180).cos() * ey) as i32));
            let deg = deg + 36.0;
            pts.push((cx + ((deg * PI180).sin() * ix) as i32, cy + ((deg * PI180).cos() * iy) as i32));
        }
        self.new_polygon_sector(&pts)
    }

    /// `DoSteps`: a flight of `num_steps` rectangular sectors filling `r`,
    /// each `step_height` higher than the last, risers textured with the
    /// runner texture, then welded with [`MapData::process_joins`]. The new
    /// sectors end up selected.
    pub fn add_steps(&mut self, r: &Rect, p: &StepsParams) -> Result<(), StepsError> {
        if p.num_steps == 0 {
            return Err(StepsError::NoSteps);
        }
        self.normalize_flags();
        self.unselect_all(Kind::Sector);
        let (size_x, size_y) = (r.right - r.left, r.top - r.bottom);
        let n = p.num_steps as i32;
        let each = match p.direction {
            Direction::East | Direction::West => size_x / n,
            Direction::North | Direction::South => size_y / n,
        };
        let ceil_start = self.defaults.top as i32;
        let (mut cur_height, step_height) = (p.low_height as i32, p.step_height as i32);
        let mut cur = match p.direction {
            Direction::East => r.left,
            Direction::North => r.bottom,
            Direction::West => r.right,
            Direction::South => r.top,
        };
        let (mut stitchx1, mut stitchx2) = (0i32, 0i32);
        let runner = to_name8(&p.runner_texture);

        for _ in 0..p.num_steps {
            let sec = self.sector_new();
            self.sectors[sec].floor_z = cur_height as i16;
            let ceil_z = ceil_start.max(cur_height + 80 + step_height);
            self.sectors[sec].ceil_z = ceil_z as i16;
            let (mut vtx, mut lin) = ([0usize; 4], [0usize; 4]);
            for j in 0..4 {
                vtx[j] = self.vertex_new().expect("vertex space");
                lin[j] = self.linedef_sidedef_new();
                self.vertex_flags[vtx[j]].moving = true;
                self.linedef_flags[lin[j]].moving = true;
                let sd = self.linedefs[lin[j]].sidedef1 as usize;
                self.sidedefs[sd].sector = sec as i16;
            }
            let pts = match p.direction {
                Direction::East => [(cur, r.top), (cur + each, r.top), (cur + each, r.bottom), (cur, r.bottom)],
                Direction::North => [(r.left, cur), (r.left, cur + each), (r.right, cur + each), (r.right, cur)],
                Direction::West => [(cur, r.bottom), (cur - each, r.bottom), (cur - each, r.top), (cur, r.top)],
                Direction::South => [(r.left, cur - each), (r.left, cur), (r.right, cur), (r.right, cur - each)],
            };
            for j in 0..4 {
                self.vertexes[vtx[j]] = Vertex { x: pts[j].0 as i16, y: pts[j].1 as i16 };
                self.linedefs[lin[j]].from = vtx[j] as i16;
                self.linedefs[lin[j]].to = vtx[(j + 1) % 4] as i16;
            }
            let side = |m: &Self, l: usize| m.linedefs[lin[l]].sidedef1 as usize;
            // the riser faces the next step up
            let (riser, s0, s2) = match p.direction {
                Direction::South => (3, stitchx2, stitchx1),
                _ => (1, stitchx1, stitchx2),
            };
            let sd = side(self, riser);
            self.sidedefs[sd].t2 = copy_wall(&runner);
            // stitch the textures so they line up from step to step
            let stitchy = (ceil_start - ceil_z) as i16;
            let sd = side(self, 0);
            self.sidedefs[sd].x = s0 as i16;
            self.sidedefs[sd].y = stitchy;
            let sd = side(self, 2);
            self.sidedefs[sd].x = s2 as i16;
            self.sidedefs[sd].y = stitchy;

            cur_height += step_height;
            match p.direction {
                Direction::East => {
                    cur += each;
                    stitchx1 += each;
                    stitchx2 -= each;
                }
                Direction::North => {
                    cur += each;
                    stitchx1 += each;
                    stitchx2 -= each;
                }
                Direction::West => {
                    cur -= each;
                    stitchx1 -= each;
                    stitchx2 += each;
                }
                Direction::South => {
                    cur -= each;
                    stitchx1 += each;
                    stitchx2 -= each;
                }
            }
            self.select(Kind::Sector, sec);
        }
        self.process_joins();
        Ok(())
    }
}
