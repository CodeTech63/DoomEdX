//! The 3D preview (`3D.CPP` wireframe, `H3D.CPP` hidden-line), without any
//! drawing: the camera, the mouse gestures, wall-panel extraction and the
//! projection/sorting. A front end only has to draw the polygons it returns.
//!
//! The original is a one-sided/two-sided *panel* viewer: every solid line is
//! one rectangle floor-to-ceiling; every two-sided line gets a rectangle
//! wherever its two sectors' floors (or ceilings) differ. "Hidden" mode sorts
//! the rectangles far-to-near and paints each one filled with the background
//! before outlining it (the painter's algorithm).
//!
//! Deviation: points behind the viewer are rejected. The original only
//! rejected `z == 0`, so geometry behind you was drawn mirrored.

use crate::map::{is_used, MapData, Rect};
use crate::structs::{line_bits, NOTHING};

const PI180: f64 = 0.017453292;

/// A vertical rectangle: corners `p1` and `p2` in map units; `z` of `p1` is one
/// edge height and `z` of `p2` the other.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Panel {
    pub p1: (i32, i32, i32),
    pub p2: (i32, i32, i32),
}

/// `H3D.CPP`'s `WM_INITDIALOG`: the panels to draw for a map.
pub fn panels(map: &MapData) -> Vec<Panel> {
    let mut out = vec![];
    let sec = |sd: i16| map.side_sector(sd).and_then(|s| map.sectors.get(s));
    for i in 0..map.linedefs.len() {
        if !is_used(&map.linedef_flags, i) {
            continue;
        }
        let l = map.linedefs[i];
        let (Some(a), Some(b)) = (map.vertexes.get(l.from as usize), map.vertexes.get(l.to as usize)) else { continue };
        let (a, b) = ((a.x as i32, a.y as i32), (b.x as i32, b.y as i32));
        if l.sidedef1 == NOTHING {
            continue;
        }
        let two = l.solidity & line_bits::TWO_SIDED != 0;
        if !two {
            if let Some(s) = sec(l.sidedef1) {
                out.push(Panel { p1: (a.0, a.1, s.floor_z as i32), p2: (b.0, b.1, s.ceil_z as i32) });
            }
        } else if l.sidedef2 != NOTHING {
            if let (Some(s1), Some(s2)) = (sec(l.sidedef1), sec(l.sidedef2)) {
                if s1.floor_z != s2.floor_z {
                    out.push(Panel { p1: (a.0, a.1, s1.floor_z as i32), p2: (b.0, b.1, s2.floor_z as i32) });
                }
                if s1.ceil_z != s2.ceil_z {
                    out.push(Panel { p1: (a.0, a.1, s1.ceil_z as i32), p2: (b.0, b.1, s2.ceil_z as i32) });
                }
            }
        }
    }
    out
}

/// Viewer (`v*`), look-toward point (`o*`) and zoom. As in the original,
/// `vz` is stored negated relative to the height shown in the setup dialog.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Camera {
    pub vx: i32,
    pub vy: i32,
    pub vz: i32,
    pub ox: i32,
    pub oy: i32,
    pub oz: i32,
    pub zoom: i32,
}

impl Default for Camera {
    fn default() -> Self {
        Camera { vx: 1000, vy: 1000, vz: -200, ox: 0, oy: 0, oz: 0, zoom: 5 }
    }
}

type Mat = [[f32; 4]; 4];

fn ident() -> Mat {
    let mut m = [[0.0; 4]; 4];
    for (i, r) in m.iter_mut().enumerate() {
        r[i] = 1.0;
    }
    m
}

fn mult(a: &Mat, b: &Mat) -> Mat {
    let mut x = [[0.0; 4]; 4];
    for i in 0..4 {
        for j in 0..4 {
            x[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j] + a[i][3] * b[3][j];
        }
    }
    x
}

impl Camera {
    /// The dialog's opening state: look at the middle of the map.
    pub fn for_extent(e: Option<Rect>) -> Self {
        let mut c = Camera::default();
        if let Some(e) = e {
            c.ox = (e.right - e.left) / 2 + e.left;
            c.oy = (e.top - e.bottom) / 2 + e.bottom;
        }
        c.oz = 0;
        if let Some(e) = e {
            // The original always opened at (1000, 1000, 200) and let the
            // user fix it in the setup dialog; that lands inside most maps.
            // Start outside the map instead, looking at its centre.
            let span = ((e.right - e.left).max(e.top - e.bottom)).max(256);
            c.vx = c.ox + span;
            c.vy = c.oy - span;
            c.vz = -(span / 2);
        }
        c
    }

    /// `SetViewMatrix`.
    pub fn matrix(&self) -> [[f32; 4]; 4] {
        let (fx, fy, fz) = ((self.vx - self.ox) as f32, (self.vy - self.oy) as f32, (self.vz - self.oz) as f32);
        let mut mat = ident();
        mat[3][0] = -self.vx as f32;
        mat[3][1] = -self.vy as f32;
        mat[3][2] = -self.vz as f32;
        let mut t = ident();
        t[1][1] = 0.0;
        t[2][2] = 0.0;
        t[2][1] = 1.0;
        t[1][2] = -1.0;
        mat = mult(&mat, &t);
        let d1 = (fx * fx + fy * fy).sqrt();
        if d1.abs() > 0.0001 {
            let mut t = ident();
            t[0][0] = -fy / d1;
            t[2][2] = -fy / d1;
            t[0][2] = fx / d1;
            t[2][0] = -fx / d1;
            mat = mult(&mat, &t);
        }
        let d2 = (fx * fx + fy * fy + fz * fz).sqrt();
        if d2.abs() > 0.0001 {
            let mut t = ident();
            t[1][1] = d1 / d2;
            t[2][2] = d1 / d2;
            t[1][2] = fz / d2;
            t[2][1] = -fz / d2;
            mat = mult(&mat, &t);
        }
        let mut t = ident();
        t[2][2] = -1.0;
        t[0][0] = self.zoom as f32;
        t[1][1] = self.zoom as f32;
        mult(&mat, &t)
    }

    // ---- mouse gestures (dx, dy are pixel deltas since the last event) ----

    /// Both buttons, horizontal: move toward/away from the look-toward point.
    pub fn dolly(&mut self, dx: i32) {
        if dx != 0 {
            let (ddx, ddy) = ((self.vx - self.ox) as f64, (self.vy - self.oy) as f64);
            let ang = ddy.atan2(ddx);
            let dist = ddx.hypot(ddy) - dx as f64 * 10.0;
            self.vx = self.ox + (ang.cos() * dist) as i32;
            self.vy = self.oy + (ang.sin() * dist) as i32;
        }
    }

    /// Scroll wheel: move the viewer toward (`steps > 0`) or away from
    /// (`steps < 0`) the look-toward point by 15% of the current distance per
    /// step, never closer than 16 units. Height is unchanged. (Not in the
    /// original.)
    pub fn wheel(&mut self, steps: i32) {
        let (ddx, ddy) = ((self.vx - self.ox) as f64, (self.vy - self.oy) as f64);
        let dist = ddx.hypot(ddy);
        if dist < 1.0 {
            return;
        }
        let ang = ddy.atan2(ddx);
        let dist = (dist * 0.85f64.powi(steps)).clamp(16.0, 60000.0);
        self.vx = self.ox + (ang.cos() * dist).round() as i32;
        self.vy = self.oy + (ang.sin() * dist).round() as i32;
    }

    /// Left button: x orbits the viewer around the look-toward point, y raises
    /// or lowers the viewer.
    pub fn orbit(&mut self, dx: i32, dy: i32) {
        if dx != 0 {
            let (ddx, ddy) = ((self.vx - self.ox) as f64, (self.vy - self.oy) as f64);
            let mut deg = ddy.atan2(ddx) / PI180;
            let dist = ddx.hypot(ddy);
            deg -= dx as f64 / 2.0;
            let rad = deg * PI180;
            self.vx = self.ox + (rad.cos() * dist) as i32;
            self.vy = self.oy + (rad.sin() * dist) as i32;
        }
        if dy != 0 {
            self.vz += dy * 10;
        }
    }

    /// Right button: x turns the look-toward point around the viewer, y raises
    /// or lowers the look-toward point.
    pub fn turn(&mut self, dx: i32, dy: i32) {
        if dx != 0 {
            let (ddx, ddy) = ((self.ox - self.vx) as f64, (self.oy - self.vy) as f64);
            let mut deg = ddy.atan2(ddx) / PI180;
            let dist = ddx.hypot(ddy);
            deg -= dx as f64 / 2.0;
            let rad = deg * PI180;
            self.ox = self.vx + (rad.cos() * dist) as i32;
            self.oy = self.vy + (rad.sin() * dist) as i32;
        }
        if dy != 0 {
            self.oz += dy * 10;
        }
    }
}

/// A panel ready to draw: four screen corners in drawing order
/// (`s1..s4`, a closed outline) and its distance from the viewer.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Projected {
    pub s: [(i32, i32); 4],
    pub distance: i32,
}

/// `Draw3dMap`'s projection step for a display of `w` x `h` pixels. In hidden
/// mode the result is sorted far-to-near (draw in order).
pub fn project(panels: &[Panel], cam: &Camera, w: i32, h: i32, hidden: bool) -> Vec<Projected> {
    let m = cam.matrix();
    let (cx, cy) = (w / 2, h / 2);
    let aspect = h as f32 / w.max(1) as f32;
    let tr = |x: i32, y: i32, z: i32| -> Option<(i32, i32)> {
        let (x, y, z) = (x as f32, y as f32, -(z as f32));
        let ex = m[0][0] * x + m[1][0] * y + m[2][0] * z + m[3][0];
        let ey = m[0][1] * x + m[1][1] * y + m[2][1] * z + m[3][1];
        let ez = m[0][2] * x + m[1][2] * y + m[2][2] * z + m[3][2];
        if ez <= 0.0 {
            return None; // behind (or on) the eye plane
        }
        let sx = (aspect * cx as f32 * (ex / ez)) as i32 + cx;
        let sy = (cy as f32 * (ey / ez)) as i32 + cy;
        if sx.abs() > (w * 2).abs() || sy.abs() > (h * 2).abs() {
            return None;
        }
        Some((sx, sy))
    };
    let (vx, vy, vz) = (cam.vx as f64, cam.vy as f64, cam.vz as f64);
    let mut out: Vec<Projected> = panels
        .iter()
        .filter_map(|p| {
            let s = [
                tr(p.p1.0, p.p1.1, p.p1.2)?,
                tr(p.p1.0, p.p1.1, p.p2.2)?,
                tr(p.p2.0, p.p2.1, p.p2.2)?,
                tr(p.p2.0, p.p2.1, p.p1.2)?,
            ];
            // `PreCalc`: distance to the rectangle's centre. The original
            // compares against the un-negated heights; so do we.
            let distance = if hidden {
                let tx = vx - ((p.p2.0 + p.p1.0) / 2) as f64;
                let ty = vy - ((p.p2.1 + p.p1.1) / 2) as f64;
                let tz = vz - ((p.p2.2 + p.p1.2) / 2) as f64;
                (tx * tx + ty * ty + tz * tz).sqrt() as i32
            } else {
                50
            };
            (distance > 20).then_some(Projected { s, distance })
        })
        .collect();
    if hidden {
        out.sort_by(|a, b| b.distance.cmp(&a.distance)); // stable, far first
    }
    out
}
