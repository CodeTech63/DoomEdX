//! Undo / redo by whole-map snapshots (an addition to the original, which had
//! no undo).
//!
//! The editor calls [`UndoStack::commit_if_changed`] whenever it is idle (no
//! mouse button down, no text being typed). A whole drag, a typed value or a
//! multi-step operation therefore becomes a single undo step: the snapshot of
//! the map as it was at the previous idle moment.

use std::collections::VecDeque;

use crate::map::{is_used, Flags, MapData};

impl MapData {
    /// True if the editable content (items, tags, deletions) is identical.
    /// Selection, the edited flag and the built node data are ignored.
    pub fn same_content(&self, o: &MapData) -> bool {
        fn used_same(a: &[Flags], b: &[Flags]) -> bool {
            (0..a.len().max(b.len())).all(|i| is_used(a, i) == is_used(b, i))
        }
        self.things == o.things
            && self.vertexes == o.vertexes
            && self.linedefs == o.linedefs
            && self.sidedefs == o.sidedefs
            && self.sectors == o.sectors
            && self.tags == o.tags
            && self.next_tag == o.next_tag
            && used_same(&self.thing_flags, &o.thing_flags)
            && used_same(&self.vertex_flags, &o.vertex_flags)
            && used_same(&self.linedef_flags, &o.linedef_flags)
            && used_same(&self.sidedef_flags, &o.sidedef_flags)
            && used_same(&self.sector_flags, &o.sector_flags)
    }

    /// Replace the editable content with that of `snap`. The selection is
    /// cleared and the nodes are marked for rebuilding.
    pub fn restore_content(&mut self, snap: &MapData) {
        self.things = snap.things.clone();
        self.vertexes = snap.vertexes.clone();
        self.linedefs = snap.linedefs.clone();
        self.sidedefs = snap.sidedefs.clone();
        self.sectors = snap.sectors.clone();
        self.tags = snap.tags.clone();
        self.next_tag = snap.next_tag;
        self.segs = snap.segs.clone();
        self.ssectors = snap.ssectors.clone();
        self.nodes = snap.nodes.clone();
        self.reject = snap.reject.clone();
        self.blockmap = snap.blockmap.clone();
        let clean = |f: &[Flags]| f.iter().map(|x| Flags { used: x.used, selected: false, moving: false }).collect::<Vec<_>>();
        self.thing_flags = clean(&snap.thing_flags);
        self.vertex_flags = clean(&snap.vertex_flags);
        self.linedef_flags = clean(&snap.linedef_flags);
        self.sidedef_flags = clean(&snap.sidedef_flags);
        self.sector_flags = clean(&snap.sector_flags);
        self.normalize_flags();
        self.mark_nodes_dirty();
    }
}

pub struct UndoStack {
    undo: VecDeque<MapData>,
    redo: Vec<MapData>,
    /// the map as of the last idle moment
    committed: Option<MapData>,
    limit: usize,
}

impl UndoStack {
    pub fn new(limit: usize) -> Self {
        UndoStack { undo: VecDeque::new(), redo: Vec::new(), committed: None, limit: limit.max(1) }
    }

    /// Start afresh from `map` (a new or newly loaded map).
    pub fn reset(&mut self, map: &MapData) {
        self.undo.clear();
        self.redo.clear();
        self.committed = Some(map.clone());
    }

    /// Adopt `map` as the current state without making an undo step, for
    /// changes that only renumber (packing deleted items away).
    pub fn rebase(&mut self, map: &MapData) {
        self.committed = Some(map.clone());
    }

    /// If the content differs from the last committed state, record that
    /// state as an undo step. Returns whether a step was recorded.
    pub fn commit_if_changed(&mut self, map: &MapData) -> bool {
        match &self.committed {
            None => {
                self.committed = Some(map.clone());
                false
            }
            Some(c) if c.same_content(map) => false,
            Some(_) => {
                let prev = self.committed.replace(map.clone()).unwrap();
                self.undo.push_back(prev);
                while self.undo.len() > self.limit {
                    self.undo.pop_front();
                }
                self.redo.clear();
                true
            }
        }
    }

    pub fn undo(&mut self, map: &mut MapData) -> bool {
        self.commit_if_changed(map);
        let Some(prev) = self.undo.pop_back() else { return false };
        if let Some(cur) = self.committed.take() {
            self.redo.push(cur);
        }
        map.restore_content(&prev);
        self.committed = Some(prev);
        true
    }

    pub fn redo(&mut self, map: &mut MapData) -> bool {
        self.commit_if_changed(map);
        let Some(next) = self.redo.pop() else { return false };
        if let Some(cur) = self.committed.take() {
            self.undo.push_back(cur);
        }
        map.restore_content(&next);
        self.committed = Some(next);
        true
    }

    pub fn undo_len(&self) -> usize {
        self.undo.len()
    }
    pub fn redo_len(&self) -> usize {
        self.redo.len()
    }
}
