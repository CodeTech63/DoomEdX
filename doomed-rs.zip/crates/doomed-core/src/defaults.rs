//! Templates for newly created items (`DefThing`, `DefSideDef`, `DefLineDef`,
//! `DefSector` and the `DefaultSector*` settings, from `INIT.CPP`/`GLOBALS.CPP`).

use crate::structs::*;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Defaults {
    pub thing: Thing,
    pub sidedef: SideDef,
    pub linedef: LineDef,
    pub sector: Sector,
    /// `DefaultSectorWall`
    pub wall: [u8; 8],
    /// `DefaultSectorFloor` / `DefaultSectorCeil`
    pub floor: [u8; 8],
    pub ceil: [u8; 8],
    /// `DefaultSectorBottom` / `Top` / `Light`
    pub bottom: i16,
    pub top: i16,
    pub light: i16,
}

impl Defaults {
    /// Builds all four item templates from the six style settings, as `INIT.CPP` does.
    pub fn new(wall: &str, floor: &str, ceil: &str, bottom: i16, top: i16, light: i16) -> Self {
        let (wall, floor, ceil) = (to_name8(wall), to_name8(floor), to_name8(ceil));
        Defaults {
            thing: Thing { x: 0, y: 0, face: 0, item: 0x7f3 /* barrel */, lev: 7 },
            sidedef: SideDef { x: 0, y: 0, t1: null_wall(), t2: null_wall(), t3: copy_wall(&wall), sector: 0 },
            linedef: LineDef {
                from: 0,
                to: 0,
                solidity: line_bits::IMPASSABLE,
                special: 0,
                tag: 0,
                sidedef1: NOTHING,
                sidedef2: NOTHING,
            },
            sector: Sector {
                floor_z: bottom,
                ceil_z: top,
                floor: copy_wall(&floor),
                ceil: copy_wall(&ceil),
                light,
                flash: 0,
                tag: 0,
            },
            wall,
            floor,
            ceil,
            bottom,
            top,
            light,
        }
    }
}

impl Default for Defaults {
    /// The compiled-in defaults of `GLOBALS.CPP`.
    fn default() -> Self {
        Defaults::new("MARBLE1", "FLAT5_2", "CEIL1_1", 0, 128, 200)
    }
}
