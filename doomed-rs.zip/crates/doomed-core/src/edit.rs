//! Delete commands, "make sector a door" and rotate/scale
//! (`EDIT.CPP`, `MakeSectorDoor` in `TOOLS.CPP`).

use crate::map::{is_used, MapData};
use crate::select::Kind;
use crate::structs::*;

const PI180: f64 = 0.017453292;

/// Why [`MapData::make_sector_door`] refused (the original's error boxes).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DoorError {
    /// `IDS_DOORFOURSIDES`: a door sector needs exactly four sides.
    NotFourSides,
    /// `IDS_DOORSANDWICH`: it must sit between two other sectors.
    NotSandwiched,
    /// `IDS_DOORFLOORS`: the two neighbours must have equal floors.
    FloorsDiffer,
}

impl std::fmt::Display for DoorError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            DoorError::NotFourSides => "A door sector must have exactly four sides",
            DoorError::NotSandwiched => "A door sector must lie between two other sectors",
            DoorError::FloorsDiffer => "The sectors on either side of a door must have the same floor height",
        })
    }
}
impl std::error::Error for DoorError {}

impl MapData {
    /// `DoomEdEditDelete` (Shift+Del): removes the selection. For sectors
    /// that includes every line touching them. Vertex tool: does nothing.
    pub fn delete_selected(&mut self, tool: Kind) {
        self.normalize_flags();
        match tool {
            Kind::LineDef => {
                for f in self.linedef_flags.iter_mut().filter(|f| f.used) {
                    f.used = !f.selected;
                }
            }
            Kind::Sector => {
                for i in 0..self.linedefs.len() {
                    if !self.linedef_flags[i].used {
                        continue;
                    }
                    let l = self.linedefs[i];
                    let touches = [l.sidedef1, l.sidedef2]
                        .iter()
                        .any(|&sd| self.side_sector(sd).map_or(false, |s| self.sector_selected(s)));
                    if touches {
                        self.linedef_flags[i].used = false;
                    }
                }
                for f in self.sector_flags.iter_mut().filter(|f| f.used) {
                    f.used = !f.selected;
                }
            }
            Kind::Vertex => return,
            Kind::Thing => {
                for f in self.thing_flags.iter_mut().filter(|f| f.selected) {
                    f.used = false;
                }
            }
        }
        self.unselect_everything();
        // The original forgot to flag the map as changed here.
        self.mark_nodes_dirty();
    }

    /// `DoomEdEditPartDelete` (Del): like delete, but sectors are first
    /// detached so the neighbouring sectors keep their walls.
    pub fn partial_delete_selected(&mut self, tool: Kind) {
        self.normalize_flags();
        match tool {
            Kind::Sector => {
                self.detach_sectors();
                for f in self.vertex_flags.iter_mut().filter(|f| f.used) {
                    f.used = !f.moving;
                }
                for f in self.linedef_flags.iter_mut().filter(|f| f.used) {
                    f.used = !f.moving;
                }
                for f in self.sector_flags.iter_mut().filter(|f| f.used) {
                    f.used = !f.selected;
                }
                self.unselect_everything();
                self.mark_nodes_dirty();
            }
            other => self.delete_selected(other),
        }
    }

    /// `MakeSectorDoor`: turns each selected four-sided sector between two
    /// equal-floor neighbours into a manual door ("DOORTRAK" sides, a door
    /// texture on each face, floor = ceiling = neighbour floor, special 1).
    /// Stops at the first sector that cannot be a door; earlier ones stay done.
    ///
    /// The original skipped DOORTRAK on any sidedef whose *index* equalled a
    /// neighbouring sector's *number* (a comparison of unrelated numbers).
    /// This version excludes the two border sidedefs instead.
    pub fn make_sector_door(&mut self) -> Result<usize, DoorError> {
        self.normalize_flags();
        let mut made = 0;
        for sec in 0..self.sectors.len() {
            if !(self.sector_flags[sec].used && self.sector_flags[sec].selected) {
                continue;
            }
            let sides = (0..self.sidedefs.len())
                .filter(|&i| self.sidedef_flags[i].used && self.sidedefs[i].sector as i32 == sec as i32)
                .count();
            if sides != 4 {
                return Err(DoorError::NotFourSides);
            }
            // the two lines bordering other sectors, and the sectors beyond
            let (mut s1, mut s2): (Option<usize>, Option<usize>) = (None, None);
            let (mut l1, mut l2): (Option<usize>, Option<usize>) = (None, None);
            for i in 0..self.linedefs.len() {
                if !self.linedef_flags[i].used {
                    continue;
                }
                let l = self.linedefs[i];
                let mut note = |this: Option<usize>, line: usize| {
                    if s1.is_none() {
                        s1 = this;
                        l1 = Some(line);
                    } else {
                        s2 = this;
                        l2 = Some(line);
                    }
                };
                if l.sidedef1 != NOTHING && l.sidedef2 != NOTHING && self.side_sector(l.sidedef1) == Some(sec) {
                    note(self.side_sector(l.sidedef2), i);
                }
                if l.sidedef2 != NOTHING && self.side_sector(l.sidedef2) == Some(sec) {
                    note(self.side_sector(l.sidedef1), i);
                }
            }
            let (Some(s1), Some(s2), Some(l1), Some(l2)) = (s1, s2, l1, l2) else {
                return Err(DoorError::NotSandwiched);
            };
            if s1 >= self.sectors.len() || s2 >= self.sectors.len() {
                return Err(DoorError::NotSandwiched);
            }
            if self.sectors[s1].floor_z != self.sectors[s2].floor_z {
                return Err(DoorError::FloorsDiffer);
            }
            let length = |m: &Self, l: usize| -> i32 {
                let (a, b) = (m.linedefs[l].from as usize, m.linedefs[l].to as usize);
                let dx = (m.vertexes[b].x as i32 - m.vertexes[a].x as i32).abs() as f64;
                let dy = (m.vertexes[b].y as i32 - m.vertexes[a].y as i32).abs() as f64;
                (dx * dx + dy * dy).sqrt() as i32
            };
            let tex = |len: i32| to_name8(if len < 65 { "DOOR3" } else { "BIGDOOR2" });
            let (door1, door2) = (tex(length(self, l1)), tex(length(self, l2)));

            // the track: every other side of this sector
            let border: Vec<i16> = [l1, l2].iter().flat_map(|&l| [self.linedefs[l].sidedef1, self.linedefs[l].sidedef2]).collect();
            for i in 0..self.sidedefs.len() {
                if self.sidedefs[i].sector as i32 == sec as i32 && !border.contains(&(i as i16)) {
                    self.sidedefs[i].t1 = null_wall();
                    self.sidedefs[i].t2 = null_wall();
                    self.sidedefs[i].t3 = to_name8("DOORTRAK");
                    if let Some(j) = (0..self.linedefs.len())
                        .find(|&j| self.linedef_flags[j].used && self.linedefs[j].sidedef1 == i as i16)
                    {
                        self.linedefs[j].set_bit(line_bits::LOWER_UNPEGGED);
                    }
                }
            }
            let floor = self.sectors[s1].floor_z;
            self.sectors[sec].ceil_z = floor;
            self.sectors[sec].floor_z = floor;

            // make each border line's first side the outside one (it carries the door texture)
            for l in [l1, l2] {
                let ln = self.linedefs[l];
                if ln.sidedef1 != NOTHING && self.side_sector(ln.sidedef1) == Some(sec) {
                    let ln = &mut self.linedefs[l];
                    std::mem::swap(&mut ln.sidedef1, &mut ln.sidedef2);
                    std::mem::swap(&mut ln.from, &mut ln.to);
                }
            }
            for (l, door) in [(l1, door1), (l2, door2)] {
                let ln = self.linedefs[l];
                let (a, b) = (ln.sidedef1 as usize, ln.sidedef2 as usize);
                self.sidedefs[a].t1 = door;
                self.sidedefs[a].t2 = null_wall();
                self.sidedefs[a].t3 = null_wall();
                self.sidedefs[a].x = 0;
                self.sidedefs[a].y = 0;
                self.sidedefs[b].t1 = null_wall();
                self.sidedefs[b].t2 = null_wall();
                self.sidedefs[b].t3 = null_wall();
                let ln = &mut self.linedefs[l];
                ln.solidity = line_bits::TWO_SIDED; // transparent
                ln.special = 1; // manual door raise
                ln.tag = 0;
            }
            self.sectors[sec].ceil = to_name8("FLAT20");
            made += 1;
        }
        if made > 0 {
            self.mark_nodes_dirty();
        }
        Ok(made)
    }

    /// Centre of the bounding box of the selected sectors (`SectorRotateScale`).
    pub fn selection_center(&self) -> Option<(i32, i32)> {
        let ext = self.sector_extents();
        let mut r: Option<crate::map::Rect> = None;
        for (i, e) in ext.iter().enumerate() {
            if is_used(&self.sector_flags, i) && self.sector_selected(i) {
                if let Some(e) = e {
                    r = Some(match r {
                        None => *e,
                        Some(r) => crate::map::Rect {
                            left: r.left.min(e.left),
                            right: r.right.max(e.right),
                            top: r.top.max(e.top),
                            bottom: r.bottom.min(e.bottom),
                        },
                    });
                }
            }
        }
        r.map(|r| (r.left + (r.right - r.left) / 2, r.bottom + (r.top - r.bottom) / 2))
    }

    /// `SectorRotateScale` (the dialog's OK): detaches the selected sectors,
    /// scales (percent, 100 = unchanged) then rotates (degrees, positive =
    /// clockwise) their vertexes about the selection's centre, and re-welds.
    /// Returns `false` when no sector is selected.
    pub fn rotate_scale_selected(&mut self, xscale: i32, yscale: i32, degrees: i32) -> bool {
        self.normalize_flags();
        let Some((cx, cy)) = self.selection_center() else { return false };
        if xscale == 100 && yscale == 100 && degrees == 0 {
            return true;
        }
        self.detach_sectors();
        for i in 0..self.vertexes.len() {
            if !(self.vertex_flags[i].used && self.vertex_flags[i].moving) {
                continue;
            }
            let v = &mut self.vertexes[i];
            if xscale != 100 {
                let x = (v.x as i32 - cx) as f64 * xscale as f64 / 100.0;
                v.x = (cx + x as i32) as i16;
            }
            if yscale != 100 {
                let y = (v.y as i32 - cy) as f64 * yscale as f64 / 100.0;
                v.y = (cy + y as i32) as i16;
            }
            if degrees != 0 {
                let (x, y) = ((v.x as i32 - cx) as f64, (v.y as i32 - cy) as f64);
                let dist = x.hypot(y);
                let ang = (y.atan2(x) / PI180 - degrees as f64) * PI180;
                v.x = (cx + (ang.cos() * dist) as i32) as i16;
                v.y = (cy + (ang.sin() * dist) as i32) as i16;
            }
        }
        self.process_joins();
        true
    }
}
