//! Internal reject builder (`REJECT.CPP`): everything starts "rejected" (all
//! bits set), then sector pairs closer than `THRESHOLD` are made visible.

use crate::map::{is_used, MapData};
use crate::quirks::Quirks;
use crate::structs::*;

/// Sectors/vertices closer than this (in `idist` units) are not rejected.
pub const THRESHOLD: i32 = 600;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RejectMethod {
    /// Compare sector centers (`REJECT_QUICK`).
    Quick,
    /// Compare every pair of linedef endpoints (`REJECT_FULL`, "thorough").
    Full,
}

/// Fast approximate distance: `|dx| + |dy| - min(|dx|, |dy|) / 2`.
pub fn idist(a: (i32, i32), b: (i32, i32)) -> i32 {
    let (dx, dy) = ((b.0 - a.0).abs(), (b.1 - a.1).abs());
    dx + dy - (dx.min(dy) >> 1)
}

impl MapData {
    /// `BuildReject`.
    ///
    /// Bits are indexed `from * sectors + to`. Sector pairs that touch bits
    /// beyond the (possibly too short, see [`Quirks::reject_size_floor`]) lump
    /// are ignored.
    pub fn build_reject(&mut self, method: RejectMethod, q: &Quirks) {
        self.normalize_flags();
        let n = self.sectors.len();
        let bits = n * n;
        let size = if q.reject_size_floor { bits / 8 } else { bits.div_ceil(8) };
        let mut reject = vec![0xff; size];

        let mut reset = |from: usize, to: usize| {
            let bit = from * n + to;
            if let Some(b) = reject.get_mut(bit / 8) {
                *b &= !(1 << (bit % 8));
            }
        };

        match method {
            RejectMethod::Quick => {
                let extents = self.sector_extents();
                // A sector no line touches has the untouched extent, whose
                // "center" works out to the origin.
                let center = |i: usize| match extents[i] {
                    Some(r) => (r.left + (r.right - r.left) / 2, r.bottom + (r.top - r.bottom) / 2),
                    None => (0, 0),
                };
                for i in 0..n {
                    if !is_used(&self.sector_flags, i) {
                        continue;
                    }
                    let c1 = center(i);
                    for j in 0..n {
                        if is_used(&self.sector_flags, j) && idist(c1, center(j)) <= THRESHOLD {
                            reset(j, i);
                        }
                    }
                }
            }
            RejectMethod::Full => {
                // (sector, endpoints) for every side of every in-use linedef
                struct Side {
                    sector: usize,
                    a: (i32, i32),
                    b: (i32, i32),
                }
                let mut sides = Vec::new();
                for (i, l) in self.linedefs.iter().enumerate() {
                    if !is_used(&self.linedef_flags, i) {
                        continue;
                    }
                    let (Some(a), Some(b)) = (
                        self.vertexes.get(l.from as usize),
                        self.vertexes.get(l.to as usize),
                    ) else {
                        continue;
                    };
                    for sd in [l.sidedef1, l.sidedef2] {
                        if sd == NOTHING {
                            continue;
                        }
                        if let Some(sec) = self.sidedefs.get(sd as usize).and_then(|s| usize::try_from(s.sector).ok()) {
                            sides.push(Side { sector: sec, a: (a.x as i32, a.y as i32), b: (b.x as i32, b.y as i32) });
                        }
                    }
                }
                for s1 in &sides {
                    for s2 in &sides {
                        let near = [(s1.a, s2.a), (s1.a, s2.b), (s1.b, s2.a), (s1.b, s2.b)]
                            .iter()
                            .any(|&(p, q)| idist(p, q) <= THRESHOLD);
                        if near && s1.sector < n && s2.sector < n {
                            reset(s1.sector, s2.sector);
                        }
                    }
                }
            }
        }
        self.reject = reject;
    }
}
