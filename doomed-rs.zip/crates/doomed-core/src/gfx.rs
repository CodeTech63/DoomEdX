//! Doom graphics: PLAYPAL, patches (picture format), flats, and composite
//! textures (`TEXTURE1/2` + `PNAMES`). The original's `DIB.CPP`, `BITMAPS.CPP`
//! and `TEXTURES.CPP` did this for Windows DIBs; here it produces RGBA.

use crate::wad::Wad;
use std::collections::HashMap;

/// A decoded picture. `rgba` is `width * height * 4`, row-major from the top;
/// transparent pixels have alpha 0.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Image {
    pub width: usize,
    pub height: usize,
    pub rgba: Vec<u8>,
}

impl Image {
    pub fn blank(width: usize, height: usize) -> Self {
        Image { width, height, rgba: vec![0; width * height * 4] }
    }
}

#[derive(Debug, Clone)]
pub struct TexturePatch {
    pub origin_x: i16,
    pub origin_y: i16,
    pub patch: i16,
}

#[derive(Debug, Clone)]
pub struct TextureDef {
    pub name: String,
    pub width: i16,
    pub height: i16,
    pub patches: Vec<TexturePatch>,
}

fn i16_at(b: &[u8], o: usize) -> Option<i16> {
    b.get(o..o + 2).map(|x| i16::from_le_bytes([x[0], x[1]]))
}
fn i32_at(b: &[u8], o: usize) -> Option<i32> {
    b.get(o..o + 4).map(|x| i32::from_le_bytes([x[0], x[1], x[2], x[3]]))
}
fn lump_name(raw: &[u8]) -> String {
    let end = raw.iter().position(|&c| c == 0).unwrap_or(raw.len());
    raw[..end].iter().map(|&c| (c as char).to_ascii_uppercase()).collect()
}

/// Parses a `TEXTURE1`/`TEXTURE2` lump (malformed entries are skipped).
pub fn parse_texture_defs(data: &[u8]) -> Vec<TextureDef> {
    let Some(count) = i32_at(data, 0).filter(|&c| c >= 0) else { return vec![] };
    let mut out = vec![];
    for i in 0..count as usize {
        let Some(off) = i32_at(data, 4 + i * 4).filter(|&o| o >= 0).map(|o| o as usize) else { break };
        let (Some(name), Some(w), Some(h), Some(pc)) =
            (data.get(off..off + 8), i16_at(data, off + 12), i16_at(data, off + 14), i16_at(data, off + 20))
        else {
            continue;
        };
        let mut patches = vec![];
        for p in 0..pc.max(0) as usize {
            let po = off + 22 + p * 10;
            let (Some(x), Some(y), Some(n)) = (i16_at(data, po), i16_at(data, po + 2), i16_at(data, po + 4)) else { break };
            patches.push(TexturePatch { origin_x: x, origin_y: y, patch: n });
        }
        out.push(TextureDef { name: lump_name(name), width: w, height: h, patches });
    }
    out
}

pub fn parse_pnames(data: &[u8]) -> Vec<String> {
    let Some(n) = i32_at(data, 0).filter(|&c| c >= 0) else { return vec![] };
    (0..n as usize).filter_map(|i| data.get(4 + i * 8..12 + i * 8).map(lump_name)).collect()
}

/// Everything needed to draw textures and flats from one or more WADs
/// (later WADs override earlier ones, like a PWAD over an IWAD).
#[derive(Debug, Clone, Default)]
pub struct GfxAssets {
    pub palette: Option<Vec<[u8; 3]>>,
    lumps: HashMap<String, Vec<u8>>,
    pub pnames: Vec<String>,
    pub textures: Vec<TextureDef>,
    pub flats: Vec<String>,
}

impl GfxAssets {
    pub fn from_wads(wads: &[&Wad]) -> Self {
        let mut g = GfxAssets::default();
        for w in wads {
            g.add_wad(w);
        }
        g
    }

    pub fn add_wad(&mut self, wad: &Wad) {
        let mut in_flats = false;
        for e in &wad.entries {
            let t = e.title.to_ascii_uppercase();
            match t.as_str() {
                "F_START" | "FF_START" => {
                    in_flats = true;
                    continue;
                }
                "F_END" | "FF_END" => {
                    in_flats = false;
                    continue;
                }
                "PLAYPAL" if e.data.len() >= 768 => {
                    self.palette = Some(e.data[..768].chunks(3).map(|c| [c[0], c[1], c[2]]).collect());
                }
                "PNAMES" => self.pnames = parse_pnames(&e.data),
                "TEXTURE1" | "TEXTURE2" => {
                    for d in parse_texture_defs(&e.data) {
                        match self.textures.iter().position(|x| x.name == d.name) {
                            Some(i) => self.textures[i] = d,
                            None => self.textures.push(d),
                        }
                    }
                }
                _ => {}
            }
            if in_flats && e.data.len() == 4096 && !self.flats.contains(&t) {
                self.flats.push(t.clone());
            }
            self.lumps.insert(t, e.data.clone());
        }
    }

    pub fn texture_names(&self) -> impl Iterator<Item = &str> {
        self.textures.iter().map(|t| t.name.as_str())
    }

    fn color(&self, idx: u8) -> [u8; 3] {
        self.palette.as_ref().and_then(|p| p.get(idx as usize).copied()).unwrap_or([idx, idx, idx])
    }

    /// A 64x64 flat.
    pub fn flat_image(&self, name: &str) -> Option<Image> {
        let d = self.lumps.get(&name.to_ascii_uppercase())?;
        if d.len() != 4096 {
            return None;
        }
        let mut img = Image::blank(64, 64);
        for (i, &px) in d.iter().enumerate() {
            let c = self.color(px);
            img.rgba[i * 4..i * 4 + 4].copy_from_slice(&[c[0], c[1], c[2], 255]);
        }
        Some(img)
    }

    /// A patch in Doom picture format.
    pub fn patch_image(&self, name: &str) -> Option<Image> {
        decode_picture(self.lumps.get(&name.to_ascii_uppercase())?, |i| self.color(i))
    }

    /// A sprite with its origin offsets `(image, left, top)`: pixels from the
    /// sprite origin to the left and top edges. If the exact lump does not
    /// exist, a rotated variant of the same frame is used, preferring the
    /// front view (`...A1`, or the second half of a mirrored `...A2A8` pair).
    pub fn sprite_image(&self, name: &str) -> Option<(Image, i16, i16)> {
        let n = name.to_ascii_uppercase();
        let data = match self.lumps.get(&n) {
            Some(d) => d,
            None if n.len() == 6 => {
                let key = |k: &str| -> (u8, String) {
                    let b = k.as_bytes();
                    let rot = |c: u8| match c {
                        b'1' => 0,
                        b'0' => 1,
                        _ => 2,
                    };
                    let r = if b[5] == b'1' || (b.len() >= 8 && b[7] == b'1') { 0 } else { rot(b[5]) };
                    (r, k.to_string())
                };
                let best = self
                    .lumps
                    .keys()
                    .filter(|k| (k.len() == 6 || k.len() == 8) && k.as_bytes()[..5] == n.as_bytes()[..5])
                    .min_by_key(|k| key(k))?;
                &self.lumps[best]
            }
            None => return None,
        };
        let img = decode_picture(data, |i| self.color(i))?;
        Some((img, i16_at(data, 4)?, i16_at(data, 6)?))
    }

    /// A composite texture, patches drawn in order and clipped to its size.
    pub fn texture_image(&self, name: &str) -> Option<Image> {
        let name = name.to_ascii_uppercase();
        let def = self.textures.iter().find(|t| t.name == name)?;
        let (w, h) = (def.width.max(0) as usize, def.height.max(0) as usize);
        if w == 0 || h == 0 || w > 2048 || h > 2048 {
            return None;
        }
        let mut img = Image::blank(w, h);
        for p in &def.patches {
            let Some(pn) = self.pnames.get(p.patch as usize) else { continue };
            let Some(pi) = self.patch_image(pn) else { continue };
            for y in 0..pi.height {
                let dy = y as i32 + p.origin_y as i32;
                if dy < 0 || dy >= h as i32 {
                    continue;
                }
                for x in 0..pi.width {
                    let dx = x as i32 + p.origin_x as i32;
                    if dx < 0 || dx >= w as i32 {
                        continue;
                    }
                    let s = (y * pi.width + x) * 4;
                    if pi.rgba[s + 3] != 0 {
                        let d = (dy as usize * w + dx as usize) * 4;
                        img.rgba[d..d + 4].copy_from_slice(&pi.rgba[s..s + 4]);
                    }
                }
            }
        }
        Some(img)
    }
}

/// Decodes the column/post picture format (`patch_t`).
pub fn decode_picture(d: &[u8], color: impl Fn(u8) -> [u8; 3]) -> Option<Image> {
    let (w, h) = (i16_at(d, 0)?, i16_at(d, 2)?);
    if w <= 0 || h <= 0 || w > 4096 || h > 4096 {
        return None;
    }
    let (w, h) = (w as usize, h as usize);
    let mut img = Image::blank(w, h);
    for col in 0..w {
        let mut p = i32_at(d, 8 + col * 4)? as usize;
        loop {
            let top = *d.get(p)?;
            if top == 0xFF {
                break;
            }
            let len = *d.get(p + 1)? as usize;
            for k in 0..len {
                let px = *d.get(p + 3 + k)?;
                let y = top as usize + k;
                if y < h {
                    let c = color(px);
                    let o = (y * w + col) * 4;
                    img.rgba[o..o + 4].copy_from_slice(&[c[0], c[1], c[2], 255]);
                }
            }
            p += len + 4;
        }
    }
    Some(img)
}
