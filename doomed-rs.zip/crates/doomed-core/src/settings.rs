//! The `.INI` file (`INIT.CPP` reads it, `QUIT.CPP` writes it), styles
//! (`STYLES.CPP`), BSP builder entries (`BUILDERS.CPP`) and the DWD export
//! (`DWD.CPP`).
//!
//! The file keeps the original's section and key names, so an existing
//! DOOMED40.INI loads unchanged. Colours are `COLORREF`s (0x00BBGGRR) written
//! as uppercase hex.

use crate::build::{NodeAction, SaveOptions};
use crate::defaults::Defaults;
use crate::map::{is_used, MapData};
use crate::quirks::Quirks;
use crate::reject::RejectMethod;
use crate::structs::*;
use std::fmt::Write as _;

pub const MAX_STYLE: usize = 32;
pub const MAX_BUILDER: usize = 16;

/// A minimal Windows-style INI: `[Section]` / `Key=Value`, names compared
/// case-insensitively, unknown sections and keys preserved.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Ini {
    sections: Vec<(String, Vec<(String, String)>)>,
}

impl Ini {
    pub fn parse(text: &str) -> Ini {
        let mut ini = Ini::default();
        let mut cur: Option<usize> = None;
        for line in text.lines() {
            let t = line.trim();
            if t.is_empty() || t.starts_with(';') {
                continue;
            }
            if let Some(name) = t.strip_prefix('[').and_then(|r| r.strip_suffix(']')) {
                ini.sections.push((name.to_string(), vec![]));
                cur = Some(ini.sections.len() - 1);
            } else if let (Some(i), Some((k, v))) = (cur, t.split_once('=')) {
                ini.sections[i].1.push((k.trim().to_string(), v.trim().to_string()));
            }
        }
        ini
    }

    pub fn get(&self, section: &str, key: &str) -> Option<&str> {
        self.sections
            .iter()
            .find(|(s, _)| s.eq_ignore_ascii_case(section))?
            .1
            .iter()
            .find(|(k, _)| k.eq_ignore_ascii_case(key))
            .map(|(_, v)| v.as_str())
    }

    pub fn int(&self, section: &str, key: &str, default: i32) -> i32 {
        self.get(section, key).and_then(|v| v.trim().parse().ok()).unwrap_or(default)
    }

    /// `sscanf("%lx")`: hex, no prefix.
    pub fn hex(&self, section: &str, key: &str, default: u32) -> u32 {
        self.get(section, key).and_then(|v| u32::from_str_radix(v.trim(), 16).ok()).unwrap_or(default)
    }

    pub fn string(&self, section: &str, key: &str, default: &str) -> String {
        self.get(section, key).unwrap_or(default).to_string()
    }

    pub fn set(&mut self, section: &str, key: &str, value: impl ToString) {
        let value = value.to_string();
        let si = match self.sections.iter().position(|(s, _)| s.eq_ignore_ascii_case(section)) {
            Some(i) => i,
            None => {
                self.sections.push((section.to_string(), vec![]));
                self.sections.len() - 1
            }
        };
        let keys = &mut self.sections[si].1;
        match keys.iter_mut().find(|(k, _)| k.eq_ignore_ascii_case(key)) {
            Some(kv) => kv.1 = value,
            None => keys.push((key.to_string(), value)),
        }
    }

    pub fn remove_section(&mut self, section: &str) {
        self.sections.retain(|(s, _)| !s.eq_ignore_ascii_case(section));
    }
}

impl std::fmt::Display for Ini {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        for (s, keys) in &self.sections {
            writeln!(f, "[{s}]")?;
            for (k, v) in keys {
                writeln!(f, "{k}={v}")?;
            }
            writeln!(f)?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Colors {
    pub background: u32,
    pub map_lines: u32,
    pub map_inner_lines: u32,
    pub selected: u32,
    pub marked: u32,
    pub grid: u32,
    pub user_grid: u32,
}

impl Default for Colors {
    fn default() -> Self {
        Colors { background: 0, map_lines: 0xFF, map_inner_lines: 0xFFFF, selected: 0xFF00FF, marked: 0xFF00, grid: 0xC0C0C0, user_grid: 0x833FC0 }
    }
}

/// `COLORREF` (0x00BBGGRR) to (r, g, b).
pub fn colorref_rgb(c: u32) -> (u8, u8, u8) {
    ((c & 0xFF) as u8, ((c >> 8) & 0xFF) as u8, ((c >> 16) & 0xFF) as u8)
}

pub fn rgb_colorref(r: u8, g: u8, b: u8) -> u32 {
    r as u32 | (g as u32) << 8 | (b as u32) << 16
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Options {
    pub verify_exit: bool,
    pub show_snap_to_grid: bool,
    pub show_64_grid: bool,
    pub build_nodes_at_every_save: bool,
    pub auto_stitch: bool,
    pub auto_load_most_recent: bool,
    pub verify_after_edit: bool,
    /// `NODE_NONE`=1, `NODE_INTERNAL`=2, `NODE_EXTERNAL`=3, `NODE_IDBSP`=4
    pub node_builder: i32,
    /// `REJECT_QUICK`=1, `REJECT_FULL`=2
    pub reject_builder: i32,
    pub grid_size: i32,
}

impl Default for Options {
    fn default() -> Self {
        Options {
            verify_exit: true,
            show_snap_to_grid: false,
            show_64_grid: true,
            build_nodes_at_every_save: false,
            auto_stitch: true,
            auto_load_most_recent: true,
            verify_after_edit: false,
            node_builder: 2,
            reject_builder: 2,
            grid_size: 16,
        }
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Editors {
    pub graphics: String,
    pub text: String,
    pub ansi: String,
    pub sound: String,
    pub music: String,
}

/// A predefined sector style.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Style {
    pub name: String,
    pub walls: String,
    pub floor: String,
    pub ceiling: String,
}

impl Style {
    pub fn new(name: &str, walls: &str, floor: &str, ceiling: &str) -> Self {
        Style { name: name.into(), walls: walls.into(), floor: floor.into(), ceiling: ceiling.into() }
    }
}

/// An external BSP builder entry (the original only stores these).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Builder {
    pub name: String,
    pub command: String,
    /// 0 = WAD, 1 = DWD
    pub format: i32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Settings {
    pub colors: Colors,
    pub options: Options,
    pub recent_files: [String; 4],
    /// Path of the IWAD to load at startup (not in the original).
    pub iwad: String,
    pub editors: Editors,
    pub styles: Vec<Style>,
    pub builders: Vec<Builder>,
    pub default_wall: String,
    pub default_floor: String,
    pub default_ceil: String,
    pub floor_height: i32,
    pub ceiling_height: i32,
    /// The colour dialog's 16 custom colours (`[Custom Colors] ColorA`..`ColorP`, COLORREF hex).
    pub custom_colors: [u32; 16],
    pub light: i32,
}

pub fn default_styles() -> Vec<Style> {
    vec![
        Style::new("Stone floor, Stone walls", "GRAY1", "FLOOR0_5", "FLAT9"),
        Style::new("Gray floor, Wood walls", "WOOD1", "FLOOR0_5", "CEIL3_6"),
        Style::new("Window frame", "DOORTRAK", "FLAT20", "FLAT20"),
    ]
}

impl Default for Settings {
    fn default() -> Self {
        let styles = default_styles();
        Settings {
            colors: Colors::default(),
            options: Options::default(),
            recent_files: Default::default(),
            iwad: String::new(),
            editors: Editors { graphics: "pbrush".into(), text: "notepad".into(), ansi: String::new(), sound: "soundrec".into(), music: String::new() },
            default_wall: styles[0].walls.clone(),
            default_floor: styles[0].floor.clone(),
            default_ceil: styles[0].ceiling.clone(),
            styles,
            builders: vec![],
            floor_height: 0,
            ceiling_height: 128,
            custom_colors: [0; 16],
            light: 200,
        }
    }
}

fn b(ini: &Ini, key: &str, default: bool) -> bool {
    ini.int("Options", key, default as i32) != 0
}

fn wall8(s: &str) -> String {
    // names are at most 8 characters (`CopyWall`)
    s.chars().take(8).collect()
}

impl Settings {
    /// Reads `INIT.CPP`'s settings from INI text; anything missing gets its default.
    pub fn from_ini(ini: &Ini) -> Settings {
        let d = Colors::default();
        let colors = Colors {
            background: ini.hex("Colors", "Background", d.background),
            map_lines: ini.hex("Colors", "MapLines", d.map_lines),
            map_inner_lines: ini.hex("Colors", "MapInnerLines", d.map_inner_lines),
            selected: ini.hex("Colors", "Selected", d.selected),
            marked: ini.hex("Colors", "Marked", d.marked),
            grid: ini.hex("Colors", "Grid", d.grid),
            user_grid: ini.hex("Colors", "UserGrid", d.user_grid),
        };
        let o = Options::default();
        let options = Options {
            verify_exit: b(ini, "VerifyExit", o.verify_exit),
            show_snap_to_grid: b(ini, "ShowSnapToGrid", o.show_snap_to_grid),
            show_64_grid: b(ini, "Show64x64Grid", o.show_64_grid),
            build_nodes_at_every_save: b(ini, "BuildNodesAtEverySave", o.build_nodes_at_every_save),
            auto_stitch: b(ini, "AutoStitchDuringConstruction", o.auto_stitch),
            auto_load_most_recent: true, // the original forces this on
            verify_after_edit: b(ini, "VerifyAfterEdit", o.verify_after_edit),
            node_builder: ini.int("Options", "NodeBuilder", o.node_builder),
            reject_builder: ini.int("Options", "RejectBuilder", o.reject_builder),
            grid_size: ini.int("Options", "GridSize", o.grid_size).clamp(1, 256),
        };
        let mut recent_files: [String; 4] = Default::default();
        for (i, r) in recent_files.iter_mut().enumerate() {
            *r = ini.string("Files", &format!("RecentFile{}", i + 1), "");
        }
        let iwad = ini.string("Files", "IWAD", "");
        let ed = Settings::default().editors;
        let editors = Editors {
            graphics: ini.string("Editors", "Graphics", &ed.graphics),
            text: ini.string("Editors", "Text", &ed.text),
            ansi: ini.string("Editors", "Ansi", ""),
            sound: ini.string("Editors", "Sound", &ed.sound),
            music: ini.string("Editors", "Music", ""),
        };
        let n = ini.int("Styles", "NumberOfStyles", 0).clamp(0, MAX_STYLE as i32);
        let mut styles: Vec<Style> = (0..n)
            .map(|i| {
                let s = format!("Style{i}");
                Style {
                    name: ini.string(&s, "Name", "null"),
                    floor: wall8(&ini.string(&s, "Floor", "null")),
                    ceiling: wall8(&ini.string(&s, "Ceiling", "null")),
                    walls: wall8(&ini.string(&s, "Walls", "null")),
                }
            })
            .collect();
        if styles.is_empty() {
            styles = default_styles();
        }
        let pick = |key: &str, from: &str| {
            let v = ini.string("DefaultSettings", key, "null");
            if v.starts_with("null") { from.to_string() } else { wall8(&v) }
        };
        let nb = ini.int("Builders", "NumberOfBuilders", 0).clamp(0, MAX_BUILDER as i32);
        let builders = (0..nb)
            .map(|i| {
                let s = format!("Builder{i}");
                Builder { name: ini.string(&s, "Name", "null"), command: ini.string(&s, "Command", "null"), format: ini.int(&s, "Format", 0) }
            })
            .collect();
        Settings {
            colors,
            options,
            recent_files,
            iwad,
            editors,
            default_wall: pick("Walls", &styles[0].walls),
            default_floor: pick("Floor", &styles[0].floor),
            default_ceil: pick("Ceiling", &styles[0].ceiling),
            floor_height: ini.int("DefaultSettings", "FloorHeight", 0),
            ceiling_height: ini.int("DefaultSettings", "CeilingHeight", 128),
            custom_colors: std::array::from_fn(|i| ini.hex("Custom Colors", &format!("Color{}", (b'A' + i as u8) as char), 0)),
            light: ini.int("DefaultSettings", "Light", 200),
            styles,
            builders,
        }
    }

    pub fn from_text(text: &str) -> Settings {
        Settings::from_ini(&Ini::parse(text))
    }

    /// Writes every key `QUIT.CPP` writes into `ini` (other content is kept).
    pub fn write_into(&self, ini: &mut Ini) {
        let c = &self.colors;
        for (k, v) in [
            ("Background", c.background),
            ("MapLines", c.map_lines),
            ("MapInnerLines", c.map_inner_lines),
            ("Selected", c.selected),
            ("Marked", c.marked),
            ("Grid", c.grid),
            ("UserGrid", c.user_grid),
        ] {
            ini.set("Colors", k, format!("{v:X}"));
        }
        let o = &self.options;
        for (k, v) in [
            ("VerifyExit", o.verify_exit),
            ("ShowSnapToGrid", o.show_snap_to_grid),
            ("Show64x64Grid", o.show_64_grid),
            ("BuildNodesAtEverySave", o.build_nodes_at_every_save),
            ("AutoStitchDuringConstruction", o.auto_stitch),
            ("AutoLoadMostRecentFile", o.auto_load_most_recent),
            ("VerifyAfterEdit", o.verify_after_edit),
        ] {
            ini.set("Options", k, v as i32);
        }
        ini.set("Options", "NodeBuilder", o.node_builder);
        ini.set("Options", "RejectBuilder", o.reject_builder);
        ini.set("Options", "GridSize", o.grid_size);
        for (i, r) in self.recent_files.iter().enumerate() {
            ini.set("Files", &format!("RecentFile{}", i + 1), r);
        }
        ini.set("Files", "IWAD", &self.iwad);
        let e = &self.editors;
        for (k, v) in [("Graphics", &e.graphics), ("Text", &e.text), ("Ansi", &e.ansi), ("Sound", &e.sound), ("Music", &e.music)] {
            ini.set("Editors", k, v);
        }
        // drop stale style/builder sections that a shorter list no longer owns
        let old_styles = ini.int("Styles", "NumberOfStyles", 0);
        for i in 0..old_styles.max(0) {
            ini.remove_section(&format!("Style{i}"));
        }
        ini.set("Styles", "NumberOfStyles", self.styles.len());
        for (i, s) in self.styles.iter().enumerate() {
            let sec = format!("Style{i}");
            ini.set(&sec, "Name", &s.name);
            ini.set(&sec, "Floor", &s.floor);
            ini.set(&sec, "Ceiling", &s.ceiling);
            ini.set(&sec, "Walls", &s.walls);
        }
        let old_b = ini.int("Builders", "NumberOfBuilders", 0);
        for i in 0..old_b.max(0) {
            ini.remove_section(&format!("Builder{i}"));
        }
        ini.set("Builders", "NumberOfBuilders", self.builders.len());
        for (i, s) in self.builders.iter().enumerate() {
            let sec = format!("Builder{i}");
            ini.set(&sec, "Name", &s.name);
            ini.set(&sec, "Command", &s.command);
            ini.set(&sec, "Format", s.format);
        }
        ini.set("DefaultSettings", "Walls", &self.default_wall);
        ini.set("DefaultSettings", "Floor", &self.default_floor);
        ini.set("DefaultSettings", "Ceiling", &self.default_ceil);
        ini.set("DefaultSettings", "FloorHeight", self.floor_height);
        ini.set("DefaultSettings", "CeilingHeight", self.ceiling_height);
        for (i, c) in self.custom_colors.iter().enumerate() {
            ini.set("Custom Colors", &format!("Color{}", (b'A' + i as u8) as char), format!("{c:X}"));
        }
        ini.set("DefaultSettings", "Light", self.light);
    }

    pub fn to_text(&self, existing: Option<&str>) -> String {
        let mut ini = existing.map(Ini::parse).unwrap_or_default();
        self.write_into(&mut ini);
        ini.to_string()
    }

    /// `DefSector`, `DefSideDef` and friends, from the "DefaultSettings".
    pub fn defaults(&self) -> Defaults {
        Defaults::new(
            &self.default_wall,
            &self.default_floor,
            &self.default_ceil,
            self.floor_height as i16,
            self.ceiling_height as i16,
            self.light as i16,
        )
    }

    /// The Save dialog's initial choices, from the saved options.
    pub fn save_options(&self) -> SaveOptions {
        SaveOptions {
            node_action: match self.options.node_builder {
                1 => NodeAction::None,
                3 => NodeAction::External,
                4 => NodeAction::IdBsp,
                _ => NodeAction::Internal,
            },
            reject_method: if self.options.reject_builder == 1 { RejectMethod::Quick } else { RejectMethod::Full },
            quirks: Quirks::corrected(),
        }
    }

    /// Records `path` as the most recent file (moved to the front, no duplicates, four kept).
    pub fn add_recent(&mut self, path: &str) {
        let mut v: Vec<String> = self.recent_files.iter().filter(|p| !p.is_empty() && !p.eq_ignore_ascii_case(path)).cloned().collect();
        v.insert(0, path.to_string());
        v.truncate(4);
        for (i, r) in self.recent_files.iter_mut().enumerate() {
            *r = v.get(i).cloned().unwrap_or_default();
        }
    }
}

impl MapData {
    /// `ApplyStyle`: sets the walls of every sidedef in the selected sectors
    /// (only textures that are already set, i.e. not "-" or empty) and the
    /// floor and ceiling of the selected sectors.
    pub fn apply_style(&mut self, s: &Style) -> usize {
        self.normalize_flags();
        let walls = to_name8(&s.walls);
        for i in 0..self.sidedefs.len() {
            if !self.sidedef_flags[i].used {
                continue;
            }
            let Some(sec) = self.sidedefs[i].sector.try_into().ok().filter(|&x: &usize| x < self.sectors.len()) else { continue };
            if !self.sector_flags[sec].selected {
                continue;
            }
            let sd = &mut self.sidedefs[i];
            for t in [&mut sd.t1, &mut sd.t2, &mut sd.t3] {
                if t[0] != b'-' && t[0] != 0 {
                    *t = walls;
                }
            }
        }
        let (floor, ceil) = (to_name8(&s.floor), to_name8(&s.ceiling));
        let mut n = 0;
        for i in 0..self.sectors.len() {
            if self.sector_flags[i].used && self.sector_flags[i].selected {
                self.sectors[i].floor = floor;
                self.sectors[i].ceil = ceil;
                n += 1;
            }
        }
        if n > 0 {
            self.mark_changed();
        }
        n
    }

    /// `ExportDWD`: the map as a "WorldServer version 4" text file for the
    /// id BSP tool. Packs the map first, like the original. A line flagged
    /// two-sided that lacks a second sidedef has that flag cleared.
    pub fn export_dwd(&mut self) -> String {
        self.pack();
        self.normalize_flags();
        let mut out = String::new();
        let wn = |n: &[u8; 8]| name8(n);
        let lines: Vec<usize> = (0..self.linedefs.len()).filter(|&i| is_used(&self.linedef_flags, i)).collect();
        let _ = writeln!(out, "WorldServer version 4");
        let _ = writeln!(out, "level:{}", self.name);
        let _ = writeln!(out, "lines:{}", lines.len());
        for &i in &lines {
            if self.linedefs[i].solidity & 4 != 0 && (self.linedefs[i].sidedef1 == NOTHING || self.linedefs[i].sidedef2 == NOTHING) {
                self.linedefs[i].solidity ^= 4;
            }
            let l = self.linedefs[i];
            let (a, bb) = (self.vertexes[l.from as usize], self.vertexes[l.to as usize]);
            let _ = writeln!(out, "({},{}) to ({},{}) : {} : {} : {}", a.x, a.y, bb.x, bb.y, l.solidity, l.special, l.tag);
            let side = |sd: i16, out: &mut String| {
                let s = self.sidedefs[sd as usize];
                let sec = self.sectors[s.sector as usize];
                let _ = writeln!(out, "    {} ({} : {} / {} / {} )", s.y, s.x, wn(&s.t1), wn(&s.t2), wn(&s.t3));
                let _ = writeln!(out, "    {} : {} {} : {} {} {} {}", sec.floor_z, wn(&sec.floor), sec.ceil_z, wn(&sec.ceil), sec.light, sec.flash, sec.tag);
            };
            if l.sidedef1 != NOTHING {
                side(l.sidedef1, &mut out);
            }
            if l.solidity & 4 != 0 && l.sidedef2 != NOTHING {
                side(l.sidedef2, &mut out);
            }
        }
        let things: Vec<&Thing> = (0..self.things.len()).filter(|&i| is_used(&self.thing_flags, i)).map(|i| &self.things[i]).collect();
        let _ = writeln!(out, "\nthings:{}", things.len());
        for t in things {
            let _ = writeln!(out, "({},{}, {}) :{}, {}", t.x, t.y, t.face, t.item, t.lev);
        }
        out
    }
}
