//! Creating and deleting map items (`ITEMADD.CPP`).
//!
//! The `*_new` functions reuse the first unused slot (an item whose `used`
//! flag was cleared by a lazy delete) before growing, exactly like the
//! original. The `*_del` functions that shrink an array shift the editor
//! flags together with the items; the original shifted only the items, so
//! selection state stayed behind at the old index.

use crate::map::{Flags, MapData};
use crate::structs::*;

impl MapData {
    /// Sector that `sidedef` belongs to, `None` for `NOTHING`/dangling.
    pub fn side_sector(&self, sidedef: i16) -> Option<usize> {
        let sd = self.sidedefs.get(usize::try_from(sidedef).ok()?)?;
        usize::try_from(sd.sector).ok()
    }

    pub fn sector_new(&mut self) -> usize {
        self.normalize_flags();
        let i = match self.sector_flags.iter().position(|f| !f.used) {
            Some(i) => i,
            None => {
                self.sectors.push(self.defaults.sector);
                self.sector_flags.push(Flags::default());
                self.sectors.len() - 1
            }
        };
        self.sectors[i] = self.defaults.sector;
        self.sector_flags[i] = Flags::default();
        self.mark_nodes_dirty();
        i
    }

    pub fn linedef_new(&mut self) -> usize {
        self.normalize_flags();
        let i = match self.linedef_flags.iter().position(|f| !f.used) {
            Some(i) => i,
            None => {
                self.linedefs.push(self.defaults.linedef);
                self.linedef_flags.push(Flags::default());
                self.linedefs.len() - 1
            }
        };
        self.linedefs[i] = self.defaults.linedef;
        self.linedef_flags[i] = Flags::default();
        self.mark_nodes_dirty();
        i
    }

    pub fn sidedef_new(&mut self) -> usize {
        self.normalize_flags();
        let i = match self.sidedef_flags.iter().position(|f| !f.used) {
            Some(i) => i,
            None => {
                self.sidedefs.push(self.defaults.sidedef);
                self.sidedef_flags.push(Flags::default());
                self.sidedefs.len() - 1
            }
        };
        self.sidedefs[i] = self.defaults.sidedef;
        self.sidedef_flags[i] = Flags::default();
        self.mark_changed();
        i
    }

    /// A new linedef with a new front sidedef.
    pub fn linedef_sidedef_new(&mut self) -> usize {
        let l = self.linedef_new();
        let s = self.sidedef_new();
        self.linedefs[l].sidedef1 = s as i16;
        l
    }

    pub fn thing_new(&mut self) -> usize {
        self.normalize_flags();
        let i = match self.thing_flags.iter().position(|f| !f.used) {
            Some(i) => i,
            None => {
                self.things.push(self.defaults.thing);
                self.thing_flags.push(Flags::default());
                self.things.len() - 1
            }
        };
        self.things[i] = self.defaults.thing;
        self.thing_flags[i] = Flags::default();
        self.mark_changed();
        i
    }

    /// `SectorDel`: removes the sector and renumbers sidedef references to
    /// later sectors. (References to the deleted sector itself are left alone;
    /// delete the linedefs that use it first.)
    pub fn sector_del(&mut self, num: usize) {
        self.normalize_flags();
        if num >= self.sectors.len() {
            return;
        }
        self.sectors.remove(num);
        self.sector_flags.remove(num);
        for sd in &mut self.sidedefs {
            if sd.sector as i32 > num as i32 {
                sd.sector -= 1;
            }
        }
        self.mark_nodes_dirty();
    }

    /// `LineDefDel`: frees both sidedefs (lazily, `PackMap` removes them) and
    /// removes the linedef.
    pub fn linedef_del(&mut self, num: usize) {
        self.normalize_flags();
        let Some(l) = self.linedefs.get(num).copied() else { return };
        self.sidedef_del(l.sidedef1);
        self.sidedef_del(l.sidedef2);
        self.linedefs.remove(num);
        self.linedef_flags.remove(num);
        self.mark_nodes_dirty();
    }

    /// `SideDefDel`: sidedefs are only marked unused; `PackMap` removes them.
    pub fn sidedef_del(&mut self, num: i16) {
        if num != NOTHING {
            if let Some(f) = usize::try_from(num).ok().and_then(|n| self.sidedef_flags.get_mut(n)) {
                f.used = false;
            }
        }
        self.mark_changed();
    }

    /// `VertexDel`: frees the slot (it is likely reused right away).
    pub fn vertex_del(&mut self, num: usize) {
        self.normalize_flags();
        if let Some(f) = self.vertex_flags.get_mut(num) {
            f.used = false;
        }
        self.mark_nodes_dirty();
    }

    /// `ThingDel`.
    pub fn thing_del(&mut self, num: usize) {
        self.normalize_flags();
        if num >= self.things.len() {
            return;
        }
        self.things.remove(num);
        self.thing_flags.remove(num);
        self.mark_changed();
    }
}
