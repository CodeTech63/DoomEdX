//! Sector area decomposition for filled (textured) 2D display.
//!
//! Each sector's boundary is the set of linedefs that have it on exactly one
//! side. The area is cut into vertical slabs between consecutive vertex
//! x-coordinates; inside a slab no two edges cross, so sorting the edges by y
//! and pairing them (even-odd rule) yields trapezoids. This handles concave
//! sectors and sectors with holes without a general triangulator.

use crate::map::MapData;

/// Trapezoid with vertical parallel sides: `(x0, x1, [y0_bottom, y0_top], [y1_bottom, y1_top])`.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Trap {
    pub x0: f32,
    pub x1: f32,
    pub y0: [f32; 2],
    pub y1: [f32; 2],
}

impl MapData {
    /// Boundary edges of `sector` as `(x1, y1, x2, y2)`.
    fn sector_edges(&self, sector: usize) -> Vec<(i32, i32, i32, i32)> {
        let mut v = Vec::new();
        for (i, l) in self.linedefs.iter().enumerate() {
            if !self.linedef_flags[i].used {
                continue;
            }
            let a = self.side_sector(l.sidedef1);
            let b = self.side_sector(l.sidedef2);
            if (a == Some(sector)) == (b == Some(sector)) {
                continue; // not on the boundary (or an interior line)
            }
            if let (Some(p), Some(q)) = (self.vertexes.get(l.from as usize), self.vertexes.get(l.to as usize)) {
                v.push((p.x as i32, p.y as i32, q.x as i32, q.y as i32));
            }
        }
        v
    }

    /// Decompose the area of a sector into trapezoids.
    pub fn sector_traps(&self, sector: usize) -> Vec<Trap> {
        let edges: Vec<(i32, i32, i32, i32)> = self
            .sector_edges(sector)
            .into_iter()
            .filter(|e| e.0 != e.2)
            .map(|e| if e.0 < e.2 { e } else { (e.2, e.3, e.0, e.1) })
            .collect();
        let mut xs: Vec<i32> = edges.iter().flat_map(|e| [e.0, e.2]).collect();
        xs.sort_unstable();
        xs.dedup();
        let mut out = Vec::new();
        for w in xs.windows(2) {
            let (x0, x1) = (w[0], w[1]);
            let xm = (x0 + x1) as f64 / 2.0;
            let y_at = |e: &(i32, i32, i32, i32), x: f64| -> f64 {
                let t = (x - e.0 as f64) / (e.2 - e.0) as f64;
                e.1 as f64 + t * (e.3 - e.1) as f64
            };
            let mut span: Vec<&(i32, i32, i32, i32)> = edges.iter().filter(|e| e.0 <= x0 && e.2 >= x1).collect();
            span.sort_by(|a, b| y_at(a, xm).partial_cmp(&y_at(b, xm)).unwrap());
            for pair in span.chunks_exact(2) {
                let (lo, hi) = (pair[0], pair[1]);
                out.push(Trap {
                    x0: x0 as f32,
                    x1: x1 as f32,
                    y0: [y_at(lo, x0 as f64) as f32, y_at(hi, x0 as f64) as f32],
                    y1: [y_at(lo, x1 as f64) as f32, y_at(hi, x1 as f64) as f32],
                });
            }
        }
        out
    }
}

impl Trap {
    pub fn area(&self) -> f32 {
        (self.x1 - self.x0) * ((self.y0[1] - self.y0[0]) + (self.y1[1] - self.y1[0])) / 2.0
    }
}
