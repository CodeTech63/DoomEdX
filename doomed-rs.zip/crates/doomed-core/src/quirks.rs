//! Behaviors of DoomEd 4.0's builders that look like defects (mostly Win16
//! 16-bit `int` overflow or off-by-one errors) but determine its exact output.
//!
//! `Quirks::original()` (the default) reproduces them so output can be
//! compared byte-for-byte with the real program. `Quirks::corrected()` turns
//! them all off. Each flag is documented with where it comes from.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quirks {
    /// `BspFindPartitionSeg` computes `100 * rcnt * lcnt / (16 * splits / 3 + 1)`
    /// entirely in 16-bit `int`, so the score wraps once a node has roughly
    /// 18+ segs per side, making the partition choice effectively arbitrary
    /// for larger nodes. Corrected: 64-bit arithmetic.
    pub partition_16bit_math: bool,

    /// In `BspSplitSeg`, when a seg crosses the partition from the left side to
    /// the right side, the right-hand piece's `distance` (texture offset) is
    /// measured from the seg's far vertex instead of its start vertex.
    /// Corrected: measure from the start vertex.
    pub split_offset_from_wrong_end: bool,

    /// `BuildReject` sizes the lump as `sectors * sectors / 8` (rounded down),
    /// which is too short whenever the sector count is not a multiple of 4.
    /// Corrected: round up.
    pub reject_size_floor: bool,

    /// `BuildBlockmap`: (a) the grid is `(max - min + 128) / 128` blocks wide/
    /// high, one too few for some map sizes; (b) the diagonal slope `m` is
    /// stored in a 16-bit `int`, so lines steeper than about 33:1 wrap.
    /// Corrected: exact grid size and full-width slope.
    pub blockmap_quirks: bool,
}

impl Quirks {
    pub const fn original() -> Self {
        Quirks {
            partition_16bit_math: true,
            split_offset_from_wrong_end: true,
            reject_size_floor: true,
            blockmap_quirks: true,
        }
    }

    pub const fn corrected() -> Self {
        Quirks {
            partition_16bit_math: false,
            split_offset_from_wrong_end: false,
            reject_size_floor: false,
            blockmap_quirks: false,
        }
    }
}

impl Default for Quirks {
    fn default() -> Self {
        Self::original()
    }
}
