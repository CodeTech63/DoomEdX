//! Search and Replace (`DoSearch` / `DoReplace` in `TOOLS.CPP`).
//!
//! Names are matched by *prefix*: the original compares only as many
//! characters as were typed (`strncmp(text, name, strlen(text))`), so "STAR"
//! finds STARTAN1, STARTAN2... An empty pattern matches everything; front ends
//! should not offer that.
//!
//! Differences: the "Total found/replaced" counts. The original counted a line
//! once per matching side, and counted *every* sector in a replace whether
//! it matched or not; these functions count items actually selected/changed.

use crate::map::{is_used, MapData};
use crate::select::Kind;
use crate::structs::*;

fn prefix(name: &[u8; 8], pat: &str) -> bool {
    let p = pat.as_bytes();
    let n = name.iter().position(|&c| c == 0).unwrap_or(8);
    p.len() <= 8 && name[..n].starts_with(p) || (p.is_empty())
}

impl MapData {
    /// Thing tool: selects every thing of type `item` (after clearing the selection).
    pub fn search_things(&mut self, item: i16) -> usize {
        self.normalize_flags();
        self.unselect_all(Kind::Thing);
        let hits: Vec<usize> = (0..self.things.len()).filter(|&i| is_used(&self.thing_flags, i) && self.things[i].item == item).collect();
        for &i in &hits {
            self.select(Kind::Thing, i);
        }
        hits.len()
    }

    /// Sector tool: selects sectors whose floor or ceiling flat starts with `pat`.
    pub fn search_flats(&mut self, pat: &str) -> usize {
        self.normalize_flags();
        self.unselect_all(Kind::Sector);
        if pat.len() > 8 {
            return 0;
        }
        let hits: Vec<usize> = (0..self.sectors.len())
            .filter(|&i| is_used(&self.sector_flags, i) && (prefix(&self.sectors[i].floor, pat) || prefix(&self.sectors[i].ceil, pat)))
            .collect();
        for &i in &hits {
            self.select(Kind::Sector, i);
        }
        hits.len()
    }

    /// Line tool: selects lines with an upper, lower or middle texture starting with `pat`.
    pub fn search_textures(&mut self, pat: &str) -> usize {
        self.normalize_flags();
        self.unselect_all(Kind::LineDef);
        if pat.len() > 8 {
            return 0;
        }
        let mut hits = vec![];
        for i in 0..self.linedefs.len() {
            if !is_used(&self.linedef_flags, i) {
                continue;
            }
            let l = self.linedefs[i];
            let any = [l.sidedef1, l.sidedef2].iter().any(|&sd| {
                sd != NOTHING
                    && self.sidedefs.get(sd as usize).map_or(false, |s| prefix(&s.t1, pat) || prefix(&s.t2, pat) || prefix(&s.t3, pat))
            });
            if any {
                hits.push(i);
            }
        }
        for &i in &hits {
            self.select(Kind::LineDef, i);
        }
        hits.len()
    }

    /// Replaces thing type `from` with `to`; returns how many changed.
    pub fn replace_things(&mut self, from: i16, to: i16) -> usize {
        self.normalize_flags();
        let mut n = 0;
        for i in 0..self.things.len() {
            if self.thing_flags[i].used && self.things[i].item == from {
                self.things[i].item = to;
                n += 1;
            }
        }
        if n > 0 {
            self.mark_changed();
        }
        n
    }

    /// Replaces every floor/ceiling flat that starts with `pat` by `to` (the whole name is replaced).
    pub fn replace_flats(&mut self, pat: &str, to: &str) -> usize {
        self.normalize_flags();
        if pat.len() > 8 {
            return 0;
        }
        let new = to_name8(to);
        let mut n = 0;
        for i in 0..self.sectors.len() {
            if !self.sector_flags[i].used {
                continue;
            }
            if prefix(&self.sectors[i].floor, pat) {
                self.sectors[i].floor = new;
                n += 1;
            }
            if prefix(&self.sectors[i].ceil, pat) {
                self.sectors[i].ceil = new;
                n += 1;
            }
        }
        if n > 0 {
            self.mark_changed();
        }
        n
    }

    /// Replaces every wall texture that starts with `pat` by `to`, on both sides of every line.
    pub fn replace_textures(&mut self, pat: &str, to: &str) -> usize {
        self.normalize_flags();
        if pat.len() > 8 {
            return 0;
        }
        let new = to_name8(to);
        let mut n = 0;
        for i in 0..self.linedefs.len() {
            if !self.linedef_flags[i].used {
                continue;
            }
            let l = self.linedefs[i];
            for sd in [l.sidedef1, l.sidedef2] {
                if sd == NOTHING {
                    continue;
                }
                if let Some(s) = self.sidedefs.get_mut(sd as usize) {
                    for t in [&mut s.t1, &mut s.t2, &mut s.t3] {
                        if prefix(t, pat) {
                            *t = new;
                            n += 1;
                        }
                    }
                }
            }
        }
        if n > 0 {
            self.mark_changed();
        }
        n
    }
}
