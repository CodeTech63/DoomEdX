//! Core data layer of the Rust port of DoomEd 4.0.
//!
//! Mirrors the original program's structures (`STRUCTUR.HPP`), WAD loading
//! (`LOAD.CPP`, `READ.CPP`), map saving (`FILE.CPP`) and map packing
//! (`ITEMADD.CPP`), but with safe, growable `Vec`s instead of Win16 `__huge`
//! global-memory blocks.

pub mod blockmap;
pub mod check;
pub mod build;
pub mod defaults;
pub mod edit;
pub mod finders;
pub mod gfx;
pub mod items;
pub mod join;
pub mod map;
pub mod nodes;
pub mod pack;
pub mod preview3d;
pub mod quirks;
pub mod render3d;
pub mod reject;
pub mod search;
pub mod sectorfill;
pub mod settings;
pub mod undo;
pub mod sectors;
pub mod select;
pub mod structs;
pub mod wad;

pub use map::{Flags, MapData, Rect};
pub use nodes::{BuildError, BuildObserver, NoObserver, NodeStats};
pub use defaults::Defaults;
pub use finders::{hypotenuse, Point};
pub use edit::DoorError;
pub use gfx::{GfxAssets, Image};
pub use render3d::TexCache;
pub use undo::UndoStack;
pub use check::{Assets, NameSets, Problem, ProblemKind};
pub use sectors::{Direction, StepsError, StepsParams};
pub use select::Kind;
pub use build::{NodeAction, PrepareError, PrepareOutcome, SaveOptions};
pub use quirks::Quirks;
pub use settings::{Builder, Colors, Ini, Options, Settings, Style};
pub use reject::RejectMethod;
pub use structs::*;
pub use wad::{Wad, WadEntry, WadError, WadKind, WadType};
