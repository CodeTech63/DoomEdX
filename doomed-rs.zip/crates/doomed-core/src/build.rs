//! The pre-save build sequence from `DoomEdFileSave`.

use crate::map::MapData;
use crate::nodes::{BuildError, BuildObserver, NodeStats};
use crate::quirks::Quirks;
use crate::reject::RejectMethod;

/// The save dialog's node-builder choice (`NODE_*`).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NodeAction {
    /// Don't rebuild nodes ("Nodes not rebuilt...").
    None,
    Internal,
    /// Offered by the dialog, but the original never branches on it: it falls
    /// through to the internal builder, and so does this.
    External,
    /// Export a DWD file for the id BSP tool (not yet ported).
    IdBsp,
}

#[derive(Debug, Clone, Copy)]
pub struct SaveOptions {
    pub node_action: NodeAction,
    pub reject_method: RejectMethod,
    pub quirks: Quirks,
}

impl Default for SaveOptions {
    /// INI defaults: internal builder; thorough (full) reject; the original's
    /// 16-bit and offset bugs corrected.
    fn default() -> Self {
        SaveOptions { node_action: NodeAction::Internal, reject_method: RejectMethod::Full, quirks: Quirks::corrected() }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PrepareOutcome {
    /// Nothing needed rebuilding (`MapNodes` was false).
    UpToDate,
    /// Packed, blockmap and reject rebuilt, nodes deliberately left alone.
    NodesSkipped,
    Built(NodeStats),
}

#[derive(Debug)]
pub enum PrepareError {
    Build(BuildError),
    /// `NodeAction::IdBsp` needs the DWD exporter, which is not ported yet.
    IdBspNotPorted,
}

impl std::fmt::Display for PrepareError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PrepareError::Build(e) => write!(f, "{e}"),
            PrepareError::IdBspNotPorted => write!(f, "DWD export for the id BSP tool is not ported yet"),
        }
    }
}
impl std::error::Error for PrepareError {}
impl From<BuildError> for PrepareError {
    fn from(e: BuildError) -> Self {
        PrepareError::Build(e)
    }
}

impl MapData {
    /// What `DoomEdFileSave` does before writing, when the map's nodes are
    /// dirty: `PackMap`, `BuildBlockmap`, `BuildReject`, then `BspBuild`.
    /// (The original shows the Save Options dialog first; here the choices
    /// arrive in `opts`.) Call [`MapData::save_into`] afterwards.
    pub fn prepare_for_save(
        &mut self,
        opts: &SaveOptions,
        obs: &mut dyn BuildObserver,
    ) -> Result<PrepareOutcome, PrepareError> {
        if !self.nodes_dirty {
            return Ok(PrepareOutcome::UpToDate);
        }
        self.pack();
        self.build_blockmap(&opts.quirks);
        self.build_reject(opts.reject_method, &opts.quirks);
        match opts.node_action {
            NodeAction::None => Ok(PrepareOutcome::NodesSkipped),
            NodeAction::IdBsp => Err(PrepareError::IdBspNotPorted),
            NodeAction::Internal | NodeAction::External => {
                Ok(PrepareOutcome::Built(self.build_nodes(&opts.quirks, obs)?))
            }
        }
    }
}
