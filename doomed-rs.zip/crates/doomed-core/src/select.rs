//! Selection (`SELECT.CPP`). A single pick toggles; a rectangle only adds.

use crate::map::{is_used, MapData, Rect};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    Thing,
    Vertex,
    LineDef,
    Sector,
}

impl MapData {
    fn flags_mut(&mut self, kind: Kind) -> &mut Vec<crate::map::Flags> {
        match kind {
            Kind::Thing => &mut self.thing_flags,
            Kind::Vertex => &mut self.vertex_flags,
            Kind::LineDef => &mut self.linedef_flags,
            Kind::Sector => &mut self.sector_flags,
        }
    }

    fn flags(&self, kind: Kind) -> &[crate::map::Flags] {
        match kind {
            Kind::Thing => &self.thing_flags,
            Kind::Vertex => &self.vertex_flags,
            Kind::LineDef => &self.linedef_flags,
            Kind::Sector => &self.sector_flags,
        }
    }

    /// `SelectThing(n)` etc.: toggles one item. Unused items are ignored.
    pub fn select(&mut self, kind: Kind, num: usize) {
        self.normalize_flags();
        if let Some(f) = self.flags_mut(kind).get_mut(num) {
            if f.used {
                f.selected = !f.selected;
            }
        }
    }

    /// `SelectThing(Nothing)` etc.: adds every item inside `r` (inclusive).
    /// Things and vertexes by position; linedefs need both ends inside;
    /// sectors need their whole extent inside.
    pub fn select_in_rect(&mut self, kind: Kind, r: &Rect) {
        self.normalize_flags();
        let inside = |x: i32, y: i32| x >= r.left && x <= r.right && y >= r.bottom && y <= r.top;
        let hits: Vec<usize> = match kind {
            Kind::Thing => (0..self.things.len())
                .filter(|&i| is_used(&self.thing_flags, i) && inside(self.things[i].x as i32, self.things[i].y as i32))
                .collect(),
            Kind::Vertex => (0..self.vertexes.len())
                .filter(|&i| is_used(&self.vertex_flags, i) && inside(self.vertexes[i].x as i32, self.vertexes[i].y as i32))
                .collect(),
            Kind::LineDef => (0..self.linedefs.len())
                .filter(|&i| {
                    let l = self.linedefs[i];
                    let (a, b) = (self.vertexes.get(l.from as usize), self.vertexes.get(l.to as usize));
                    is_used(&self.linedef_flags, i)
                        && matches!((a, b), (Some(a), Some(b))
                            if inside(a.x as i32, a.y as i32) && inside(b.x as i32, b.y as i32))
                })
                .collect(),
            Kind::Sector => {
                let ext = self.sector_extents();
                (0..self.sectors.len())
                    .filter(|&i| {
                        is_used(&self.sector_flags, i)
                            && match ext[i] {
                                Some(e) => {
                                    e.left >= r.left && e.right <= r.right && e.top <= r.top && e.bottom >= r.bottom
                                }
                                // Quirk: a sector no line touches keeps its initial extent
                                // (left/bottom = MAXINT, right/top = MININT), which passes
                                // every containment test, so any marquee selects it.
                                None => true,
                            }
                    })
                    .collect()
            }
        };
        for i in hits {
            self.flags_mut(kind)[i].selected = true;
        }
    }

    /// `UnSelectAllThings` etc.
    pub fn unselect_all(&mut self, kind: Kind) {
        for f in self.flags_mut(kind) {
            f.selected = false;
        }
    }

    /// `UnSelectAll`.
    pub fn unselect_everything(&mut self) {
        for k in [Kind::Thing, Kind::Vertex, Kind::LineDef, Kind::Sector] {
            self.unselect_all(k);
        }
    }

    /// `SelectedThings` etc.
    pub fn selected_count(&self, kind: Kind) -> usize {
        self.flags(kind).iter().filter(|f| f.used && f.selected).count()
    }

    pub fn is_selected(&self, kind: Kind, num: usize) -> bool {
        self.flags(kind).get(num).map_or(false, |f| f.used && f.selected)
    }
}
