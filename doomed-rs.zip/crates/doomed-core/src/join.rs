//! Welding vertexes and merging coincident linedefs (`JOIN.CPP`).
//!
//! Moving things around in the editor leaves vertexes on top of each other and
//! pairs of one-sided linedefs on top of each other. These routines weld the
//! vertexes and fuse each pair into one two-sided linedef, fixing textures.
//!
//! One deliberate difference: the original's `Join2Lines` reports a "doubled"
//! sector through a global that was only reset by some callers, so a stale
//! value could trigger bogus deletions later. Here it is a per-call result.

use crate::map::{is_used, MapData};
use crate::structs::*;

fn same_ends(a: &LineDef, b: &LineDef) -> bool {
    (a.from == b.to && a.to == b.from) || (a.from == b.from && a.to == b.to)
}

impl MapData {
    /// The "stick a texture into the openings" step shared by the sector
    /// detach/join code: a one-sided wall with no main texture borrows its
    /// lower, else upper texture, else the default wall.
    pub(crate) fn fill_opening(&mut self, sidedef: i16) {
        let default_wall = self.defaults.wall;
        let Some(s) = usize::try_from(sidedef).ok().and_then(|i| self.sidedefs.get_mut(i)) else { return };
        if s.t3[0] == b'-' {
            if s.t2[0] != b'-' {
                s.t3 = copy_wall(&s.t2);
            }
            if s.t1[0] != b'-' {
                s.t3 = copy_wall(&s.t1);
            }
            if s.t3[0] == b'-' {
                s.t3 = copy_wall(&default_wall);
            }
        }
    }

    /// `Join2Lines(a, b)`: fuses linedef `b` into `a` and removes `b`.
    ///
    /// If both lines already carry sidedefs facing the same sector (a
    /// "doubled" sector, from dragging a sector into another), the redundant
    /// sidedef is dropped first. Returns that sector, if any.
    pub fn join_2_lines(&mut self, a: usize, b: usize) -> Option<i16> {
        let (la, lb) = (self.linedefs[a], self.linedefs[b]);
        let sector_of = |m: &Self, sd: i16| m.side_sector(sd).map(|s| s as i16);
        let both = |l: &LineDef| l.sidedef1 != NOTHING && l.sidedef2 != NOTHING;

        // which sector do the two lines have in common? (the last match wins)
        let mut doubled: Option<i16> = None;
        if both(&la) || both(&lb) {
            for (x, y) in [
                (la.sidedef1, lb.sidedef1),
                (la.sidedef2, lb.sidedef1),
                (la.sidedef1, lb.sidedef2),
                (la.sidedef2, lb.sidedef2),
            ] {
                if let (Some(sx), Some(sy)) = (sector_of(self, x), sector_of(self, y)) {
                    if sx == sy {
                        doubled = Some(sx);
                    }
                }
            }
        }

        // delete one redundant face: a face of one line facing the doubled
        // sector, against a two-sided other line's face on the same sector
        if let Some(d) = doubled {
            'done: for x_is_a in [true, false] {
                let (lx, ly) = if x_is_a { (a, b) } else { (b, a) };
                for p in [1, 2] {
                    for q in [1, 2] {
                        let (x, y) = (self.linedefs[lx], self.linedefs[ly]);
                        let xs = if p == 1 { x.sidedef1 } else { x.sidedef2 };
                        let ys = if q == 1 { y.sidedef1 } else { y.sidedef2 };
                        if sector_of(self, xs) == Some(d) && both(&y) && sector_of(self, ys) == Some(d) {
                            self.sidedef_del(ys);
                            if q == 1 {
                                self.linedefs[ly].sidedef1 = NOTHING;
                            } else {
                                self.linedefs[ly].sidedef2 = NOTHING;
                            }
                            break 'done;
                        }
                    }
                }
            }
        }

        // one linedef with two sidedefs where there were two with one each
        let (la, lb) = (self.linedefs[a], self.linedefs[b]);
        let first_rev = la.sidedef2 != NOTHING && la.sidedef1 == NOTHING;
        let second_rev = lb.sidedef2 != NOTHING && lb.sidedef1 == NOTHING;
        if first_rev {
            self.linedefs[a].sidedef1 = if second_rev { lb.sidedef2 } else { lb.sidedef1 };
        } else {
            self.linedefs[a].sidedef2 = if second_rev { lb.sidedef2 } else { lb.sidedef1 };
        }

        let (s1, s2) = (self.linedefs[a].sidedef1, self.linedefs[a].sidedef2);
        let (sec1, sec2) = (self.side_sector(s1), self.side_sector(s2));
        let (Some(sec1), Some(sec2)) = (sec1, sec2) else {
            // The original dereferences a missing sidedef here; just drop b.
            self.linedef_flags[b].used = false;
            self.mark_changed();
            return doubled;
        };
        if sec1 >= self.sectors.len() || sec2 >= self.sectors.len() {
            self.linedef_flags[b].used = false;
            self.mark_changed();
            return doubled;
        }
        let (s1, s2) = (s1 as usize, s2 as usize);

        // the wall is now passable
        self.linedefs[a].set_bit(line_bits::TWO_SIDED);
        self.linedefs[a].clear_bit(line_bits::IMPASSABLE);

        // move the main textures out of the opening
        let default_wall = copy_wall(&self.defaults.wall);
        let mut orig1 = copy_wall(&self.sidedefs[s1].t3);
        self.sidedefs[s1].t3 = null_wall();
        let mut orig2 = copy_wall(&self.sidedefs[s2].t3);
        self.sidedefs[s2].t3 = null_wall();
        if orig1[0] == b'-' {
            orig1 = default_wall;
        }
        if orig2[0] == b'-' {
            orig2 = default_wall;
        }

        // put (and match) textures where floors and ceilings don't meet,
        // but only where there wasn't a texture already
        let (c1, c2) = (self.sectors[sec1].ceil_z, self.sectors[sec2].ceil_z);
        let (f1, f2) = (self.sectors[sec1].floor_z, self.sectors[sec2].floor_z);
        if c1 > c2 {
            if self.sidedefs[s1].t1[0] == b'-' {
                self.sidedefs[s1].t1 = orig1;
            }
            self.sidedefs[s1].y = c1.wrapping_sub(c2);
        }
        if c1 < c2 {
            if self.sidedefs[s2].t1[0] == b'-' {
                self.sidedefs[s2].t1 = orig2;
            }
            self.sidedefs[s2].y = c2.wrapping_sub(c1);
        }
        if f1 > f2 && self.sidedefs[s2].t2[0] == b'-' {
            self.sidedefs[s2].t2 = orig2;
        }
        if f1 < f2 && self.sidedefs[s1].t2[0] == b'-' {
            self.sidedefs[s1].t2 = orig1;
        }

        self.linedef_flags[b].used = false;
        self.mark_changed();
        doubled
    }

    /// `ProcessJoins`: after a move, weld every moving vertex to any vertex at
    /// the same spot, then fuse every moving linedef with a linedef sharing
    /// both its ends.
    pub fn process_joins(&mut self) {
        self.normalize_flags();
        // STEP ONE: vertexes
        for i in 0..self.vertexes.len() {
            if !(self.vertex_flags[i].used && self.vertex_flags[i].moving) {
                continue;
            }
            for j in 0..self.vertexes.len() {
                if !(self.vertex_flags[j].used && j != i && self.vertexes[i] == self.vertexes[j]) {
                    continue;
                }
                // vertexes i and j are in the same place: point lines at i
                for k in 0..self.linedefs.len() {
                    if self.linedef_flags[k].used {
                        let l = &mut self.linedefs[k];
                        if l.from == j as i16 {
                            l.from = i as i16;
                        }
                        if l.to == j as i16 {
                            l.to = i as i16;
                        }
                        if l.from == l.to {
                            // the line shrank to a point
                            let (s1, s2) = (l.sidedef1, l.sidedef2);
                            self.linedef_flags[k].used = false;
                            self.sidedef_del(s1);
                            self.sidedef_del(s2);
                        }
                    }
                }
                if !self.linedefs.is_empty() {
                    self.vertex_del(j);
                }
            }
        }

        // STEP TWO: lines
        for i in 0..self.linedefs.len() {
            if !(self.linedef_flags[i].used && self.linedef_flags[i].moving) {
                continue;
            }
            for j in 0..self.linedefs.len() {
                if !(self.linedef_flags[i].used
                    && self.linedef_flags[j].used
                    && i != j
                    && same_ends(&self.linedefs[i], &self.linedefs[j]))
                {
                    continue;
                }
                if let Some(d) = self.join_2_lines(i, j) {
                    // remove the face that now duplicates the doubled sector
                    let l = self.linedefs[i];
                    if self.side_sector(l.sidedef1).map(|s| s as i16) == Some(d) {
                        self.sidedef_del(l.sidedef1);
                        self.linedefs[i].sidedef1 = l.sidedef2;
                        self.linedefs[i].sidedef2 = NOTHING;
                    } else if self.side_sector(l.sidedef2).map(|s| s as i16) == Some(d) {
                        self.sidedef_del(l.sidedef2);
                        self.linedefs[i].sidedef2 = NOTHING;
                    }
                }
            }
        }

        self.find_vertexes_in_use();
        self.mark_changed();
    }

    /// `Join2Vertexes(a, b)`: the older single-vertex weld: everything that
    /// used `b` now uses `a`, then moving lines that coincide are fused.
    pub fn join_2_vertexes(&mut self, a: usize, b: usize) {
        self.normalize_flags();
        for i in 0..self.linedefs.len() {
            if !self.linedef_flags[i].used {
                continue;
            }
            let l = &mut self.linedefs[i];
            if l.from == b as i16 {
                l.from = a as i16;
            }
            if l.to == b as i16 {
                l.to = a as i16;
            }
            if l.from == l.to {
                self.linedef_flags[i].used = false;
            }
        }
        for i in 0..self.linedefs.len() {
            if !self.linedef_flags[i].moving {
                continue;
            }
            for j in 0..self.linedefs.len() {
                if same_ends(&self.linedefs[i], &self.linedefs[j])
                    && self.linedef_flags[i].used
                    && self.linedef_flags[j].used
                    && i != j
                {
                    self.join_2_lines(i, j);
                }
            }
        }
        self.find_vertexes_in_use();
        self.mark_changed();
    }

    /// `ProcessSectorJoins`: after a sector's floor/ceiling height changed,
    /// re-split every two-sided linedef on the boundary of the selection and
    /// join it back so the step textures are redone for the new heights.
    pub fn process_sector_joins(&mut self) {
        self.normalize_flags();
        let mut i = 0;
        while i < self.linedefs.len() {
            if is_used(&self.linedef_flags, i) {
                let l = self.linedefs[i];
                let (sec1, sec2) = (self.side_sector(l.sidedef1), self.side_sector(l.sidedef2));
                if let (Some(sec1), Some(sec2)) = (sec1, sec2) {
                    let (sel1, sel2) = (
                        self.sector_flags.get(sec1).map_or(false, |f| f.selected),
                        self.sector_flags.get(sec2).map_or(false, |f| f.selected),
                    );
                    if sel1 != sel2 {
                        let newl = self.linedef_new();
                        let newv1 = self.vertex_new().expect("vertex space");
                        let newv2 = self.vertex_new().expect("vertex space");
                        self.vertexes[newv1] = self.vertexes[self.linedefs[i].from as usize];
                        self.vertexes[newv2] = self.vertexes[self.linedefs[i].to as usize];
                        // fix the flags, then copy the linedef
                        self.linedefs[i].set_bit(line_bits::IMPASSABLE);
                        self.linedefs[i].clear_bit(line_bits::TWO_SIDED);
                        self.linedefs[newl] = self.linedefs[i];
                        // the copy takes the second sidedef
                        self.linedefs[newl].sidedef1 = self.linedefs[i].sidedef2;
                        self.linedefs[i].sidedef2 = NOTHING;
                        self.linedefs[newl].sidedef2 = NOTHING;
                        self.fill_opening(self.linedefs[i].sidedef1);
                        self.fill_opening(self.linedefs[newl].sidedef1);
                        // reverse lines as required
                        if sel1 {
                            self.linedefs[newl].from = self.linedefs[i].to;
                            self.linedefs[newl].to = self.linedefs[i].from;
                            self.linedefs[i].from = newv1 as i16;
                            self.linedefs[i].to = newv2 as i16;
                        } else {
                            self.linedefs[newl].to = newv1 as i16;
                            self.linedefs[newl].from = newv2 as i16;
                        }
                        // separated, now join them again
                        self.join_2_lines(i, newl);
                    }
                }
            }
            i += 1;
        }
        self.find_vertexes_in_use();
        self.mark_changed();
    }
}
