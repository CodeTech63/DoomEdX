//! Renders a map's 3D preview to a PPM image (software lines) so the
//! projection can be checked without a window.
//!   cargo run --example preview_ppm -- file.wad MAPNAME out.ppm [hidden]
use doomed_core::preview3d::*;
use doomed_core::*;

fn line(img: &mut [u8], w: i32, h: i32, a: (i32, i32), b: (i32, i32), c: [u8; 3]) {
    let (mut x, mut y) = a;
    let (dx, dy) = ((b.0 - a.0).abs(), -(b.1 - a.1).abs());
    let (sx, sy) = (if a.0 < b.0 { 1 } else { -1 }, if a.1 < b.1 { 1 } else { -1 });
    let mut e = dx + dy;
    loop {
        if x >= 0 && y >= 0 && x < w && y < h {
            let o = ((y * w + x) * 3) as usize;
            img[o..o + 3].copy_from_slice(&c);
        }
        if (x, y) == b { break; }
        let e2 = 2 * e;
        if e2 >= dy { e += dy; x += sx; }
        if e2 <= dx { e += dx; y += sy; }
    }
}

fn fill(img: &mut [u8], w: i32, h: i32, p: &[(i32, i32); 4]) {
    let (ymin, ymax) = (p.iter().map(|q| q.1).min().unwrap().max(0), p.iter().map(|q| q.1).max().unwrap().min(h - 1));
    for y in ymin..=ymax {
        let mut xs = vec![];
        for i in 0..4 {
            let (a, b) = (p[i], p[(i + 1) % 4]);
            if (a.1 <= y && b.1 > y) || (b.1 <= y && a.1 > y) {
                xs.push(a.0 + (y - a.1) * (b.0 - a.0) / (b.1 - a.1));
            }
        }
        xs.sort();
        for pair in xs.chunks(2) {
            if let [x0, x1] = pair {
                for x in (*x0).max(0)..=(*x1).min(w - 1) {
                    let o = ((y * w + x) * 3) as usize;
                    img[o..o + 3].copy_from_slice(&[0, 0, 0]);
                }
            }
        }
    }
}

fn main() {
    let a: Vec<String> = std::env::args().skip(1).collect();
    let wad = Wad::open(&a[0]).expect("wad");
    let h = wad.find(&a[1]).expect("map");
    let m = MapData::load(&wad, h).expect("load");
    let hidden = a.get(3).map_or(false, |s| s == "hidden");
    let cam = Camera::for_extent(m.map_extent());
    let (w, hh) = (800, 600);
    let mut img = vec![0u8; (w * hh * 3) as usize];
    for p in project(&panels(&m), &cam, w, hh, hidden) {
        if hidden { fill(&mut img, w, hh, &p.s); }
        for i in 0..4 { line(&mut img, w, hh, p.s[i], p.s[(i + 1) % 4], [255, 0, 0]); }
    }
    let mut out = format!("P6\n{w} {hh}\n255\n").into_bytes();
    out.extend(img);
    std::fs::write(&a[2], out).unwrap();
}
