//! Re-run DoomEd's builders on every map in a WAD and compare with the lumps
//! already stored there. On a WAD saved by the real DOOMED40.EXE (internal
//! node builder), every line should say "identical" with the default quirks.
//!
//!   cargo run --release --example rebuild -- file.wad [--corrected] [--full-reject]
use doomed_core::*;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let Some(path) = args.iter().find(|a| !a.starts_with("--")) else {
        eprintln!("usage: rebuild <file.wad> [--corrected] [--full-reject]");
        std::process::exit(2);
    };
    let q = if args.iter().any(|a| a == "--corrected") { Quirks::corrected() } else { Quirks::original() };
    let method = if args.iter().any(|a| a == "--full-reject") { RejectMethod::Full } else { RejectMethod::Quick };
    let wad = Wad::open(path).unwrap_or_else(|e| {
        eprintln!("{path}: {e}");
        std::process::exit(1);
    });
    println!("quirks: {}   reject: {method:?}", if q == Quirks::corrected() { "corrected" } else { "original" });

    for h in wad.maps() {
        let Some(orig) = MapData::load(&wad, h) else { continue };
        let mut m = orig.clone();
        m.build_blockmap(&q);
        m.build_reject(method, &q);
        let nodes = m.build_nodes(&q, &mut NoObserver);
        let tag = |same: bool| if same { "identical" } else { "DIFFERS" };
        match nodes {
            Ok(st) => println!(
                "{:<6} nodes {:>4} (was {:>4}) {:<9} | ssectors {:<9} | segs {:>5} (was {:>5}) {:<9} | vertexes {:<9} | blockmap {:<9} | reject {:<9}",
                orig.name,
                st.nodes, orig.nodes.len(), tag(m.nodes == orig.nodes),
                tag(m.ssectors == orig.ssectors),
                st.segs, orig.segs.len(), tag(m.segs == orig.segs),
                tag(m.vertexes == orig.vertexes),
                tag(m.blockmap == orig.blockmap),
                tag(m.reject == orig.reject),
            ),
            Err(e) => println!("{:<6} node build failed: {e}", orig.name),
        }
    }
}
