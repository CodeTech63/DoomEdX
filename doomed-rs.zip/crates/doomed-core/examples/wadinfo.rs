//! `cargo run --example wadinfo -- path/to/DOOM.WAD`
use doomed_core::*;
use std::collections::BTreeMap;

fn main() {
    let Some(path) = std::env::args().nth(1) else {
        eprintln!("usage: wadinfo <file.wad>");
        std::process::exit(2);
    };
    let wad = match Wad::open(&path) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("{path}: {e}");
            std::process::exit(1);
        }
    };
    println!("{path}: {:?}, {} lumps", wad.kind, wad.entries.len());
    let mut by_type: BTreeMap<String, usize> = BTreeMap::new();
    for e in &wad.entries {
        *by_type.entry(format!("{:?}", e.ty)).or_default() += 1;
    }
    for (t, n) in &by_type {
        println!("  {t:<12}{n}");
    }
    for h in wad.maps() {
        let Some(m) = MapData::load(&wad, h) else { continue };
        let ext = m.map_extent().map_or("empty".to_string(), |r| format!("({},{})-({},{})", r.left, r.bottom, r.right, r.top));
        println!(
            "{:<6} things {:>4}  lines {:>5}  sides {:>5}  verts {:>5}  sectors {:>4}  tags {:>2}  extent {}",
            m.name, m.things.len(), m.linedefs.len(), m.sidedefs.len(), m.vertexes.len(), m.sectors.len(), m.tags.len() - 1, ext
        );
    }
}
