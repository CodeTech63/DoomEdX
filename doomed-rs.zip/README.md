# DoomEd 4.0 — Rust port

A faithful recreation of **DoomEd 4.0** (Geoff Allan, 1995; 16-bit Windows / MSVC 1.5)
in Rust, targeting modern Windows.

## Status: Milestones 1-4 — core (`doomed-core`) and the egui editor (`doomed-app`)

No dependencies, no UI. `cargo test` runs 58 tests.

| Rust | Original | Notes |
|---|---|---|
| `structs.rs` | `STRUCTUR.HPP`, `MACROS.HPP` | All WAD records (16-bit LE), `Tag` (274-byte `TAGDESC`), `NullWall`/`CopyWall`, line-bit helpers |
| `wad.rs` | `LOAD.CPP` `LoadWad` | Header/directory, exact `WD_*` classification incl. sprite/panel/tile ranges |
| `map.rs` | `READ.CPP`, `FILE.CPP`, `VertexNew` | `ReadMap` 12-entry lump window, tags, extents, in-place map replace, dirty flags |
| `pack.rs` | `PackMap`, `GetSectorExtents` | Orphan-sector removal, sidedef repacking |
| `nodes.rs` | `NODES.CPP`, `NODEBLDR.H` | BSP builder: partition scoring, seg splitting, subsector test, post-order output |
| `blockmap.rs` | `BLOCKMAP.CPP` | 128-unit grid, horizontal/vertical/diagonal line walking |
| `reject.rs` | `REJECT.CPP` | Quick (sector centers) and Full (linedef endpoints) methods |
| `build.rs` | `DoomEdFileSave` | Pack -> blockmap -> reject -> nodes, driven by `SaveOptions` |
| `quirks.rs` | — | Switch between original and corrected behavior (below) |
| `defaults.rs` | `INIT.CPP`, `GLOBALS.CPP` | Templates for new things, linedefs, sidedefs, sectors |
| `items.rs` | `ITEMADD.CPP` | `*_new` (reuse unused slots first) and `*_del` |
| `select.rs` | `SELECT.CPP` | Toggle / marquee selection for things, vertexes, linedefs, sectors |
| `finders.rs` | `FINDERS.CPP` | Nearest vertex / thing / linedef (halving search) / sector (ray cast) |
| `join.rs` | `JOIN.CPP` | `ProcessJoins`, `Join2Lines`, `Join2Vertexes`, `ProcessSectorJoins` |
| `sectors.rs` | `SECTOR.CPP`, `TOOLS.CPP`, `NEWSECT.CPP`, `STEPS.CPP` | Detach, extract, duplicate, drop; rectangle / polygon / star / steps generators |
| `check.rs` | `TOOLS.CPP` `DialogMapCheck` | Map checker with exact messages; texture/flat lookup via the `Assets` trait |

Tools (`cargo run --release --example ...`):
* `wadinfo -- DOOM.WAD` — lump classes and per-map counts.
* `rebuild -- file.wad [--corrected] [--full-reject]` — re-runs every builder on each map and compares
  byte-for-byte with the lumps stored in the WAD. Run it on a WAD saved by the real `DOOMED40.EXE`:
  with default (original) quirks every column should read `identical`.

### Quirks (saving uses `Quirks::corrected()`; `Quirks::original()` reproduces DOOMED40.EXE and is kept for the `rebuild` example and tests)
These are behaviors of the original that look like defects but determine its exact output.

| Flag | Original behavior | Effect |
|---|---|---|
| `partition_16bit_math` | `100 * rcnt * lcnt / (16 * splits / 3 + 1)` evaluated in 16-bit `int` | Score wraps at ~18+ segs per side, so partition choice is effectively arbitrary in large nodes (still a valid BSP, just less balanced) |
| `split_offset_from_wrong_end` | When a seg crosses from left to right, the right piece's `distance` is measured from the wrong endpoint | Wrong texture offset on some split walls |
| `reject_size_floor` | Reject lump = `sectors² / 8` rounded down | Too short unless the sector count is a multiple of 4 (a 1-sector map gets an empty lump) |
| `blockmap_quirks` | Grid is `(max-min+128)/128` blocks (one too few for some map sizes); slope stored in a 16-bit `int` | Lines steeper than ~33:1 walk the wrong blocks; some maps index one column past the grid |

### Editing-model notes
Operations that move things mark the new vertexes and linedefs as *moving*; the UI drags them and then
calls `process_joins()`, which welds coincident vertexes and fuses coincident linedefs, exactly like the
original. Deletes come in two kinds, as in the original: `*_del` removes immediately, while joins and
`PackMap` use the lazy `used = false` flag.

Carried over on purpose:
* `NearestLineDef` gives up (returns `None`) rather than guess when two lines stay equally close.
* A sector no line touches is selected by any marquee (its "extent" is the untouched initial one).
* The Steps/Polygon/Star generators and `SectorDuplicate` reuse freed slots in the same order.
* The map checker's "Invalid ... Texture" messages call a sidedef's first texture "Lower" and its second
  "Upper", while its "Missing ..." messages use the conventional meaning; texture names match by
  *prefix* (a truncated name passes).

### Deliberate differences that are always on
* `*_del` shifts the selection/moving flags together with the items (the original left them behind).
* `Join2Lines` returns the "doubled" sector instead of setting a global that some callers never reset.
* A missing sidedef in `Join2Lines`, an empty hit-test (`dist[-1]`) and a zero step count (divide by zero)
  are handled instead of crashing.
* Saving writes a compact file (equivalent to the original's save + `PurgeWad`).
* `GetMapExtents` includes vertex 0 and no longer clears vertex selection.
* Tag compaction drops number-0 entries cleanly.
* A missing lump loads as empty.
* Crashes in the original become safe fallbacks or errors: empty linedef list, divide-by-zero on near-flat
  blockmap diagonals, per-block 50-entry buffer overflow, an uninitialised partition index, and the stray
  `node->segs = SegInfo->prev` assignment in `BspDivideNode` (which would drop earlier right-side segs).
* `NODE_EXTERNAL` falls through to the internal builder, exactly as in `BspBuild`; `NODE_IDBSP` (DWD export)
  returns an error until that exporter is ported.
* The original's live drawing during the build is exposed as the `BuildObserver` trait.

## Milestone 4: the editor (`doomed-app`)

    cargo run --release -p doomed-app [file.wad]

Needs Rust 1.81+ (eframe 0.29). `Editor` (`editor.rs`) is the mouse/keyboard state machine ported from
`MOUSE.CPP`/`EDIT.CPP` with no windowing in it, so it is tested headlessly (`tests/mouse.rs`);
`View` (`view.rs`) is `PAINT.CPP`'s aspect fit and `SCROLL.CPP`'s zoom/scroll; `app.rs` is the egui shell
(canvas drawn with `PAINT.CPP`'s rules and the INI default colours, menus, toolbar, property panels, dialogs).

Mouse (as in the original): left-click selects (Shift toggles), drag on empty space is a marquee (small marquee
= unselect all), hold past the double-click time and drag to move; Shift while starting a sector drag
extracts instead of detaching. Right-drag in empty space with the Sector tool offers New Sector
(Shift = square, Ctrl = centred); right-click on a sector offers the Selected Object menu; Thing tool
right-click places a thing; Vertex tool right-click on a line splits it; Line tool right-click near a vertex
rubber-bands a new line with vertex snap. Del = partial delete, Shift+Del = full delete. Mouse wheel zooms,
middle-drag pans, arrows/PgUp/PgDn scroll, Ctrl+S saves.

File dialogs are in-app path prompts (no native file picker). Open an IWAD (File menu) to give Check Map the
texture/flat names. An IWAD is never overwritten: Save As writes a PWAD.

Deviations from the original in this layer
* Vertex Snap skips the vertexes being dragged (the original could snap a vertex to itself and freeze).
* `MakeSectorDoor` identifies the two border sidedefs properly (the original compared a sidedef index with sector numbers).
* Delete commands now flag the map changed (the original never called `MapChange`); the menu captions
  for Delete/Partial Delete are no longer swapped relative to the keys.
* The unreachable right-button branch of `DoomEdMouseMove` is not ported.
* Thing colours, the thing facing tick and the layout of the property panels are my choices (not recovered from the source).

### Milestone 5 (partial): graphics
`doomed_core::gfx` decodes PLAYPAL, patches, flats and composite textures (TEXTURE1/2 + PNAMES) to RGBA
(`tests/gfx.rs`). The editor shows texture/flat thumbnails in the property panels, has a filterable
picker (the "..." buttons; a sector choice applies to every selected sector), and a WAD Directory window
with picture previews. Open an IWAD first (File menu); an open PWAD's own graphics override it.

### Milestone 6: 3D preview
`doomed_core::preview3d` ports `3D.CPP`/`H3D.CPP` (camera matrix, mouse gestures, wall-panel extraction,
projection, far-to-near sort) with no drawing in it (`tests/preview3d.rs`); the app's *Map > 3D Preview...*
window draws it. Left-drag orbits and raises the viewer, right-drag turns the view and raises the target,
both buttons dolly, H (or the checkbox) toggles hidden-line mode, and the viewer/target/zoom fields are the
original's setup dialog. `cargo run -p doomed-core --example preview_ppm -- file.wad E1M1 out.ppm [hidden]`
renders the same view to an image without a window.

Deviations: points behind the viewer are dropped (the original mirrored them); the camera starts outside
the map looking at its centre instead of at a fixed (1000, 1000, 200); hidden-line mode stays on while
dragging (the original suppressed it for speed). Like the original there are no textures or floors/ceilings,
and a panel with any corner far off-screen is dropped rather than clipped.

Not yet ported: Search/Replace, Styles (Apply Style/Styles...), tag/platform dialogs, sounds and tiles in
the directory viewer, lump import/export/delete, 2D print, 3D preview, DWD export/external builders,
Options dialog and INI persistence.

### Milestone 7: remaining tools

- Search / Replace for things, flats and textures (prefix match, as TOOLS.CPP), with picker integration.
- Styles (STYLES.CPP): list, add/edit/delete, apply to selected sectors; `[Styles]` in the INI.
- INI persistence (INIT/QUIT): colours, options, recent files, editors, sector defaults, builders (stored, not executed, as in the original).
- Platforms/Tags dialog (Map menu) and tag drop-downs in the sector and linedef panels.
- Named sector specials, linedef actions and flag names from LISTS.CPP (`specials.rs`).
- DWD export (WorldServer version 4) and lump import/export in the directory browser.
- Textured floors in the 2D view (View > Floor textures): sectors are cut into trapezoids (`sectorfill.rs`) and filled with their floor flat at 64 map units per tile.
- Textured 3D view (`render3d.rs`; shown in the main pane, switched with the 2D/3D toggle beside the Grid box or Map > 3D View; the app starts in 2D and the render size follows the pane with no cap, software rasteriser; `T` toggles it, Ctrl + left-drag moves the look-at point, the scroll wheel moves the viewer nearer to / farther from it (the both-buttons drag still dollies), `H` still switches the wireframe to hidden-line): walls follow the Doom peg rules and x/y offsets, floors and ceilings are tiled 64x64 flats, sky ceilings are flat blue, two-sided middle textures are masked, back faces are culled. Clicking in the 3D view selects what is under the pointer (a wall selects its linedef, a floor or ceiling its sector, a sprite its thing), switches to the matching tool and fills the properties panel; Shift-click toggles. Picking works in wireframe mode too. Needs an IWAD for the graphics; otherwise the wireframe is used. `cargo run -p doomed-app --example textured_demo -- out.ppm` renders a synthetic room.
- Undo / redo (Edit menu, Ctrl+Z, Ctrl+Y or Ctrl+Shift+Z): 20 levels, by whole-map snapshots taken whenever the editor is idle (no mouse button down, no text being typed), so a whole drag or typed value is one step. Selection changes are not steps. Loading or creating a map starts a fresh history; saving does not add one. Not in the original.
- Save As opens the system file dialog on Windows (the `rfd` crate; other platforms keep the built-in path box). Saving runs on a worker thread; if it takes longer than 0.3 s a centred "Building nodes..." notice appears and the editor is locked until it finishes, so a long node build no longer freezes the window.
- Open WAD and Open IWAD use the system file dialog on Windows too.
- 3D view: right-click a wall to save the textures of the side you clicked (upper, lower, middle) or a floor/ceiling to save that sector's flats; Ctrl + right-click pastes onto the wall or sector under the pointer (wall onto wall, sector onto sector). Only textures are pasted: never offsets, line flags, actions, tags, heights, light or sector specials.
- Reset button beside the 2D/3D toggle returns the 3D viewer to its starting position. The texture/flat picker is a 5-column scrolling grid; click the picture to choose it.
- Map > Statistics (item counts after packing, as `DoomEdStatistics`).
- Directory viewer: Rename... (LABEL.CPP) with the MAP01-32 / S_START / P_START / F_START marker list.
- Options: the 16 custom colours persist in the INI (`[Custom Colors]`, ColorA..ColorP); right-click a swatch to apply it to a map colour.
- View > Sector fill: none / floor textures / ceiling textures / light level (2D view).
- 3D preview "Things" option: things are drawn as upright sprite billboards (lump named by the thing table, rotated frames such as `A2A8` accepted, origin offsets honoured), standing on their sector's floor.
- Not ported: 2D printing (PRINT.CPP) and ImportDWD (an empty stub in the original).

## Roadmap (original file → Rust)
2. ~~Node builder~~ done. Remaining: `DWD.CPP` export and external builders (`BUILDERS.CPP`)
3. ~~2D editor model~~ done, except `DoSearch`/`DoReplace` (TOOLS.CPP) and the property dialogs' logic (`LINEDEF`, `SECTOR`, `THING`, `TAGS`, `LABEL`), which belong with the UI
4. ~~UI shell~~ done in `doomed-app` (not yet: `OPTIONS` persistence, `STYLES`, search/replace, tag dialogs)
5. **Graphics/assets**: pictures, pickers and a basic directory viewer done; remaining: sounds/tiles, lump edit, `VIEWERS`
6. ~~3D preview~~ done (wireframe and hidden-line)
